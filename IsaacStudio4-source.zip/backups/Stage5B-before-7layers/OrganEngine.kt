package com.isaacstudio.studio4.audio.instruments

import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.pow

class OrganEngine : com.isaacstudio.studio4.audio.AudioRenderer {
    @Volatile
    override var isRenderingEnabled = true
@Volatile
var layerVolume = 1.0f

    companion object {
        private const val SAMPLE_RATE = 44100
        private const val VOICE_COUNT = 16

        private val DRAWBAR_RATIOS = doubleArrayOf(
            0.5, 1.5, 1.0, 2.0, 3.0,
            4.0, 5.0, 6.0, 8.0
        )
    }

    private data class Voice(
var voiceId: Long = 0L,
        var note: Int = -1,
        var phase: Double = 0.0,
        var active: Boolean = false
    )

    private val voices = Array(VOICE_COUNT) { Voice() }
private var nextVoiceId = 1L
    private val drawbars = IntArray(9) { 0 }



    fun setDrawbar(index: Int, level: Int) {
        if (index in 0..8) {
            synchronized(voices) {
                drawbars[index] = level.coerceIn(0, 8)
            }
        }
    }

    fun setDrawbars(levels: IntArray) {
        synchronized(voices) {
            for (i in 0..8) {
                if (i < levels.size) {
                    drawbars[i] = levels[i].coerceIn(0, 8)
                }
            }
        }
    }

fun noteOn(note: Int): Long {
    return synchronized(voices) {
        val voice = voices.firstOrNull { !it.active }
            ?: voices.minByOrNull { it.note }

        if (voice == null) {
            0L
        } else {
            voice.voiceId = nextVoiceId++
            voice.note = note.coerceIn(0, 127)
            voice.phase = 0.0
            voice.active = true
            voice.voiceId
        }
    }
}

    fun noteOff(note: Int) {
        synchronized(voices) {
            voices.filter { it.active && it.note == note }
                .forEach {
                    it.active = false
                    it.note = -1
                }
        }
    }
fun noteOffVoice(voiceId: Long) {
    synchronized(voices) {
        val voice = voices.firstOrNull {
            it.active && it.voiceId == voiceId
        } ?: return

        voice.active = false
        voice.note = -1
    }
}


override fun renderInto(buffer: FloatArray) {
    if (!isRenderingEnabled) return
    synchronized(voices) {
        for (i in buffer.indices) {
            var sample = 0.0

            for (voice in voices) {
                if (!voice.active) continue

                val frequency = 440.0 *
                    2.0.pow((voice.note - 69) / 12.0)

                for (bar in 0..8) {
                    val level = drawbars[bar]
                    if (level == 0) continue

                    val ratio = DRAWBAR_RATIOS[bar]
                    val angle = 2.0 * PI *
                        voice.phase * ratio

                    sample += sin(angle) * (level / 8.0)
                }

                voice.phase += frequency / SAMPLE_RATE

                if (voice.phase >= 1.0) {
                    voice.phase -= 1.0
                }
            }

buffer[i] += (
    sample * 0.025 * layerVolume.coerceIn(0f, 1f)
).coerceIn(-1.0, 1.0).toFloat()

        }
    }
}
fun start() {
    isRenderingEnabled = true
}

fun stop() {
    isRenderingEnabled = false
}

}
