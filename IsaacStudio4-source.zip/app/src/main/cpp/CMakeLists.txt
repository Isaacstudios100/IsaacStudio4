cmake_minimum_required(VERSION 3.22.1)
project(IsaacPianoSampleDecoder LANGUAGES C CXX)

set(CMAKE_C_STANDARD 99)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

set(THIRD_PARTY_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party")
foreach(component opus ogg opusfile)
    if(NOT EXISTS "${THIRD_PARTY_DIR}/${component}")
        message(FATAL_ERROR "Missing pinned dependency source: ${component}")
    endif()
endforeach()

# Build the official Xiph libopus as a static library.
set(OPUS_BUILD_SHARED_LIBRARY OFF CACHE BOOL "" FORCE)
set(OPUS_BUILD_TESTING OFF CACHE BOOL "" FORCE)
set(OPUS_BUILD_PROGRAMS OFF CACHE BOOL "" FORCE)
set(OPUS_INSTALL_PKG_CONFIG_MODULE OFF CACHE BOOL "" FORCE)
set(OPUS_INSTALL_CMAKE_CONFIG_MODULE OFF CACHE BOOL "" FORCE)
add_subdirectory("${THIRD_PARTY_DIR}/opus" "${CMAKE_CURRENT_BINARY_DIR}/opus")

# Build the small Ogg container library statically.
add_library(ogg STATIC
    "${THIRD_PARTY_DIR}/ogg/src/bitwise.c"
    "${THIRD_PARTY_DIR}/ogg/src/framing.c"
)
target_include_directories(ogg PUBLIC "${THIRD_PARTY_DIR}/ogg/include")
set_target_properties(ogg PROPERTIES POSITION_INDEPENDENT_CODE ON)

# Build only opusfile's local decoding API. HTTP/HTTPS support and opusurl
# are deliberately excluded, so OpenSSL is not required.
add_library(opusfile STATIC
    "${THIRD_PARTY_DIR}/opusfile/src/info.c"
    "${THIRD_PARTY_DIR}/opusfile/src/internal.c"
    "${THIRD_PARTY_DIR}/opusfile/src/opusfile.c"
    "${THIRD_PARTY_DIR}/opusfile/src/stream.c"
)
target_include_directories(opusfile
    PUBLIC "${THIRD_PARTY_DIR}/opusfile/include"
    PRIVATE "${THIRD_PARTY_DIR}/opusfile/src"
)
target_link_libraries(opusfile PUBLIC ogg opus m)
set_target_properties(opusfile PROPERTIES POSITION_INDEPENDENT_CODE ON)

add_library(pianosampledecoder SHARED native_opus_decoder.cpp)
target_link_libraries(pianosampledecoder PRIVATE opusfile ogg opus log m)
target_compile_options(pianosampledecoder PRIVATE -Wall -Wextra)
