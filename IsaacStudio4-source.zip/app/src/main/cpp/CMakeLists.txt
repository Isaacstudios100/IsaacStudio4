cmake_minimum_required(VERSION 3.22.1)
project(IsaacPianoSampleDecoder LANGUAGES C CXX)

set(CMAKE_C_STANDARD 99)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

set(THIRD_PARTY_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party")
foreach(component opus ogg opusfile)
    if(NOT EXISTS "${THIRD_PARTY_DIR}/${component}")
        message(FATAL_ERROR "Missing pinned dependency source: ${component}")
    endif()
endforeach()

# Build the official Xiph libopus as a static library.
set(OPUS_BUILD_SHARED_LIBRARY OFF CACHE BOOL "" FORCE)
set(OPUS_BUILD_TESTING OFF CACHE BOOL "" FORCE)
set(OPUS_BUILD_PROGRAMS OFF CACHE BOOL "" FORCE)
set(OPUS_INSTALL_PKG_CONFIG_MODULE OFF CACHE BOOL "" FORCE)
set(OPUS_INSTALL_CMAKE_CONFIG_MODULE OFF CACHE BOOL "" FORCE)
add_subdirectory("${THIRD_PARTY_DIR}/opus" "${CMAKE_CURRENT_BINARY_DIR}/opus")

# Build the Ogg container library with its official generated type configuration.
include(CheckIncludeFiles)
check_include_files(inttypes.h INCLUDE_INTTYPES_H)
check_include_files(stdint.h INCLUDE_STDINT_H)
check_include_files(sys/types.h INCLUDE_SYS_TYPES_H)

set(SIZE16 int16_t)
set(USIZE16 uint16_t)
set(SIZE32 int32_t)
set(USIZE32 uint32_t)
set(SIZE64 int64_t)
set(USIZE64 uint64_t)

set(OGG_GENERATED_INCLUDE_DIR "${CMAKE_CURRENT_BINARY_DIR}/ogg-generated")
file(MAKE_DIRECTORY "${OGG_GENERATED_INCLUDE_DIR}/ogg")
configure_file(
    "${THIRD_PARTY_DIR}/ogg/include/ogg/config_types.h.in"
    "${OGG_GENERATED_INCLUDE_DIR}/ogg/config_types.h"
    @ONLY
)

add_library(ogg STATIC
    "${THIRD_PARTY_DIR}/ogg/src/bitwise.c"
    "${THIRD_PARTY_DIR}/ogg/src/framing.c"
    "${OGG_GENERATED_INCLUDE_DIR}/ogg/config_types.h"
)
target_include_directories(ogg PUBLIC
    "${THIRD_PARTY_DIR}/ogg/include"
    "${OGG_GENERATED_INCLUDE_DIR}"
)
set_target_properties(ogg PROPERTIES POSITION_INDEPENDENT_CODE ON)

# Build only opusfile's local decoding API. HTTP/HTTPS support and opusurl
# are deliberately excluded, so OpenSSL is not required.
add_library(opusfile STATIC
    "${THIRD_PARTY_DIR}/opusfile/src/info.c"
    "${THIRD_PARTY_DIR}/opusfile/src/internal.c"
    "${THIRD_PARTY_DIR}/opusfile/src/opusfile.c"
    "${THIRD_PARTY_DIR}/opusfile/src/stream.c"
)
target_include_directories(opusfile
    PUBLIC "${THIRD_PARTY_DIR}/opusfile/include"
    PRIVATE "${THIRD_PARTY_DIR}/opusfile/src"
)
target_link_libraries(opusfile PUBLIC ogg opus m)
set_target_properties(opusfile PROPERTIES POSITION_INDEPENDENT_CODE ON)

add_library(pianosampledecoder SHARED native_opus_decoder.cpp)
target_link_libraries(pianosampledecoder PRIVATE opusfile ogg opus log m)
target_compile_options(pianosampledecoder PRIVATE -Wall -Wextra)
