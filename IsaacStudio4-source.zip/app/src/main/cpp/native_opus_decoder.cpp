#include <jni.h>
#include <opusfile.h>
#include <opus_types.h>

#include <cstdint>
#include <limits>

static_assert(sizeof(jshort) == sizeof(opus_int16),
              "JNI short and Opus PCM16 sample sizes must match.");

extern "C"
JNIEXPORT jshortArray JNICALL
Java_com_isaacstudio_studio4_audio_instruments_NativeOpusDecoder_decodeOggToPcm16(
        JNIEnv* env,
        jobject /* receiver */,
        jbyteArray encoded) {
    if (encoded == nullptr) {
        return nullptr;
    }

    const jsize inputSize = env->GetArrayLength(encoded);
    if (inputSize <= 0) {
        return nullptr;
    }

    jbyte* input = env->GetByteArrayElements(encoded, nullptr);
    if (input == nullptr) {
        return nullptr;
    }

    int openError = 0;
    OggOpusFile* file = op_open_memory(
        reinterpret_cast<const unsigned char*>(input),
        static_cast<size_t>(inputSize),
        &openError
    );

    if (file == nullptr) {
        env->ReleaseByteArrayElements(encoded, input, JNI_ABORT);
        return nullptr;
    }

    const int channels = op_channel_count(file, -1);
    const ogg_int64_t totalFrames = op_pcm_total(file, -1);

    // The Meta Piano bank is mono. Accept stereo as a defensive fallback,
    // but reject unexpected multichannel or implausibly long streams.
    constexpr ogg_int64_t MAX_FRAMES = 48'000LL * 120LL;
    if ((channels != 1 && channels != 2) ||
        totalFrames <= 0 ||
        totalFrames > MAX_FRAMES ||
        totalFrames > std::numeric_limits<jsize>::max() / channels) {
        op_free(file);
        env->ReleaseByteArrayElements(encoded, input, JNI_ABORT);
        return nullptr;
    }

    const jsize expectedSamples =
        static_cast<jsize>(totalFrames * channels);
    jshortArray output = env->NewShortArray(expectedSamples);
    if (output == nullptr) {
        op_free(file);
        env->ReleaseByteArrayElements(encoded, input, JNI_ABORT);
        return nullptr;
    }

    opus_int16 pcm[4096 * 2];
    ogg_int64_t framesWritten = 0;
    bool failed = false;

    while (true) {
        const int frames = op_read(file, pcm, 4096 * channels, nullptr);
        if (frames < 0) {
            failed = true;
            break;
        }
        if (frames == 0) {
            break;
        }

        const jsize samples = static_cast<jsize>(frames * channels);
        if (framesWritten + frames > totalFrames) {
            failed = true;
            break;
        }

        env->SetShortArrayRegion(
            output,
            static_cast<jsize>(framesWritten * channels),
            samples,
            reinterpret_cast<const jshort*>(pcm)
        );

        if (env->ExceptionCheck()) {
            failed = true;
            break;
        }
        framesWritten += frames;
    }

    op_free(file);
    env->ReleaseByteArrayElements(encoded, input, JNI_ABORT);

    // Reject incomplete or inconsistent streams rather than returning
    // a sample with silent padding or truncated playback.
    if (failed || framesWritten != totalFrames) {
        env->DeleteLocalRef(output);
        return nullptr;
    }

    return output;
}
