package com.isaacstudio.studio4.audio.performance

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

/**
 * Persistent assignments for the eight live performance program buttons.
 * Stored separately from the performance library.
 */
class ProgramBankStorage(context: Context) {

    companion object {
        private const val SCHEMA_VERSION = 1
        private const val SLOT_COUNT = 8
    }

    private val atomicFile = AtomicFile(
        File(context.filesDir, "program_slots.json")
    )

    @Synchronized
    fun loadSlots(): List<String?> = readSlots()

    @Synchronized
    fun assign(slot: Int, performanceName: String) {
        require(slot in 0 until SLOT_COUNT) { "Invalid program slot." }
        val name = cleanName(performanceName)
        require(name.isNotEmpty()) { "Performance name cannot be empty." }

        val slots = readSlots().toMutableList()
        slots[slot] = name
        writeSlots(slots)
    }

    @Synchronized
    fun clear(slot: Int) {
        require(slot in 0 until SLOT_COUNT) { "Invalid program slot." }

        val slots = readSlots().toMutableList()
        slots[slot] = null
        writeSlots(slots)
    }

    @Synchronized
    fun renamePerformance(oldName: String, newName: String) {
        val old = oldName.trim()
        val new = cleanName(newName)
        require(new.isNotEmpty()) { "Performance name cannot be empty." }

        val slots = readSlots().toMutableList()
        var changed = false
        for (index in slots.indices) {
            if (slots[index]?.equals(old, ignoreCase = true) == true) {
                slots[index] = new
                changed = true
            }
        }
        if (changed) writeSlots(slots)
    }

    @Synchronized
    fun clearPerformance(performanceName: String) {
        val target = performanceName.trim()
        val slots = readSlots().toMutableList()
        var changed = false

        for (index in slots.indices) {
            if (slots[index]?.equals(target, ignoreCase = true) == true) {
                slots[index] = null
                changed = true
            }
        }
        if (changed) writeSlots(slots)
    }

    private fun cleanName(value: String): String =
        value.trim().replace(Regex("\\s+"), " ").take(48)

    private fun readSlots(): List<String?> {
        val root = try {
            atomicFile.openRead().bufferedReader().use {
                JSONObject(it.readText())
            }
        } catch (_: FileNotFoundException) {
            return List(SLOT_COUNT) { null }
        } catch (error: Exception) {
            throw IOException(
                "Program bank is unreadable; original file preserved.",
                error
            )
        }

        val version = root.optInt("schemaVersion", -1)
        if (version != SCHEMA_VERSION) {
            throw IOException("Unsupported program bank version: $version")
        }

        val array = root.optJSONArray("slots")
            ?: throw IOException("Program bank has no slots array.")

        if (array.length() != SLOT_COUNT) {
            throw IOException("Program bank must contain exactly eight slots.")
        }

        return List(SLOT_COUNT) { index ->
            val value = array.get(index)
            when {
                value == JSONObject.NULL -> null
                value is String -> cleanName(value).takeIf { it.isNotEmpty() }
                else -> throw IOException("Invalid value in program slot ${index + 1}.")
            }
        }
    }

    private fun writeSlots(slots: List<String?>) {
        require(slots.size == SLOT_COUNT) {
            "Program bank must contain exactly eight slots."
        }

        val root = JSONObject()
        root.put("schemaVersion", SCHEMA_VERSION)

        val array = JSONArray()
        slots.forEach { name ->
            array.put(name ?: JSONObject.NULL)
        }
        root.put("slots", array)

        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomicFile.startWrite()
            stream.write(root.toString().toByteArray(Charsets.UTF_8))
            stream.fd.sync()
            atomicFile.finishWrite(stream)
        } catch (error: Exception) {
            if (stream != null) atomicFile.failWrite(stream)
            throw IOException("Could not save program bank.", error)
        }
    }
}
