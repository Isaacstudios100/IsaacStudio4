package com.isaacstudio.studio4.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Shared digital wavetable bank.
 *
 * Tables are generated once and reused by all Synth layers.
 * Playback uses linear interpolation and cyclic phase lookup.
 */
object DigitalWavetable {

    private const val TABLE_SIZE = 2048
    private const val TABLE_MASK = TABLE_SIZE - 1
    private const val MORPH_FRAMES = 5

    private val tables: Array<Array<FloatArray>> =
        Array(SynthDigitalWave.values().size) { waveIndex ->
            Array(MORPH_FRAMES) { morphIndex ->
                generateTable(
                    SynthDigitalWave.values()[waveIndex],
                    morphIndex.toFloat() / (MORPH_FRAMES - 1)
                )
            }
        }

    private fun generateTable(
        wave: SynthDigitalWave,
        morph: Float
    ): FloatArray {
        val table = FloatArray(TABLE_SIZE)

        for (i in table.indices) {
            val phase = i.toDouble() / TABLE_SIZE
            val angle = 2.0 * PI * phase

            val value = when (wave) {
                SynthDigitalWave.CLASSIC -> {
                    val harmonics = 2 + (morph * 18f).toInt()
                    var sum = 0.0
                    for (h in 1..harmonics) {
                        sum += sin(angle * h) / h
                    }
                    sum
                }

                SynthDigitalWave.ORGAN -> {
                    val harmonics = 2 + (morph * 7f).toInt()
                    var sum = 0.0
                    for (h in 1..harmonics) {
                        if (h == 1 || h % 2 == 1) {
                            sum += sin(angle * h) / h
                        }
                    }
                    sum
                }

                SynthDigitalWave.FORMANT -> {
                    val center = 2.0 + morph * 7.0
                    sin(angle) * 0.45 +
                        sin(angle * center) * 0.35 +
                        sin(angle * (center + 1.5)) * 0.20
                }

                SynthDigitalWave.VOCAL -> {
                    sin(angle) * 0.45 +
                        sin(angle * 2.0) * (0.25 + morph * 0.15) +
                        sin(angle * 3.0) * 0.20 +
                        sin(angle * 5.0) * (0.10 + morph * 0.10)
                }

                SynthDigitalWave.BELL -> {
                    sin(angle) * 0.55 +
                        sin(angle * 2.76) * 0.25 +
                        sin(angle * 5.4) * 0.20
                }

                SynthDigitalWave.GLASS -> {
                    sin(angle) * 0.55 +
                        sin(angle * (3.0 + morph * 2.0)) * 0.30 +
                        sin(angle * (7.0 + morph * 3.0)) * 0.15
                }

                SynthDigitalWave.COMPLEX -> {
                    sin(angle) * 0.30 +
                        sin(angle * 2.0) * 0.25 +
                        sin(angle * 3.7) * 0.20 +
                        sin(angle * 6.2) * 0.15 +
                        sin(angle * 9.0) * 0.10
                }

                SynthDigitalWave.ADDITIVE -> {
                    var sum = 0.0
                    for (h in 1..12) {
                        val amplitude = 1.0 / h
                        sum += sin(angle * h) * amplitude *
                            (1.0 - morph * (h - 1) / 12.0)
                    }
                    sum
                }
            }

            table[i] = value.toFloat()
        }

        var peak = 0f
        for (sample in table) {
            peak = maxOf(peak, kotlin.math.abs(sample))
        }

        if (peak > 0f) {
            for (i in table.indices) {
                table[i] /= peak
            }
        }

        return table
    }

    /**
     * Read a wavetable using cyclic linear interpolation.
     */
    fun sample(
        phase: Double,
        wave: SynthDigitalWave,
        morph: Float
    ): Double {
        val waveIndex = wave.ordinal
        val position = morph.coerceIn(0f, 1f) * (MORPH_FRAMES - 1)

        val lowerFrame = position.toInt()
        val upperFrame = minOf(lowerFrame + 1, MORPH_FRAMES - 1)
        val blend = position - lowerFrame

        val lower = readTable(
            tables[waveIndex][lowerFrame],
            phase
        )

        val upper = readTable(
            tables[waveIndex][upperFrame],
            phase
        )

        return lower + (upper - lower) * blend
    }

    private fun readTable(
        table: FloatArray,
        phase: Double
    ): Double {
        val wrappedPhase = phase - kotlin.math.floor(phase)
        val position = wrappedPhase * TABLE_SIZE

        val index = position.toInt() and TABLE_MASK
        val nextIndex = (index + 1) and TABLE_MASK
        val fraction = position - position.toInt()

        val first = table[index].toDouble()
        val second = table[nextIndex].toDouble()

        return first + (second - first) * fraction
    }
}
