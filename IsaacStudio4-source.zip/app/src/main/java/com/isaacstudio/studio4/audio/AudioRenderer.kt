package com.isaacstudio.studio4.audio

interface AudioRenderer {

    var isRenderingEnabled: Boolean

    /**
     * Generates audio samples and adds them to the supplied mix buffer.
     * Implementations must preserve their own instrument voice state.
     */
    fun renderInto(buffer: FloatArray)
}
