package com.isaacstudio.studio4.diagnostics

import android.app.Activity
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Bundle
import android.widget.TextView
import java.io.File

class OpusDecoderTestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = TextView(this).apply {
            textSize = 16f
            setPadding(28, 28, 28, 28)
            text = "ISAAC STUDIO 4\n\nTesting Android Opus decoder..."
        }
        setContentView(report)
        Thread({ runDecoderTest(report) }, "OpusDecoderDiagnostic").start()
    }

    private fun runDecoderTest(report: TextView) {
        val lines = StringBuilder()
        fun add(line: String) { lines.append(line).append('\n') }

        var extractor: MediaExtractor? = null
        var codec: MediaCodec? = null
        var codecStarted = false

        try {
            val sampleFile = File(cacheDir, "opus_test.ogg")
            assets.open("diagnostics/opus_test.ogg").use { input ->
                sampleFile.outputStream().use { output -> input.copyTo(output) }
            }
            add("Sample copied: ${sampleFile.length()} bytes")

            val ex = MediaExtractor()
            extractor = ex
            ex.setDataSource(sampleFile.absolutePath)

            var audioTrack = -1
            var trackFormat: MediaFormat? = null

            for (i in 0 until ex.trackCount) {
                val candidate = ex.getTrackFormat(i)
                val trackMime = candidate.getString(MediaFormat.KEY_MIME) ?: continue
                if (trackMime.startsWith("audio/")) {
                    audioTrack = i
                    trackFormat = candidate
                    break
                }
            }

            if (audioTrack < 0 || trackFormat == null) {
                throw IllegalStateException("No audio track found by MediaExtractor")
            }

            val format = trackFormat
            val mime = format.getString(MediaFormat.KEY_MIME)
                ?: throw IllegalStateException("Missing audio MIME type")

            add("Input MIME: $mime")
            add("Input rate: ${format.getInteger(MediaFormat.KEY_SAMPLE_RATE)} Hz")
            add("Input channels: ${format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)}")

            ex.selectTrack(audioTrack)

            val advertised = MediaCodecList(MediaCodecList.ALL_CODECS)
                .findDecoderForFormat(format)
            add("Advertised decoder: ${advertised ?: "none reported"}")

            val decoder = MediaCodec.createDecoderByType(mime)
            codec = decoder
            add("Created decoder: ${decoder.name}")

            decoder.configure(format, null, null, 0)
            decoder.start()
            codecStarted = true

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var outputBytes = 0L
            var outputFormat: MediaFormat? = null
            val startedAt = System.currentTimeMillis()

            while (!outputDone) {
                if (System.currentTimeMillis() - startedAt > 30000L) {
                    throw IllegalStateException("Decoder timed out after 30 seconds")
                }

                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10000L)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex)
                            ?: throw IllegalStateException("Input buffer unavailable")
                        inputBuffer.clear()

                        val size = ex.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(
                                inputIndex, 0, 0, 0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(
                                inputIndex, 0, size,
                                ex.sampleTime.coerceAtLeast(0L), 0
                            )
                            ex.advance()
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(info, 10000L)
                when {
                    outputIndex >= 0 -> {
                        if (info.size > 0) outputBytes += info.size.toLong()
                        val eos = (info.flags and
                            MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        decoder.releaseOutputBuffer(outputIndex, false)
                        if (eos) outputDone = true
                    }
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        outputFormat = decoder.outputFormat
                    }
                }
            }

            val decoded = outputFormat ?: decoder.outputFormat
            val rate = decoded.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = decoded.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val encoding = if (decoded.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                decoded.getInteger(MediaFormat.KEY_PCM_ENCODING)
            } else {
                AudioFormat.ENCODING_PCM_16BIT
            }

            val bytesPerSample = when (encoding) {
                AudioFormat.ENCODING_PCM_8BIT -> 1
                AudioFormat.ENCODING_PCM_16BIT -> 2
                AudioFormat.ENCODING_PCM_FLOAT -> 4
                else -> 0
            }
            val frames = if (bytesPerSample > 0 && channels > 0) {
                outputBytes / (bytesPerSample * channels)
            } else 0L
            val seconds = if (rate > 0) frames.toDouble() / rate else 0.0

            add("")
            add("DECODE RESULT: SUCCESS")
            add("Output rate: $rate Hz")
            add("Output channels: $channels")
            add("PCM encoding: $encoding")
            add("Decoded bytes: $outputBytes")
            add("Decoded frames: $frames")
            add("Decoded duration: ${"%.3f".format(seconds)} seconds")
            add("Elapsed: ${System.currentTimeMillis() - startedAt} ms")
            add("")
            add("No audio was played. Piano engines were not modified.")

        } catch (t: Throwable) {
            add("")
            add("DECODE RESULT: FAILED")
            add("${t.javaClass.simpleName}: ${t.message}")
        } finally {
            try { if (codecStarted) codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { extractor?.release() } catch (_: Throwable) {}
        }

        runOnUiThread { report.text = lines.toString() }
    }
}
