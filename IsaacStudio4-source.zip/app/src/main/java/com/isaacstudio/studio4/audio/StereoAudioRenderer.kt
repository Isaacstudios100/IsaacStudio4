package com.isaacstudio.studio4.audio

interface StereoAudioRenderer {
    var isRenderingEnabled: Boolean

    fun renderStereoInto(
        left: FloatArray,
        right: FloatArray
    )
}
