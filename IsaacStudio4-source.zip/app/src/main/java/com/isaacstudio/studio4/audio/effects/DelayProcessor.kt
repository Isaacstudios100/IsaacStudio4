package com.isaacstudio.studio4.audio.effects

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Independent stereo delay processor owned by one instrument layer.
 *
 * Delay memory and filter states are allocated once during construction.
 * Processing uses persistent buffers and does not allocate per audio block.
 *
 * Tempo sync currently uses a quarter-note delay.
 */
class DelayProcessor(
    private val sampleRate: Float = 44100f
) {
    companion object {
        private const val MAX_DELAY_MS = 2000f
        private const val MAX_FEEDBACK = 0.92f
        private const val TWO_PI = (2.0 * PI).toFloat()
    }

    private val bufferSize = 131072
    private val bufferMask = bufferSize - 1

    private val delayLeft = FloatArray(bufferSize)
    private val delayRight = FloatArray(bufferSize)

    private var writePosition = 0

    private val previousHighPassInput = FloatArray(2)
    private val previousHighPassOutput = FloatArray(2)
    private val lowPassState = FloatArray(2)
    private val analogState = FloatArray(2)
    private val spaceState = FloatArray(2)

    private var modulationPhase = 0f

    /**
     * Processes stereo audio.
     *
     * Input and output arrays may be the same arrays.
     */
    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: DelaySettings
    ) {
        val frameCount = minOf(
            inputLeft.size,
            inputRight.size,
            outputLeft.size,
            outputRight.size
        )

        if (!settings.enabled) {
            for (i in 0 until frameCount) {
                outputLeft[i] = inputLeft[i]
                outputRight[i] = inputRight[i]
            }
            return
        }

        val bpm = settings.tempoBpm.coerceIn(30f, 300f)

        val requestedTimeMs = if (settings.tempoSync) {
            60000f / bpm
        } else {
            settings.timeMs.coerceIn(1f, MAX_DELAY_MS)
        }

        val baseDelaySamples = (
            requestedTimeMs * sampleRate / 1000f
        ).coerceIn(1f, (bufferSize - 2).toFloat())

        val feedback = settings.feedback.coerceIn(0f, MAX_FEEDBACK)
        val mix = settings.mix.coerceIn(0f, 1f)

        val modulationIncrement = TWO_PI * 0.25f / sampleRate
        val modulationDepthSamples = sampleRate * 0.003f

        for (i in 0 until frameCount) {
            // Capture dry samples before writing output.
            // This makes in-place processing safe.
            val dryLeft = inputLeft[i]
            val dryRight = inputRight[i]

            val modulation = sin(modulationPhase)

            modulationPhase += modulationIncrement
            if (modulationPhase >= TWO_PI) {
                modulationPhase -= TWO_PI
            }

            val modulatedDelay = (
                baseDelaySamples +
                    modulation * modulationDepthSamples
            ).coerceIn(1f, (bufferSize - 2).toFloat())

            val delayedLeft = readInterpolated(
                delayLeft,
                writePosition,
                modulatedDelay
            )

            val delayedRight = readInterpolated(
                delayRight,
                writePosition,
                modulatedDelay
            )

            var feedbackLeft = applyFeedbackVariation(
                delayedLeft,
                delayLeft,
                baseDelaySamples,
                modulation,
                0,
                settings.feedbackEffect
            )

            var feedbackRight = applyFeedbackVariation(
                delayedRight,
                delayRight,
                baseDelaySamples,
                modulation,
                1,
                settings.feedbackEffect
            )

            feedbackLeft = applyFeedbackFilter(
                feedbackLeft,
                0,
                settings.filter
            )

            feedbackRight = applyFeedbackFilter(
                feedbackRight,
                1,
                settings.filter
            )

            if (settings.analogMode) {
                feedbackLeft = applyAnalogCharacter(feedbackLeft, 0)
                feedbackRight = applyAnalogCharacter(feedbackRight, 1)
            }

            val nextLeft: Float
            val nextRight: Float

            if (settings.pingPong) {
                // Cross-feedback: left echo feeds right and vice versa.
                nextLeft = dryLeft + feedbackRight * feedback
                nextRight = dryRight + feedbackLeft * feedback
            } else {
                // Conventional independent stereo feedback.
                nextLeft = dryLeft + feedbackLeft * feedback
                nextRight = dryRight + feedbackRight * feedback
            }

            delayLeft[writePosition] = nextLeft
            delayRight[writePosition] = nextRight

            outputLeft[i] =
                dryLeft * (1f - mix) + delayedLeft * mix

            outputRight[i] =
                dryRight * (1f - mix) + delayedRight * mix

            writePosition = (writePosition + 1) and bufferMask
        }
    }

    private fun readInterpolated(
        buffer: FloatArray,
        position: Int,
        delaySamples: Float
    ): Float {
        var readPosition = position.toFloat() - delaySamples

        while (readPosition < 0f) {
            readPosition += bufferSize
        }

        val integerPosition = readPosition.toInt()
        val index = integerPosition and bufferMask
        val nextIndex = (index + 1) and bufferMask
        val fraction = readPosition - integerPosition

        val first = buffer[index]
        val second = buffer[nextIndex]

        return first + (second - first) * fraction
    }

    private fun applyFeedbackVariation(
        input: Float,
        buffer: FloatArray,
        baseDelaySamples: Float,
        modulation: Float,
        channel: Int,
        effect: DelayFeedbackEffect
    ): Float {
        return when (effect) {
            DelayFeedbackEffect.OFF -> input

            DelayFeedbackEffect.CHORUS -> {
                val offset = sampleRate * 0.004f * modulation

                val secondary = readInterpolated(
                    buffer,
                    writePosition,
                    (baseDelaySamples + offset)
                        .coerceIn(1f, (bufferSize - 2).toFloat())
                )

                input * 0.7f + secondary * 0.3f
            }

            DelayFeedbackEffect.FLAM -> {
                val secondary = readInterpolated(
                    buffer,
                    writePosition,
                    (baseDelaySamples + sampleRate * 0.018f)
                        .coerceIn(1f, (bufferSize - 2).toFloat())
                )

                input * 0.65f + secondary * 0.35f
            }

            DelayFeedbackEffect.VIBE -> {
                val offset = sampleRate * 0.002f * modulation

                readInterpolated(
                    buffer,
                    writePosition,
                    (baseDelaySamples + offset)
                        .coerceIn(1f, (bufferSize - 2).toFloat())
                )
            }

            DelayFeedbackEffect.SPACE -> {
                val previous = spaceState[channel]
                val result = previous * 0.65f + input * 0.35f

                spaceState[channel] = result
                result
            }

            DelayFeedbackEffect.ENSEMBLE -> {
                val offset = sampleRate * 0.005f

                val first = readInterpolated(
                    buffer,
                    writePosition,
                    (baseDelaySamples - offset)
                        .coerceIn(1f, (bufferSize - 2).toFloat())
                )

                val second = readInterpolated(
                    buffer,
                    writePosition,
                    (baseDelaySamples + offset)
                        .coerceIn(1f, (bufferSize - 2).toFloat())
                )

                input * 0.5f + (first + second) * 0.25f
            }
        }
    }

    private fun applyFeedbackFilter(
        input: Float,
        channel: Int,
        filter: DelayFilterType
    ): Float {
        return when (filter) {
            DelayFilterType.OFF -> input

            DelayFilterType.LOW_PASS -> {
                val result = lowPassState[channel] +
                    0.22f * (input - lowPassState[channel])

                lowPassState[channel] = result
                result
            }

            DelayFilterType.HIGH_PASS -> {
                val result = 0.995f * (
                    previousHighPassOutput[channel] +
                        input - previousHighPassInput[channel]
                )

                previousHighPassInput[channel] = input
                previousHighPassOutput[channel] = result

                result
            }

            DelayFilterType.BAND_PASS -> {
                val highPassed = 0.995f * (
                    previousHighPassOutput[channel] +
                        input - previousHighPassInput[channel]
                )

                previousHighPassInput[channel] = input
                previousHighPassOutput[channel] = highPassed

                val result = lowPassState[channel] +
                    0.22f * (highPassed - lowPassState[channel])

                lowPassState[channel] = result
                result
            }
        }
    }

    private fun applyAnalogCharacter(
        input: Float,
        channel: Int
    ): Float {
        val smoothed = analogState[channel] +
            0.18f * (input - analogState[channel])

        analogState[channel] = smoothed

        // Gentle nonlinear saturation in the feedback path.
        return smoothed / (1f + abs(smoothed) * 0.35f)
    }

    fun reset() {
        delayLeft.fill(0f)
        delayRight.fill(0f)

        previousHighPassInput.fill(0f)
        previousHighPassOutput.fill(0f)
        lowPassState.fill(0f)
        analogState.fill(0f)
        spaceState.fill(0f)

        writePosition = 0
        modulationPhase = 0f
    }
}
