package com.isaacstudio.studio4.audio.effects

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tanh

class RotarySpeakerProcessor {

    companion object {
        const val STOP = 0
        const val SLOW = 1
        const val FAST = 2

        private const val SAMPLE_RATE = 44100.0
        private const val BUFFER_SIZE = 2048
        private const val BUFFER_MASK = BUFFER_SIZE - 1
    }

    @Volatile
    var mode = STOP

    @Volatile
    var drive = 0.0f

    private val delayBuffer = DoubleArray(BUFFER_SIZE)

    private var writeIndex = 0

    private var hornPhase = 0.0
    private var drumPhase = 0.0

    private var currentHornSpeed = 0.0
    private var currentDrumSpeed = 0.0

    private var hornDelay = 100.0
    private var drumDelay = 150.0

    private fun readDelay(delaySamples: Double): Double {
        val readPosition =
            (writeIndex - delaySamples + BUFFER_SIZE) % BUFFER_SIZE

        val index1 = readPosition.toInt() and BUFFER_MASK
        val index2 = (index1 + 1) and BUFFER_MASK

        val fraction = readPosition - readPosition.toInt()

        return delayBuffer[index1] * (1.0 - fraction) +
                delayBuffer[index2] * fraction
    }

    fun process(
        input: FloatArray,
        left: FloatArray,
        right: FloatArray
    ) {
        val frameCount = minOf(input.size, left.size, right.size)

        val selectedMode = mode.coerceIn(STOP, FAST)
        val driveAmount = drive.coerceIn(0.0f, 1.0f)

        val targetHornSpeed = when (selectedMode) {
            SLOW -> 0.8
            FAST -> 6.7
            else -> 0.0
        }

        val targetDrumSpeed = when (selectedMode) {
            SLOW -> 0.7
            FAST -> 5.7
            else -> 0.0
        }

        for (i in 0 until frameCount) {

            currentHornSpeed +=
                (targetHornSpeed - currentHornSpeed) * 0.00008

            currentDrumSpeed +=
                (targetDrumSpeed - currentDrumSpeed) * 0.00008

            hornPhase +=
                2.0 * PI * currentHornSpeed / SAMPLE_RATE

            drumPhase +=
                2.0 * PI * currentDrumSpeed / SAMPLE_RATE

            if (hornPhase >= 2.0 * PI) {
                hornPhase -= 2.0 * PI
            }

            if (drumPhase >= 2.0 * PI) {
                drumPhase -= 2.0 * PI
            }

            val sample = input[i].toDouble()

            delayBuffer[writeIndex] = sample

            val hornMovement = sin(hornPhase)
            val drumMovement = sin(drumPhase)

            val hornReadDelay =
                100.0 + hornMovement * 35.0

            val drumReadDelay =
                150.0 + drumMovement * 18.0

            hornDelay +=
                (hornReadDelay - hornDelay) * 0.02

            drumDelay +=
                (drumReadDelay - drumDelay) * 0.02

            val hornSignal = readDelay(hornDelay)
            val drumSignal = readDelay(drumDelay)

            val hornAmplitude =
                0.75 + 0.25 * hornMovement

            val drumAmplitude =
                0.85 + 0.15 * drumMovement

            val hornPan = cos(hornPhase)
            val drumPan = cos(drumPhase)

            val hornLeft = (1.0 - hornPan) * 0.5
            val hornRight = (1.0 + hornPan) * 0.5

            val drumLeft = (1.0 - drumPan) * 0.5
            val drumRight = (1.0 + drumPan) * 0.5

            var outputLeft =
                hornSignal * hornAmplitude * hornLeft * 0.65 +
                drumSignal * drumAmplitude * drumLeft * 0.35

            var outputRight =
                hornSignal * hornAmplitude * hornRight * 0.65 +
                drumSignal * drumAmplitude * drumRight * 0.35

            if (selectedMode == STOP &&
                currentHornSpeed < 0.001 &&
                currentDrumSpeed < 0.001
            ) {
                val centeredSignal =
                    hornSignal * 0.65 + drumSignal * 0.35

                outputLeft = centeredSignal
                outputRight = centeredSignal
            }

            if (driveAmount > 0.0f) {
                val saturation = 1.0 + driveAmount * 8.0
                val amount = driveAmount.toDouble()

                outputLeft =
                    outputLeft * (1.0 - amount) +
                    tanh(outputLeft * saturation) * amount

                outputRight =
                    outputRight * (1.0 - amount) +
                    tanh(outputRight * saturation) * amount
            }

            left[i] = outputLeft.toFloat()
            right[i] = outputRight.toFloat()

            writeIndex = (writeIndex + 1) and BUFFER_MASK
        }
    }

    fun reset() {
        delayBuffer.fill(0.0)

        writeIndex = 0

        hornPhase = 0.0
        drumPhase = 0.0

        currentHornSpeed = 0.0
        currentDrumSpeed = 0.0

        hornDelay = 100.0
        drumDelay = 150.0
    }
}
