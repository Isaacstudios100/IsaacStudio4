package com.isaacstudio.studio4.audio

import kotlin.math.PI
import kotlin.math.tan
import kotlin.math.tanh

class SynthFilterProcessor(
    private val sampleRate: Float = 44100f
) {
    private class SvfState {
        var ic1eq = 0f
        var ic2eq = 0f
        var lowpass = 0f
        var bandpass = 0f
        var highpass = 0f

        fun process(input: Float, g: Float, k: Float) {
            val a1 = 1f / (1f + g * (g + k))
            val a2 = g * a1
            val a3 = g * a2

            val v3 = input - ic2eq
            val v1 = a1 * ic1eq + a2 * v3
            val v2 = ic2eq + a2 * ic1eq + a3 * v3

            ic1eq = 2f * v1 - ic1eq
            ic2eq = 2f * v2 - ic2eq

            lowpass = v2
            bandpass = v1
            highpass = input - k * v1 - v2
        }

        fun reset() {
            ic1eq = 0f
            ic2eq = 0f
            lowpass = 0f
            bandpass = 0f
            highpass = 0f
        }
    }

    private val filterA = SvfState()
    private val filterB = SvfState()
    private val filterC = SvfState()
    private val filterD = SvfState()

    private var cachedSettings: SynthFilterSettings? = null
    private var previousMode = SynthFilterMode.BYPASS
    private var g = 0f
    private var k = 1.4142f
    private var resonanceAmount = 0f
    private var driveAmount = 0f
    private var ladderOutput = 0f

    private fun updateSettings(settings: SynthFilterSettings) {
        if (settings == cachedSettings) return

        val safeCutoff = settings.cutoffHz.coerceIn(
            20f,
            (sampleRate * 0.45f).coerceAtLeast(20f)
        )
        val safeResonance = settings.resonance.coerceIn(0f, 1f)
        driveAmount = settings.drive.coerceIn(0f, 1f)

        g = tan((PI * safeCutoff / sampleRate).toDouble()).toFloat()

        val q = 0.707f + safeResonance * 11.293f
        k = 1f / q

        resonanceAmount = safeResonance * 0.8f
        cachedSettings = settings
    }

    private fun applyDrive(input: Float): Float {
        if (driveAmount <= 0.0001f) return input

        val gain = 1f + driveAmount * 12f
        return tanh((input * gain).toDouble()).toFloat()
    }

    fun process(input: Float, settings: SynthFilterSettings): Float {
        if (settings.mode != previousMode) {
            reset()
            previousMode = settings.mode
        }

        if (settings.mode == SynthFilterMode.BYPASS) return input

        updateSettings(settings)

        val drivenInput = applyDrive(input)

        return when (settings.mode) {
            SynthFilterMode.BYPASS -> input

            SynthFilterMode.LOW_PASS_12 -> {
                filterA.process(drivenInput, g, k)
                filterA.lowpass
            }

            SynthFilterMode.LOW_PASS_24 -> {
                filterA.process(drivenInput, g, k)
                filterB.process(filterA.lowpass, g, k)
                filterB.lowpass
            }

            SynthFilterMode.LADDER -> {
                val feedbackInput = drivenInput - resonanceAmount * ladderOutput

                filterA.process(feedbackInput, g, 1.4142f)
                filterB.process(filterA.lowpass, g, 1.4142f)
                filterC.process(filterB.lowpass, g, 1.4142f)
                filterD.process(filterC.lowpass, g, 1.4142f)

                ladderOutput = filterD.lowpass
                ladderOutput
            }

            SynthFilterMode.HIGH_PASS -> {
                filterA.process(drivenInput, g, k)
                filterA.highpass
            }

            SynthFilterMode.BAND_PASS -> {
                filterA.process(drivenInput, g, k)
                filterA.bandpass
            }

            SynthFilterMode.LOW_PASS_BAND_PASS -> {
                filterA.process(drivenInput, g, k)
                0.5f * (filterA.lowpass + filterA.bandpass)
            }
        }
    }

    fun reset() {
        filterA.reset()
        filterB.reset()
        filterC.reset()
        filterD.reset()
        ladderOutput = 0f
    }
}
