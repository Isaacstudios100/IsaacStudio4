package com.isaacstudio.studio4.audio.performance

import com.isaacstudio.studio4.audio.SynthOscillatorSettings
import com.isaacstudio.studio4.audio.SynthFilterSettings
import com.isaacstudio.studio4.audio.SynthModulationSettings
import com.isaacstudio.studio4.audio.Waveform
import com.isaacstudio.studio4.audio.effects.LayerEffectsSettings
import com.isaacstudio.studio4.audio.instruments.LayerId
import com.isaacstudio.studio4.audio.instruments.OrganModel
import com.isaacstudio.studio4.audio.instruments.PianoSoundModel

/**
 * Complete persistent workstation state.
 *
 * Runtime-only data such as active voices, MIDI controller states,
 * oscillator phases and effect buffers is intentionally excluded.
 */
data class PerformanceSnapshot(
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val name: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = createdAtMillis,
    val selectedLayer: LayerId = LayerId.SYNTH_1,
    val masterVolume: Float = 1.0f,
    val organ1AuxEnabled: Boolean = false,
    val organ2AuxEnabled: Boolean = false,
    val rotaryMode: Int = 0,
    val rotaryDrive: Float = 0.0f,
    val rotaryEnabled: Boolean = true,
    val rotaryCloseMic: Boolean = false,
    val rotaryStopMode: Boolean = false,
    val rotaryAngle: Int = 0,
    val layers: Map<LayerId, PerformanceLayer> =
        LayerId.values().associateWith { PerformanceLayer() }
) {
    companion object {
        const val CURRENT_SCHEMA_VERSION = 2
    }
}

/**
 * Persistent settings for one independent workstation layer.
 *
 * Instrument-specific fields coexist in this model so every layer
 * can be restored without depending on the currently selected tab.
 */
data class PerformanceLayer(
    val enabled: Boolean = false,
    val lowKey: Int = 0,
    val highKey: Int = 127,
    val volume: Float = 1.0f,
    val octave: Int = 0,

    // Synth settings
    val waveform: Waveform = Waveform.SAWTOOTH,
    val attack: Float = 0.005f,
    val decay: Float = 0.12f,
    val sustain: Float = 0.7f,
    val release: Float = 0.3f,
    val oscillatorSettings: SynthOscillatorSettings =
        SynthOscillatorSettings(),
    val filterSettings: SynthFilterSettings =
        SynthFilterSettings(),
    val modulationSettings: SynthModulationSettings =
        SynthModulationSettings(),

    // Organ settings
    val organModel: OrganModel = OrganModel.B3,
    val organDrawbars: Map<OrganModel, List<Int>> =
        OrganModel.values().associateWith { model ->
            when (model) {
                OrganModel.B3 ->
                    listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
                OrganModel.B3_BASS ->
                    listOf(8, 0, 0, 0, 0, 0, 0, 0, 0)
                OrganModel.VOX ->
                    listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
                OrganModel.FARFISA ->
                    listOf(1, 0, 1, 0, 0, 0, 0, 0, 0)
                OrganModel.PIPE_1,
                OrganModel.PIPE_2 ->
                    listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
            }
        },
    val organVoxFilterMix: Float = 0.5f,
    val b3PercussionEnabled: Boolean = false,
    val b3PercussionHarmonic: Int = 2,
    val b3PercussionSoft: Boolean = false,
    val b3PercussionFastDecay: Boolean = true,
    val b3PercussionPolyMode: Boolean = false,
    val vibratoChorusMode: Int = 0,
    val rotaryMode: Int = 0,
    val rotaryDrive: Float = 0.0f,
    val rotaryEnabled: Boolean = true,
    val rotaryCloseMic: Boolean = false,
    val rotaryStopMode: Boolean = false,
    val rotaryAngle: Int = 0,

    // Piano settings
    val pianoSoundModel: PianoSoundModel =
        PianoSoundModel.STUDIO_GRAND,

    // Independent effects rack for this layer
    val effects: LayerEffectsSettings = LayerEffectsSettings()
)
