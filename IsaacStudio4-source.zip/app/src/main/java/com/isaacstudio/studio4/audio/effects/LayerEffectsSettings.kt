package com.isaacstudio.studio4.audio.effects

enum class Mod1Type {
    OFF,
    RING_MOD,
    TREMOLO,
    AUTO_PAN,
    AUTO_WAH,
    WAH,
    PUMP
}

enum class Mod2Type {
    OFF,
    CHORUS,
    FLANGER,
    PHASER,
    VIBE,
    ENSEMBLE,
    SPIN
}

enum class DelayFilterType {
    OFF,
    HIGH_PASS,
    BAND_PASS,
    LOW_PASS
}

enum class DelayFeedbackEffect {
    OFF,
    CHORUS,
    FLAM,
    VIBE,
    SPACE,
    ENSEMBLE
}

enum class AmpModel {
    OFF,
    SMALL,
    JC,
    TWIN
}

enum class ReverbType {
    ROOM,
    BOOTH,
    SPRING,
    STAGE,
    HALL,
    CATHEDRAL
}

data class Mod1Settings(
    val enabled: Boolean = false,
    val type: Mod1Type = Mod1Type.OFF,
    val rate: Float = 0.5f,
    val amount: Float = 0.5f,
    val mix: Float = 0.5f,
    val frequency: Float = 0.5f,
    val resonance: Float = 0.2f
)

data class Mod2Settings(
    val enabled: Boolean = false,
    val type: Mod2Type = Mod2Type.OFF,
    val rate: Float = 0.5f,
    val amount: Float = 0.5f,
    val mix: Float = 0.5f,
    val feedback: Float = 0.3f
)

data class DelaySettings(
    val enabled: Boolean = false,
    val timeMs: Float = 375f,
    val tempoSync: Boolean = false,
    val tempoBpm: Float = 120f,
    val feedback: Float = 0.35f,
    val mix: Float = 0.25f,
    val pingPong: Boolean = false,
    val analogMode: Boolean = false,
    val filter: DelayFilterType = DelayFilterType.OFF,
    val feedbackEffect: DelayFeedbackEffect = DelayFeedbackEffect.OFF
)

data class AmpEqSettings(
    val enabled: Boolean = false,
    val ampModel: AmpModel = AmpModel.OFF,
    val drive: Float = 0f,
    val lowPassHz: Float = 20000f,
    val highPassHz: Float = 20f,
    val lowGainDb: Float = 0f,
    val midGainDb: Float = 0f,
    val midFrequencyHz: Float = 1000f,
    val highGainDb: Float = 0f
)

data class CompressorSettings(
    val enabled: Boolean = false,
    val amount: Float = 0.5f,
    val fast: Boolean = false
)

data class ReverbSettings(
    val enabled: Boolean = false,
    val type: ReverbType = ReverbType.ROOM,
    val roomSize: Float = 0.5f,
    val wetMix: Float = 0.25f,
    val bright: Boolean = false,
    val chorale: Boolean = false
)

data class LayerEffectsSettings(
    val mod1: Mod1Settings = Mod1Settings(),
    val mod2: Mod2Settings = Mod2Settings(),
    val delay: DelaySettings = DelaySettings(),
    val ampEq: AmpEqSettings = AmpEqSettings(),
    val compressor: CompressorSettings = CompressorSettings(),
    val reverb: ReverbSettings = ReverbSettings()
)
