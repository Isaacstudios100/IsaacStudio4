package com.isaacstudio.studio4.audio.instruments

enum class LayerId(
    val instrument: InstrumentType,
    val displayName: String
) {
    PIANO_1(InstrumentType.PIANO, "PIANO 1"),
    PIANO_2(InstrumentType.PIANO, "PIANO 2"),

    ORGAN_1(InstrumentType.ORGAN, "ORGAN 1"),
    ORGAN_2(InstrumentType.ORGAN, "ORGAN 2"),

    SYNTH_1(InstrumentType.SYNTH, "SYNTH 1"),
    SYNTH_2(InstrumentType.SYNTH, "SYNTH 2"),
    SYNTH_3(InstrumentType.SYNTH, "SYNTH 3")
}
