package com.isaacstudio.studio4.audio.effects

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tan

/**
 * Per-layer Modulation 1 processor.
 *
 * Supports mono input with stereo output and native stereo input/output.
 * One instance must be used per effects rack.
 */
class Modulation1Processor(
    private val sampleRate: Float = 44100f
) {
    private var lfoPhase = 0.0
    private var ringPhase = 0.0
    private var envelope = 0f

    private var leftIc1eq = 0f
    private var leftIc2eq = 0f
    private var rightIc1eq = 0f
    private var rightIc2eq = 0f

    private var filterG = 0f
    private var filterK = 1.4142f
    private var filterA1 = 1f
    private var filterA2 = 0f
    private var filterA3 = 0f
    private var lastCutoffHz = Float.NaN
    private var lastResonance = Float.NaN

    private fun updateFilter(cutoffHz: Float, resonance: Float) {
        val safeRate = sampleRate.coerceAtLeast(8000f)
        val safeCutoff = cutoffHz.coerceIn(30f, safeRate * 0.40f)
        val safeResonance = resonance.coerceIn(0f, 1f)

        val cutoffChanged =
            lastCutoffHz.isNaN() || abs(safeCutoff - lastCutoffHz) >= 8f
        val resonanceChanged =
            lastResonance.isNaN() || safeResonance != lastResonance

        if (cutoffChanged) {
            filterG = tan((PI * safeCutoff / safeRate).toDouble()).toFloat()
            lastCutoffHz = safeCutoff
        }

        if (cutoffChanged || resonanceChanged) {
            val q = 0.707f + safeResonance * 9.293f
            filterK = 1f / q

            filterA1 = 1f / (1f + filterG * (filterG + filterK))
            filterA2 = filterG * filterA1
            filterA3 = filterG * filterA2
            lastResonance = safeResonance
        }
    }

    private fun processBandPass(input: Float, isLeft: Boolean): Float {
        if (isLeft) {
            val v3 = input - leftIc2eq
            val v1 = filterA1 * leftIc1eq + filterA2 * v3
            val v2 = leftIc2eq + filterA2 * leftIc1eq + filterA3 * v3

            leftIc1eq = 2f * v1 - leftIc1eq
            leftIc2eq = 2f * v2 - leftIc2eq
            return v1
        }

        val v3 = input - rightIc2eq
        val v1 = filterA1 * rightIc1eq + filterA2 * v3
        val v2 = rightIc2eq + filterA2 * rightIc1eq + filterA3 * v3

        rightIc1eq = 2f * v1 - rightIc1eq
        rightIc2eq = 2f * v2 - rightIc2eq
        return v1
    }

    /**
     * Mono input, stereo output.
     * Output buffers are overwritten, not accumulated.
     */
    fun process(
        input: FloatArray,
        left: FloatArray,
        right: FloatArray,
        settings: Mod1Settings
    ) {
        processStereo(input, input, left, right, settings)
    }

    /**
     * Native stereo input and stereo output.
     * LFO and ring phases advance once per frame, shared by both channels.
     * Filter state remains independent for left and right.
     *
     * Output buffers are overwritten, not accumulated.
     */
    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: Mod1Settings
    ) {
        val frameCount = minOf(
            inputLeft.size,
            inputRight.size,
            outputLeft.size,
            outputRight.size
        )
        if (frameCount <= 0) return

        if (!settings.enabled || settings.type == Mod1Type.OFF) {
            for (i in 0 until frameCount) {
                outputLeft[i] = inputLeft[i]
                outputRight[i] = inputRight[i]
            }
            return
        }

        val rate = 0.05f + settings.rate.coerceIn(0f, 1f) * 11.95f
        val amount = settings.amount.coerceIn(0f, 1f)
        val mix = settings.mix.coerceIn(0f, 1f)
        val frequency = settings.frequency.coerceIn(0f, 1f)
        val resonance = settings.resonance.coerceIn(0f, 1f)
        val safeRate = sampleRate.coerceAtLeast(8000f)

        val lfoIncrement = 2.0 * PI * rate / safeRate
        val ringFrequency = 20f + frequency * 1980f
        val ringIncrement = 2.0 * PI * ringFrequency / safeRate

        val envelopeAttack = 1f - exp(-1f / (0.010f * safeRate))
        val envelopeRelease = 1f - exp(-1f / (0.120f * safeRate))

        for (i in 0 until frameCount) {
            val dryLeft = inputLeft[i]
            val dryRight = inputRight[i]

            val lfo = sin(lfoPhase).toFloat()
            lfoPhase += lfoIncrement
            if (lfoPhase >= 2.0 * PI) lfoPhase -= 2.0 * PI

            var processedLeft = dryLeft
            var processedRight = dryRight

            when (settings.type) {
                Mod1Type.TREMOLO -> {
                    val gain = 1f - amount * 0.5f * (lfo + 1f)
                    processedLeft = dryLeft * gain
                    processedRight = dryRight * gain
                }

                Mod1Type.PUMP -> {
                    val duck = 0.5f * (lfo + 1f)
                    val gain = 1f - amount * duck
                    processedLeft = dryLeft * gain
                    processedRight = dryRight * gain
                }

                Mod1Type.AUTO_PAN -> {
                    val pan = (0.5f + 0.5f * amount * lfo).coerceIn(0f, 1f)

                    val leftGain: Float
                    val rightGain: Float

                    if (pan < 0.5f) {
                        leftGain = 1f
                        rightGain = pan * 2f
                    } else {
                        leftGain = (1f - pan) * 2f
                        rightGain = 1f
                    }

                    processedLeft = dryLeft * leftGain
                    processedRight = dryRight * rightGain
                }

                Mod1Type.RING_MOD -> {
                    val carrier = sin(ringPhase).toFloat()
                    ringPhase += ringIncrement
                    if (ringPhase >= 2.0 * PI) ringPhase -= 2.0 * PI

                    val ringGain = 1f - amount + amount * carrier
                    processedLeft = dryLeft * ringGain
                    processedRight = dryRight * ringGain
                }

                Mod1Type.WAH -> {
                    if ((i and 15) == 0) {
                    val baseHz = 250f + frequency * 3750f
                    val sweep = lfo * amount * 1.8f
                    val cutoff = baseHz * exp(0.69314718056f * sweep)

                    updateFilter(cutoff, resonance)
                    }
                    processedLeft = processBandPass(dryLeft, true)
                    processedRight = processBandPass(dryRight, false)
                }

                Mod1Type.AUTO_WAH -> {
                    val magnitude = (abs(dryLeft) + abs(dryRight)) * 0.5f
                    val coefficient = if (magnitude > envelope) {
                        envelopeAttack
                    } else {
                        envelopeRelease
                    }

                    envelope += coefficient * (magnitude - envelope)

                    if ((i and 15) == 0) {
                    val baseHz = 180f + frequency * 900f
                    val cutoff = baseHz + envelope * amount * 9000f

                    updateFilter(cutoff, resonance)
                    }
                    processedLeft = processBandPass(dryLeft, true)
                    processedRight = processBandPass(dryRight, false)
                }

                Mod1Type.OFF -> Unit
            }

            outputLeft[i] = dryLeft * (1f - mix) + processedLeft * mix
            outputRight[i] = dryRight * (1f - mix) + processedRight * mix
        }
    }

    fun reset() {
        lfoPhase = 0.0
        ringPhase = 0.0
        envelope = 0f

        leftIc1eq = 0f
        leftIc2eq = 0f
        rightIc1eq = 0f
        rightIc2eq = 0f

        filterG = 0f
        filterK = 1.4142f
        filterA1 = 1f
        filterA2 = 0f
        filterA3 = 0f
        lastCutoffHz = Float.NaN
        lastResonance = Float.NaN
    }
}
