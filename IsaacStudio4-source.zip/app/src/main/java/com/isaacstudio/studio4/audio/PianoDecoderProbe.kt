package com.isaacstudio.studio4.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.TimeUnit

object PianoDecoderProbe {

    private val samples = listOf(
        "INSPiano_Vel01_C4_01.ogg",
        "INSPiano_Vel03_C4_01.ogg",
        "INSPiano_Vel04_C4_01.ogg"
    )

    fun run(context: Context, callback: (String) -> Unit) {
        Thread({
            val results = mutableListOf<String>()

            for (sample in samples) {
                results += try {
                    decodeSample(context, sample)
                } catch (error: Exception) {
                    "$sample: FAIL (${error.javaClass.simpleName}: ${error.message ?: "Unknown error"})"
                }
            }

            val passed = results.count { it.contains(": PASS") }
            val report = buildString {
                append("Opus decoder: $passed/${samples.size} passed")
                results.forEach {
                    append("\n")
                    append(it)
                }
            }

            Handler(Looper.getMainLooper()).post {
                callback(report)
            }
        }, "Piano-Opus-Decoder-Probe").start()
    }

    private fun decodeSample(context: Context, sample: String): String {
        val tempFile = File.createTempFile("piano_probe_", ".ogg", context.cacheDir)
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null

        try {
            context.assets.open("meta-piano/ogg/$sample").use { input ->
                tempFile.outputStream().use { output -> input.copyTo(output) }
            }

            extractor.setDataSource(tempFile.absolutePath)

            var audioTrack = -1
            var format: MediaFormat? = null

            for (index in 0 until extractor.trackCount) {
                val candidate = extractor.getTrackFormat(index)
                val mime = candidate.getString(MediaFormat.KEY_MIME) ?: continue

                if (mime.contains("opus", ignoreCase = true)) {
                    audioTrack = index
                    format = candidate
                    break
                }
            }

            check(audioTrack >= 0 && format != null) {
                "No Opus audio track found"
            }

            val selectedFormat = requireNotNull(format)
            val mime = selectedFormat.getString(MediaFormat.KEY_MIME)!!
            extractor.selectTrack(audioTrack)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(selectedFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputEnded = false
            var outputEnded = false
            var decodedBytes = 0L
            var outputRate = 0
            var outputChannels = 0
            var pcmEncoding = -1
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(15)

            while (!outputEnded && System.nanoTime() < deadline) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)

                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex)
                        check(inputBuffer != null) { "Decoder input buffer unavailable" }
                        inputBuffer.clear()

                        val sampleSize = extractor.readSampleData(inputBuffer, 0)

                        if (sampleSize < 0) {
                            codec.queueInputBuffer(
                                inputIndex, 0, 0, 0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputEnded = true
                        } else {
                            codec.queueInputBuffer(
                                inputIndex, 0, sampleSize,
                                extractor.sampleTime, 0
                            )
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outputFormat = codec.outputFormat
                        outputRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        outputChannels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                            pcmEncoding = outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        }
                    }

                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit

                    else -> if (outputIndex >= 0) {
                        if (info.size > 0) {
                            decodedBytes += info.size.toLong()
                        }

                        outputEnded =
                            (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0

                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }

            check(outputEnded) { "Decoder timed out before end of stream" }
            check(decodedBytes > 0L) { "Decoder produced no PCM data" }

            return "$sample: PASS | ${decodedBytes} PCM bytes | ${outputRate}Hz | ${outputChannels}ch | PCM=$pcmEncoding"

        } finally {
            try {
                codec?.stop()
            } catch (_: Exception) {
            }
            codec?.release()
            extractor.release()
            tempFile.delete()
        }
    }
}
