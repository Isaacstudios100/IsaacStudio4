package com.isaacstudio.studio4.audio.effects

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Per-layer stereo Modulation 2 processor.
 *
 * Each effects rack must own one persistent instance.
 * All delay buffers and filter states are allocated once.
 */
class Modulation2Processor(
    private val sampleRate: Float = 44100f
) {
    companion object {
        private const val BUFFER_SIZE = 4096
        private const val BUFFER_MASK = BUFFER_SIZE - 1
        private const val ALL_PASS_STAGES = 6
    }

    private val delayLeft = FloatArray(BUFFER_SIZE)
    private val delayRight = FloatArray(BUFFER_SIZE)
    private var writePosition = 0

    private var lfoPhase = 0.0
    private var ensemblePhase2 = 0.0
    private var ensemblePhase3 = 0.0

    private val leftAllPass = FloatArray(ALL_PASS_STAGES)
    private val rightAllPass = FloatArray(ALL_PASS_STAGES)

    private var lastAllPassCoefficient = Float.NaN
    private var feedbackLeft = 0f
    private var feedbackRight = 0f

    private fun readDelay(buffer: FloatArray, delaySamples: Float): Float {
        val delay = delaySamples.coerceIn(1f, BUFFER_SIZE - 2f)
        val whole = delay.toInt()
        val fraction = delay - whole

        val index1 = (writePosition - whole) and BUFFER_MASK
        val index2 = (index1 - 1) and BUFFER_MASK

        val first = buffer[index1]
        val second = buffer[index2]

        return first + (second - first) * fraction
    }

    private fun allPass(
        input: Float,
        states: FloatArray,
        coefficient: Float
    ): Float {
        var output = input
        val a = coefficient.coerceIn(-0.95f, 0.95f)

        for (stage in 0 until ALL_PASS_STAGES) {
            val previous = output
            output = -a * previous + states[stage]
            states[stage] = previous + a * output
        }

        return output
    }

    fun process(
        input: FloatArray,
        left: FloatArray,
        right: FloatArray,
        settings: Mod2Settings
    ) {
        processStereo(input, input, left, right, settings)
    }

    /**
     * Native stereo processing.
     * Output buffers are overwritten, not accumulated.
     */
    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: Mod2Settings
    ) {
        val frameCount = minOf(
            inputLeft.size,
            inputRight.size,
            outputLeft.size,
            outputRight.size
        )

        if (frameCount <= 0) return

        if (!settings.enabled || settings.type == Mod2Type.OFF) {
            for (i in 0 until frameCount) {
                outputLeft[i] = inputLeft[i]
                outputRight[i] = inputRight[i]
            }
            return
        }

        val safeRate = sampleRate.coerceAtLeast(8000f)
        val rate = 0.05f + settings.rate.coerceIn(0f, 1f) * 9.95f
        val amount = settings.amount.coerceIn(0f, 1f)
        val mix = settings.mix.coerceIn(0f, 1f)
        val feedback = settings.feedback.coerceIn(0f, 0.85f)

        val increment = 2.0 * PI * rate / safeRate

        for (i in 0 until frameCount) {
            val dryLeft = inputLeft[i]
            val dryRight = inputRight[i]

            val lfo = sin(lfoPhase).toFloat()
            val lfo2 = sin(ensemblePhase2).toFloat()
            val lfo3 = sin(ensemblePhase3).toFloat()

            lfoPhase += increment
            ensemblePhase2 += increment * 1.13
            ensemblePhase3 += increment * 0.87

            if (lfoPhase >= 2.0 * PI) lfoPhase -= 2.0 * PI
            if (ensemblePhase2 >= 2.0 * PI) ensemblePhase2 -= 2.0 * PI
            if (ensemblePhase3 >= 2.0 * PI) ensemblePhase3 -= 2.0 * PI

            var wetLeft = dryLeft
            var wetRight = dryRight

            when (settings.type) {
                Mod2Type.CHORUS -> {
                    val baseDelay = safeRate * 0.012f
                    val depth = safeRate * 0.008f * amount

                    val delayL = baseDelay + depth * lfo
                    val delayR = baseDelay + depth * -lfo

                    wetLeft = readDelay(delayLeft, delayL)
                    wetRight = readDelay(delayRight, delayR)

                    delayLeft[writePosition] =
                        dryLeft + wetLeft * feedback * 0.25f
                    delayRight[writePosition] =
                        dryRight + wetRight * feedback * 0.25f
                }

                Mod2Type.FLANGER -> {
                    val baseDelay = safeRate * 0.0015f
                    val depth = safeRate * 0.0035f * amount

                    val delayL = baseDelay + depth * (0.5f + 0.5f * lfo)
                    val delayR = baseDelay + depth * (0.5f - 0.5f * lfo)

                    wetLeft = readDelay(delayLeft, delayL)
                    wetRight = readDelay(delayRight, delayR)

                    delayLeft[writePosition] =
                        dryLeft + wetLeft * feedback
                    delayRight[writePosition] =
                        dryRight + wetRight * feedback
                }

                Mod2Type.PHASER -> {
                    val coefficient = 0.15f + 0.78f *
                        (0.5f + 0.5f * lfo) * amount

                    wetLeft = allPass(dryLeft, leftAllPass, coefficient)
                    wetRight = allPass(dryRight, rightAllPass, coefficient)
                }

                Mod2Type.VIBE -> {
                    val coefficient = -0.80f + 1.60f *
                        (0.5f + 0.5f * lfo) * amount

                    wetLeft = allPass(dryLeft, leftAllPass, coefficient)
                    wetRight = allPass(dryRight, rightAllPass, -coefficient)
                }

                Mod2Type.ENSEMBLE -> {
                    val baseDelay = safeRate * 0.014f
                    val depth = safeRate * 0.006f * amount

                    val tap1L = readDelay(
                        delayLeft, baseDelay + depth * lfo
                    )
                    val tap2L = readDelay(
                        delayLeft, baseDelay * 1.35f + depth * lfo2
                    )
                    val tap3L = readDelay(
                        delayLeft, baseDelay * 1.70f + depth * lfo3
                    )

                    val tap1R = readDelay(
                        delayRight, baseDelay - depth * lfo
                    )
                    val tap2R = readDelay(
                        delayRight, baseDelay * 1.35f - depth * lfo2
                    )
                    val tap3R = readDelay(
                        delayRight, baseDelay * 1.70f - depth * lfo3
                    )

                    wetLeft = (tap1L + tap2L + tap3L) / 3f
                    wetRight = (tap1R + tap2R + tap3R) / 3f

                    delayLeft[writePosition] = dryLeft
                    delayRight[writePosition] = dryRight
                }

                Mod2Type.SPIN -> {
                    val baseDelay = safeRate * 0.002f
                    val depth = safeRate * 0.003f * amount

                    val delayL = baseDelay + depth * (0.5f + 0.5f * lfo)
                    val delayR = baseDelay + depth * (0.5f - 0.5f * lfo)

                    val delayedLeft = readDelay(delayLeft, delayL)
                    val delayedRight = readDelay(delayRight, delayR)

                    val pan = 0.5f + 0.5f * lfo * amount
                    val leftGain = 1f - 0.35f * pan
                    val rightGain = 0.65f + 0.35f * pan

                    wetLeft = delayedLeft * leftGain +
                        delayedRight * (1f - leftGain) * 0.35f
                    wetRight = delayedRight * rightGain +
                        delayedLeft * (1f - rightGain) * 0.35f

                    delayLeft[writePosition] =
                        dryLeft + delayedLeft * feedback * 0.3f
                    delayRight[writePosition] =
                        dryRight + delayedRight * feedback * 0.3f
                }

                Mod2Type.OFF -> Unit
            }

            if (
                settings.type == Mod2Type.CHORUS ||
                settings.type == Mod2Type.FLANGER ||
                settings.type == Mod2Type.ENSEMBLE ||
                settings.type == Mod2Type.SPIN
            ) {
                writePosition = (writePosition + 1) and BUFFER_MASK
            }

            outputLeft[i] = dryLeft * (1f - mix) + wetLeft * mix
            outputRight[i] = dryRight * (1f - mix) + wetRight * mix
        }
    }

    fun reset() {
        delayLeft.fill(0f)
        delayRight.fill(0f)
        leftAllPass.fill(0f)
        rightAllPass.fill(0f)

        writePosition = 0
        lfoPhase = 0.0
        ensemblePhase2 = 0.0
        ensemblePhase3 = 0.0

        lastAllPassCoefficient = Float.NaN
        feedbackLeft = 0f
        feedbackRight = 0f
    }
}
