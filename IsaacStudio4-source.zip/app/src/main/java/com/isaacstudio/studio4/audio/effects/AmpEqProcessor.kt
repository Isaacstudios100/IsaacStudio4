package com.isaacstudio.studio4.audio.effects

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Independent stereo amplifier and equalizer processor.
 *
 * One persistent instance belongs to each instrument layer's effects rack.
 * Filter state and amp coloration state are retained between audio blocks.
 * Coefficients are recalculated only when settings change.
 *
 * Processing is allocation-free after construction.
 */
class AmpEqProcessor(
    private val sampleRate: Float = 44100f
) {
    private class Biquad {
        private var b0 = 1f
        private var b1 = 0f
        private var b2 = 0f
        private var a1 = 0f
        private var a2 = 0f

        private var x1 = 0f
        private var x2 = 0f
        private var y1 = 0f
        private var y2 = 0f

        fun set(
            nb0: Float,
            nb1: Float,
            nb2: Float,
            a0: Float,
            na1: Float,
            na2: Float
        ) {
            if (abs(a0) < 0.0000001f) return

            b0 = nb0 / a0
            b1 = nb1 / a0
            b2 = nb2 / a0
            a1 = na1 / a0
            a2 = na2 / a0
        }

        fun setLowPass(frequency: Float, rate: Float) {
            val omega = 2f * PI.toFloat() * frequency / rate
            val c = cos(omega)
            val s = sin(omega)
            val alpha = s / (2f * 0.70710678f)

            set(
                (1f - c) * 0.5f,
                1f - c,
                (1f - c) * 0.5f,
                1f + alpha,
                -2f * c,
                1f - alpha
            )
        }

        fun setHighPass(frequency: Float, rate: Float) {
            val omega = 2f * PI.toFloat() * frequency / rate
            val c = cos(omega)
            val s = sin(omega)
            val alpha = s / (2f * 0.70710678f)

            set(
                (1f + c) * 0.5f,
                -(1f + c),
                (1f + c) * 0.5f,
                1f + alpha,
                -2f * c,
                1f - alpha
            )
        }

        fun setPeaking(
            frequency: Float,
            gainDb: Float,
            rate: Float
        ) {
            if (abs(gainDb) < 0.0001f) {
                set(1f, 0f, 0f, 1f, 0f, 0f)
                return
            }

            val a = 10f.pow(gainDb / 40f)
            val omega = 2f * PI.toFloat() * frequency / rate
            val c = cos(omega)
            val alpha = sin(omega) / (2f * 0.9f)

            set(
                1f + alpha * a,
                -2f * c,
                1f - alpha * a,
                1f + alpha / a,
                -2f * c,
                1f - alpha / a
            )
        }

        fun setLowShelf(
            frequency: Float,
            gainDb: Float,
            rate: Float
        ) {
            if (abs(gainDb) < 0.0001f) {
                set(1f, 0f, 0f, 1f, 0f, 0f)
                return
            }

            val a = 10f.pow(gainDb / 40f)
            val omega = 2f * PI.toFloat() * frequency / rate
            val c = cos(omega)
            val s = sin(omega)
            val alpha = s * 0.5f * 1.41421356f
            val beta = 2f * sqrt(a) * alpha

            set(
                a * ((a + 1f) - (a - 1f) * c + beta),
                2f * a * ((a - 1f) - (a + 1f) * c),
                a * ((a + 1f) - (a - 1f) * c - beta),
                (a + 1f) + (a - 1f) * c + beta,
                -2f * ((a - 1f) + (a + 1f) * c),
                (a + 1f) + (a - 1f) * c - beta
            )
        }

        fun setHighShelf(
            frequency: Float,
            gainDb: Float,
            rate: Float
        ) {
            if (abs(gainDb) < 0.0001f) {
                set(1f, 0f, 0f, 1f, 0f, 0f)
                return
            }

            val a = 10f.pow(gainDb / 40f)
            val omega = 2f * PI.toFloat() * frequency / rate
            val c = cos(omega)
            val s = sin(omega)
            val alpha = s * 0.5f * 1.41421356f
            val beta = 2f * sqrt(a) * alpha

            set(
                a * ((a + 1f) + (a - 1f) * c + beta),
                -2f * a * ((a - 1f) + (a + 1f) * c),
                a * ((a + 1f) + (a - 1f) * c - beta),
                (a + 1f) - (a - 1f) * c + beta,
                2f * ((a - 1f) - (a + 1f) * c),
                (a + 1f) - (a - 1f) * c - beta
            )
        }

        fun process(input: Float): Float {
            val output =
                b0 * input +
                b1 * x1 +
                b2 * x2 -
                a1 * y1 -
                a2 * y2

            x2 = x1
            x1 = input
            y2 = y1
            y1 = output

            return output
        }

        fun reset() {
            x1 = 0f
            x2 = 0f
            y1 = 0f
            y2 = 0f
        }
    }

    private val safeSampleRate = sampleRate.coerceAtLeast(8000f)
    private val nyquist = safeSampleRate * 0.49f

    private val highPassLeft = Biquad()
    private val highPassRight = Biquad()
    private val lowPassLeft = Biquad()
    private val lowPassRight = Biquad()

    private val lowEqLeft = Biquad()
    private val lowEqRight = Biquad()
    private val midEqLeft = Biquad()
    private val midEqRight = Biquad()
    private val highEqLeft = Biquad()
    private val highEqRight = Biquad()

    private var cachedHighPass = Float.NaN
    private var cachedLowPass = Float.NaN
    private var cachedLowGain = Float.NaN
    private var cachedMidGain = Float.NaN
    private var cachedMidFrequency = Float.NaN
    private var cachedHighGain = Float.NaN

    private var cachedModel = AmpModel.OFF
    private var cachedDrive = Float.NaN

    private var leftLowState = 0f
    private var rightLowState = 0f
    private var leftHighState = 0f
    private var rightHighState = 0f



    private var modelLowAmount = 0f
    private var modelHighAmount = 0f
    private var modelDriveAmount = 0f

    /**
     * Processes stereo audio. Input and output arrays may be identical.
     * Output buffers are overwritten, not accumulated.
     */
    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: AmpEqSettings
    ) {
        val frameCount = minOf(
            inputLeft.size,
            inputRight.size,
            outputLeft.size,
            outputRight.size
        )

        if (frameCount <= 0) return

        if (!settings.enabled) {
            for (i in 0 until frameCount) {
                outputLeft[i] = inputLeft[i]
                outputRight[i] = inputRight[i]
            }
            return
        }

        updateCoefficients(settings)

        for (i in 0 until frameCount) {
            val dryLeft = inputLeft[i]
            val dryRight = inputRight[i]

            var left = highPassLeft.process(dryLeft)
            var right = highPassRight.process(dryRight)

            left = lowPassLeft.process(left)
            right = lowPassRight.process(right)

            left = lowEqLeft.process(left)
            right = lowEqRight.process(right)

            left = midEqLeft.process(left)
            right = midEqRight.process(right)

            left = highEqLeft.process(left)
            right = highEqRight.process(right)

            if (cachedModel != AmpModel.OFF) {
                left = applyAmpCharacter(left, true)
                right = applyAmpCharacter(right, false)
            }

            if (modelDriveAmount > 0f) {
                left = applyDrive(left, modelDriveAmount)
                right = applyDrive(right, modelDriveAmount)
            }

            outputLeft[i] = left
            outputRight[i] = right
        }
    }

    private fun updateCoefficients(settings: AmpEqSettings) {
        val highPass = settings.highPassHz.coerceIn(20f, nyquist)
        val lowPass = settings.lowPassHz.coerceIn(20f, nyquist)
        val lowGain = settings.lowGainDb.coerceIn(-18f, 18f)
        val midGain = settings.midGainDb.coerceIn(-18f, 18f)
        val midFrequency = settings.midFrequencyHz.coerceIn(40f, nyquist)
        val highGain = settings.highGainDb.coerceIn(-18f, 18f)

        if (highPass != cachedHighPass) {
            highPassLeft.setHighPass(highPass, safeSampleRate)
            highPassRight.setHighPass(highPass, safeSampleRate)
            cachedHighPass = highPass
        }

        if (lowPass != cachedLowPass) {
            lowPassLeft.setLowPass(lowPass, safeSampleRate)
            lowPassRight.setLowPass(lowPass, safeSampleRate)
            cachedLowPass = lowPass
        }

        if (lowGain != cachedLowGain) {
            lowEqLeft.setLowShelf(180f, lowGain, safeSampleRate)
            lowEqRight.setLowShelf(180f, lowGain, safeSampleRate)
            cachedLowGain = lowGain
        }

        if (midGain != cachedMidGain || midFrequency != cachedMidFrequency) {
            midEqLeft.setPeaking(midFrequency, midGain, safeSampleRate)
            midEqRight.setPeaking(midFrequency, midGain, safeSampleRate)
            cachedMidGain = midGain
            cachedMidFrequency = midFrequency
        }

        if (highGain != cachedHighGain) {
            highEqLeft.setHighShelf(5000f.coerceAtMost(nyquist), highGain, safeSampleRate)
            highEqRight.setHighShelf(5000f.coerceAtMost(nyquist), highGain, safeSampleRate)
            cachedHighGain = highGain
        }

        val drive = settings.drive.coerceIn(0f, 1f)
        val model = settings.ampModel

        if (drive != cachedDrive || model != cachedModel) {
            cachedDrive = drive
            cachedModel = model

            when (model) {
                AmpModel.OFF -> {
                    modelLowAmount = 0f
                    modelHighAmount = 0f
                    // Generic saturation remains available without amp coloration.
                    modelDriveAmount = drive * 0.50f
                }

                AmpModel.SMALL -> {
                    modelLowAmount = -0.20f
                    modelHighAmount = -0.16f
                    modelDriveAmount = drive * 0.65f
                }

                AmpModel.JC -> {
                    modelLowAmount = -0.025f
                    modelHighAmount = 0.09f
                    modelDriveAmount = drive * 0.35f
                }

                AmpModel.TWIN -> {
                    modelLowAmount = 0.07f
                    modelHighAmount = 0.13f
                    modelDriveAmount = drive * 0.50f
                }
            }
        }
    }

    private fun applyAmpCharacter(input: Float, left: Boolean): Float {
        val lowCoefficient = 0.015f
        val highCoefficient = 0.12f

        return if (left) {
            leftLowState += lowCoefficient * (input - leftLowState)
            leftHighState += highCoefficient * (input - leftHighState)

            input +
                leftLowState * modelLowAmount +
                (input - leftHighState) * modelHighAmount
        } else {
            rightLowState += lowCoefficient * (input - rightLowState)
            rightHighState += highCoefficient * (input - rightHighState)

            input +
                rightLowState * modelLowAmount +
                (input - rightHighState) * modelHighAmount
        }
    }

    private fun applyDrive(input: Float, amount: Float): Float {
        val gain = 1f + amount * 5f
        val driven = input * gain
        val saturated = driven / (1f + abs(driven) * 0.35f)
        return saturated / (1f + amount * 1.75f)
    }

    fun reset() {
        highPassLeft.reset()
        highPassRight.reset()
        lowPassLeft.reset()
        lowPassRight.reset()

        lowEqLeft.reset()
        lowEqRight.reset()
        midEqLeft.reset()
        midEqRight.reset()
        highEqLeft.reset()
        highEqRight.reset()

        leftLowState = 0f
        rightLowState = 0f
        leftHighState = 0f
        rightHighState = 0f
    }
}
