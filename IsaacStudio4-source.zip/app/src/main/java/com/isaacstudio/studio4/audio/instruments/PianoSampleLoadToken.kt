package com.isaacstudio.studio4.audio.instruments

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Tracks one asynchronous sample request for one voice generation.
 *
 * Cancellation is safe even when the request handle has not yet returned
 * from PianoSampleBank.requestSample().
 */
internal class PianoSampleLoadToken {
    private val cancelled = AtomicBoolean(false)
    private val request = AtomicReference<PianoSampleRequest?>(null)

    val isCancelled: Boolean
        get() = cancelled.get()

    fun attach(handle: PianoSampleRequest) {
        if (!request.compareAndSet(null, handle)) {
            handle.cancel()
            return
        }

        if (cancelled.get()) {
            handle.cancel()
        }
    }

    fun cancel() {
        cancelled.set(true)
        request.get()?.cancel()
    }
}
