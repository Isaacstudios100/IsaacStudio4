package com.isaacstudio.studio4.audio.effects

import com.isaacstudio.studio4.audio.instruments.LayerId

/**
 * Holds the independent effect settings for one instrument layer.
 *
 * Settings are immutable snapshots. The UI publishes a replacement snapshot,
 * while the audio engine can read the current snapshot without taking a lock.
 */
class LayerEffectsRack {

    // Persistent DSP state owned exclusively by this layer.
    val modulation1Processor = Modulation1Processor()
    val modulation2Processor = Modulation2Processor()

    @Volatile
    var settings: LayerEffectsSettings = LayerEffectsSettings()
        private set

    fun updateSettings(newSettings: LayerEffectsSettings) {
        settings = newSettings
    }
}

/**
 * Owns exactly one independent effects rack for every LayerId.
 *
 * Rack instances are created once and retained for the lifetime of this
 * manager. Updating one layer never changes another layer's settings.
 */
class LayerEffectsRackManager {

    private val racks: Map<LayerId, LayerEffectsRack> =
        LayerId.values().associateWith { LayerEffectsRack() }

    fun rackFor(layerId: LayerId): LayerEffectsRack {
        return checkNotNull(racks[layerId]) {
            "No effects rack registered for $layerId"
        }
    }

    fun settingsFor(layerId: LayerId): LayerEffectsSettings {
        return rackFor(layerId).settings
    }

    fun update(layerId: LayerId, settings: LayerEffectsSettings) {
        rackFor(layerId).updateSettings(settings)
    }

    fun allLayerIds(): Set<LayerId> = racks.keys
}
