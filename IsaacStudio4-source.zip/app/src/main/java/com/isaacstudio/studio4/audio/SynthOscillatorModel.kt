package com.isaacstudio.studio4.audio

/**
 * Sound-generation modes for each independent Synth layer.
 */
enum class SynthSoundMode {
    ANALOG,
    SAMPLES
}

/**
 * Oscillator types available in the Synth architecture.
 */
enum class SynthOscillatorType {
    ANALOG,
    FM_HARMONIC,
    FM_INHARMONIC,
    DIGITAL_WAVE
}

/**
 * Analog oscillator waveform categories.
 */
enum class SynthAnalogCategory {
    PURE,
    SHAPE,
    SHAPE_SINE,
    SUB_OSC,
    MULTI,
    SUPER,
    SYNC,
    BELL,
    NOISE,
    MISC
}

/**
 * Configuration for an individual oscillator.
 */
data class SynthOscillatorConfig(
    val waveform: Waveform = Waveform.SAWTOOTH,
    val semitone: Int = 0,
    val fineTune: Float = 0f,
    val detune: Float = 0f,
    val level: Float = 1f
)

/**
 * Independent oscillator configuration for one Synth layer.
 */
data class SynthOscillatorSettings(
    val enabled: Boolean = false,
    val soundMode: SynthSoundMode = SynthSoundMode.ANALOG,
    val oscillatorType: SynthOscillatorType =
        SynthOscillatorType.ANALOG,
    val analogCategory: SynthAnalogCategory =
        SynthAnalogCategory.PURE,
    val oscillatorA: SynthOscillatorConfig =
        SynthOscillatorConfig(),
    val oscillatorB: SynthOscillatorConfig =
        SynthOscillatorConfig(semitone = 12),
    val oscillatorMix: Float = 0f,
    val oscillatorControl: Float = 0f
)
