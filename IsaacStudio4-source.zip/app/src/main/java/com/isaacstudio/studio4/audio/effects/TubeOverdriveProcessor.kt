package com.isaacstudio.studio4.audio.effects

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp

/**
 * Stateful stereo tube-style overdrive.
 *
 * Each layer owns its own processor instance.
 * Processing is allocation-free after construction.
 * Input and output arrays may safely be the same arrays.
 */
class TubeOverdriveProcessor(
    sampleRate: Float = 44100f
) {
    private val safeSampleRate =
        if (sampleRate.isFinite() && sampleRate > 0f) sampleRate else 44100f

    private var cachedTone = Float.NaN
    private var toneCoefficient = 1f

    private var leftToneState = 0f
    private var rightToneState = 0f

    private var leftDcInput = 0f
    private var rightDcInput = 0f
    private var leftDcOutput = 0f
    private var rightDcOutput = 0f

    private fun safeControl(value: Float, fallback: Float, minimum: Float, maximum: Float): Float {
        return if (value.isFinite()) value.coerceIn(minimum, maximum) else fallback
    }

    private fun updateTone(tone: Float) {
        if (tone == cachedTone) return

        cachedTone = tone

        val cutoff = 1800f * (16000f / 1800f) * tone
        val safeCutoff = cutoff.coerceIn(1800f, 16000f)

        toneCoefficient = (
            1f - exp(
                (-2.0 * PI * safeCutoff / safeSampleRate).toFloat()
            )
        ).coerceIn(0.001f, 1f)
    }

    private fun saturate(input: Float): Float {
        val shaped = (input + 0.08f * input * abs(input)).coerceIn(-3f, 3f)
        val squared = shaped * shaped

        return shaped * (27f + squared) / (27f + 9f * squared)
    }

    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: TubeOverdriveSettings
    ) {
        val frames = minOf(
            inputLeft.size,
            inputRight.size,
            outputLeft.size,
            outputRight.size
        )

        if (!settings.enabled) {
            for (i in 0 until frames) {
                outputLeft[i] = inputLeft[i]
                outputRight[i] = inputRight[i]
            }
            return
        }

        val drive = safeControl(settings.drive, 0.35f, 0f, 1f)
        val tone = safeControl(settings.tone, 0.5f, 0f, 1f)
        val level = safeControl(settings.level, 1f, 0f, 2f)

        updateTone(tone)

        val inputGain = 1f + drive * 11f
        val alpha = toneCoefficient

        for (i in 0 until frames) {
            val rawLeft = if (inputLeft[i].isFinite()) inputLeft[i].coerceIn(-8f, 8f) else 0f
            val rawRight = if (inputRight[i].isFinite()) inputRight[i].coerceIn(-8f, 8f) else 0f

            val drivenLeft = saturate(rawLeft * inputGain)
            val drivenRight = saturate(rawRight * inputGain)

            leftToneState += alpha * (drivenLeft - leftToneState)
            rightToneState += alpha * (drivenRight - rightToneState)

            val dcLeft = leftToneState - leftDcInput + 0.995f * leftDcOutput
            val dcRight = rightToneState - rightDcInput + 0.995f * rightDcOutput

            leftDcInput = leftToneState
            rightDcInput = rightToneState
            leftDcOutput = dcLeft
            rightDcOutput = dcRight

            outputLeft[i] = (dcLeft * level).coerceIn(-8f, 8f)
            outputRight[i] = (dcRight * level).coerceIn(-8f, 8f)
        }
    }

    fun reset() {
        leftToneState = 0f
        rightToneState = 0f

        leftDcInput = 0f
        rightDcInput = 0f
        leftDcOutput = 0f
        rightDcOutput = 0f

        cachedTone = Float.NaN
        toneCoefficient = 1f
    }
}
