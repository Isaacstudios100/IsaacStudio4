package com.isaacstudio.studio4.audio.instruments

enum class InstrumentType {
    PIANO,
    ORGAN,
    SYNTH
}
