package com.isaacstudio.studio4.audio.performance

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import com.isaacstudio.studio4.audio.*
import com.isaacstudio.studio4.audio.effects.*
import com.isaacstudio.studio4.audio.instruments.*
import java.io.File
import java.io.IOException

class PerformanceStorage(context: Context) {

    private val storageFile =
        File(context.filesDir, "performances.json")

    private val atomicFile = AtomicFile(storageFile)

    @Synchronized
    fun loadAll(): List<PerformanceSnapshot> {
        return readLibrary()
    }

    @Synchronized
    fun save(snapshot: PerformanceSnapshot) {
        val name = cleanName(snapshot.name)
        require(name.isNotEmpty()) {
            "Performance name cannot be empty."
        }

        val entries = readLibrary()

        val normalized = snapshot.copy(
            schemaVersion = PerformanceSnapshot.CURRENT_SCHEMA_VERSION,
            name = name,
            updatedAtMillis = System.currentTimeMillis()
        )

        val index = entries.indexOfFirst {
            it.name.equals(name, ignoreCase = true)
        }

        if (index >= 0) {
            entries[index] = normalized
        } else {
            entries.add(normalized)
        }

        writeLibrary(entries)
    }

    @Synchronized
    fun rename(oldName: String, newName: String) {
        val target = cleanName(newName)
        require(target.isNotEmpty()) {
            "Performance name cannot be empty."
        }

        val entries = readLibrary()

        val index = entries.indexOfFirst {
            it.name.equals(oldName.trim(), ignoreCase = true)
        }

        require(index >= 0) {
            "Performance not found."
        }

        require(entries.none {
            it.name.equals(target, ignoreCase = true) &&
            !it.name.equals(oldName.trim(), ignoreCase = true)
        }) {
            "A performance with that name already exists."
        }

        entries[index] = entries[index].copy(
            name = target,
            updatedAtMillis = System.currentTimeMillis()
        )

        writeLibrary(entries)
    }

    @Synchronized
    fun delete(name: String) {
        val entries = readLibrary()

        val removed = entries.removeAll {
            it.name.equals(name.trim(), ignoreCase = true)
        }

        require(removed) {
            "Performance not found."
        }

        writeLibrary(entries)
    }

    private fun cleanName(value: String): String =
        value.trim().replace(Regex("\\s+"), " ").take(48)

    private fun readLibrary(): MutableList<PerformanceSnapshot> {

        val root = try {
            atomicFile.openRead().bufferedReader().use {
                JSONObject(it.readText())
            }
        } catch (_: java.io.FileNotFoundException) {
            return mutableListOf()
        } catch (e: Exception) {
            throw IOException("Performance library is unreadable; original file preserved.", e)
        }

        val version = root.optInt("schemaVersion", -1)
        if (version != 1 && version != PerformanceSnapshot.CURRENT_SCHEMA_VERSION) {
            throw IOException("Unsupported performance library version: $version")
        }

        val array = root.optJSONArray("performances")
            ?: throw IOException("Performance library has no performances array.")

        val result = mutableListOf<PerformanceSnapshot>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            try {
                result.add(decodePerformance(item))
            } catch (_: Exception) {
                // Skip an invalid entry without discarding valid performances.
            }
        }
        return result
    }

    private fun writeLibrary(entries: List<PerformanceSnapshot>) {
        val root = JSONObject()
        root.put("schemaVersion", PerformanceSnapshot.CURRENT_SCHEMA_VERSION)

        val array = JSONArray()
        entries.forEach { array.put(encodePerformance(it)) }
        root.put("performances", array)

        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomicFile.startWrite()
            stream.write(root.toString().toByteArray(Charsets.UTF_8))
            stream.fd.sync()
            atomicFile.finishWrite(stream)
        } catch (e: Exception) {
            if (stream != null) atomicFile.failWrite(stream)
            throw IOException("Could not save performance library.", e)
        }
    }

    private fun encodePerformance(value: PerformanceSnapshot): JSONObject {
        val item = JSONObject()
        item.put("schemaVersion", value.schemaVersion)
        item.put("name", value.name)
        item.put("createdAtMillis", value.createdAtMillis)
        item.put("updatedAtMillis", value.updatedAtMillis)
        item.put("selectedLayer", value.selectedLayer.name)
        item.put("masterVolume", value.masterVolume.toDouble())
        item.put("organ1AuxEnabled", value.organ1AuxEnabled)
        item.put("organ2AuxEnabled", value.organ2AuxEnabled)
        item.put("rotaryMode", value.rotaryMode)
        item.put("rotaryDrive", value.rotaryDrive.toDouble())
        item.put("rotaryEnabled", value.rotaryEnabled)
        item.put("rotaryCloseMic", value.rotaryCloseMic)
        item.put("rotaryStopMode", value.rotaryStopMode)
        item.put("rotaryAngle", value.rotaryAngle)

        val layers = JSONObject()
        LayerId.values().forEach { id ->
            layers.put(id.name, encodeLayer(value.layers[id] ?: PerformanceLayer()))
        }
        item.put("layers", layers)
        return item
    }


    private fun encodeLayer(v: PerformanceLayer): JSONObject {
        val o = JSONObject()
        o.put("enabled", v.enabled)
        o.put("lowKey", v.lowKey)
        o.put("highKey", v.highKey)
        o.put("volume", v.volume.toDouble())
        o.put("octave", v.octave)

        o.put("waveform", v.waveform.name)
        o.put("attack", v.attack.toDouble())
        o.put("decay", v.decay.toDouble())
        o.put("sustain", v.sustain.toDouble())
        o.put("release", v.release.toDouble())
        o.put("oscillator", encodeOscillator(v.oscillatorSettings))
        o.put("filter", encodeFilter(v.filterSettings))
        o.put("modulation", encodeModulation(v.modulationSettings))

        o.put("organModel", v.organModel.name)
        val drawbars = JSONObject()
        v.organDrawbars.forEach { (model, bars) ->
            val a = JSONArray()
            bars.take(9).forEach { a.put(it.coerceIn(0, 8)) }
            drawbars.put(model.name, a)
        }
        o.put("organDrawbars", drawbars)
        o.put("organVoxFilterMix", v.organVoxFilterMix.toDouble())
        o.put("b3PercussionEnabled", v.b3PercussionEnabled)
        o.put("b3PercussionHarmonic", v.b3PercussionHarmonic)
        o.put("b3PercussionSoft", v.b3PercussionSoft)
        o.put("b3PercussionFastDecay", v.b3PercussionFastDecay)
        o.put("b3PercussionPolyMode", v.b3PercussionPolyMode)
        o.put("vibratoChorusMode", v.vibratoChorusMode)
        o.put("pianoSoundModel", v.pianoSoundModel.name)
        o.put("effects", encodeEffects(v.effects))
        return o
    }

    private fun decodeLayer(o: JSONObject): PerformanceLayer {
        val defaults = PerformanceLayer()
        val drawbarObject = o.optJSONObject("organDrawbars") ?: JSONObject()
        val drawbars = OrganModel.values().associateWith { model ->
            val a = drawbarObject.optJSONArray(model.name)
            if (a == null) defaults.organDrawbars[model] ?: List(9) { 0 }
            else List(9) { i ->
                (if (i < a.length()) a.optInt(i, 0) else 0).coerceIn(0, 8)
            }
        }

        return PerformanceLayer(
            enabled = o.optBoolean("enabled", defaults.enabled),
            lowKey = minOf(
                intValue(o, "lowKey", 0, 0, 127),
                intValue(o, "highKey", 127, 0, 127)
            ),
            highKey = maxOf(
                intValue(o, "lowKey", 0, 0, 127),
                intValue(o, "highKey", 127, 0, 127)
            ),
            volume = number(o, "volume", 1f, 0f, 1f),
            octave = intValue(o, "octave", 0, -4, 4),

            waveform = enumValue(o.optString("waveform"), Waveform.SAWTOOTH),
            attack = number(o, "attack", .005f, .001f, 10f),
            decay = number(o, "decay", .12f, 0f, 10f),
            sustain = number(o, "sustain", .7f, 0f, 1f),
            release = number(o, "release", .3f, .001f, 20f),
            oscillatorSettings = decodeOscillator(o.optJSONObject("oscillator")),
            filterSettings = decodeFilter(o.optJSONObject("filter")),
            modulationSettings = decodeModulation(o.optJSONObject("modulation")),

            organModel = enumValue(o.optString("organModel"), OrganModel.B3),
            organDrawbars = drawbars,
            organVoxFilterMix = number(o, "organVoxFilterMix", .5f, 0f, 1f),
            b3PercussionEnabled = o.optBoolean("b3PercussionEnabled", false),
            b3PercussionHarmonic = intValue(o, "b3PercussionHarmonic", 2, 2, 3),
            b3PercussionSoft = o.optBoolean("b3PercussionSoft", false),
            b3PercussionFastDecay = o.optBoolean("b3PercussionFastDecay", true),
            b3PercussionPolyMode = o.optBoolean("b3PercussionPolyMode", false),
            vibratoChorusMode = intValue(o, "vibratoChorusMode", 0, 0, 6),
            rotaryMode = intValue(o, "rotaryMode", 0, 0, 2),
            rotaryDrive = number(o, "rotaryDrive", 0f, 0f, 1f),
            rotaryEnabled = o.optBoolean("rotaryEnabled", true),
            rotaryCloseMic = o.optBoolean("rotaryCloseMic", false),
            rotaryStopMode = o.optBoolean("rotaryStopMode", false),
            rotaryAngle = intValue(o, "rotaryAngle", 0, 0, 6),

            pianoSoundModel = enumValue(
                o.optString("pianoSoundModel"), PianoSoundModel.STUDIO_GRAND
            ),
            effects = decodeEffects(o.optJSONObject("effects"))
        )
    }

    private fun encodeOscillator(v: SynthOscillatorSettings) = JSONObject().apply {
        put("enabled", v.enabled)
        put("soundMode", v.soundMode.name)
        put("oscillatorType", v.oscillatorType.name)
        put("analogCategory", v.analogCategory.name)
        put("oscillatorA", encodeOscillatorConfig(v.oscillatorA))
        put("oscillatorB", encodeOscillatorConfig(v.oscillatorB))
        put("oscillatorMix", v.oscillatorMix.toDouble())
        put("oscillatorControl", v.oscillatorControl.toDouble())
    }

    private fun encodeOscillatorConfig(v: SynthOscillatorConfig) = JSONObject().apply {
        put("waveform", v.waveform.name)
        put("semitone", v.semitone)
        put("fineTune", v.fineTune.toDouble())
        put("detune", v.detune.toDouble())
        put("level", v.level.toDouble())
        put("analogCategory", v.analogCategory.name)
        put("oscillatorControl", v.oscillatorControl.toDouble())
        put("oscillatorType", v.oscillatorType.name)
        put("fmAmount", v.fmAmount.toDouble())
        put("fmRatio", v.fmRatio.toDouble())
        put("digitalWave", v.digitalWave.name)
        put("digitalMorph", v.digitalMorph.toDouble())
    }

    private fun decodeOscillator(o: JSONObject?): SynthOscillatorSettings {
        val d = SynthOscillatorSettings()
        if (o == null) return d
        return SynthOscillatorSettings(
            enabled = o.optBoolean("enabled", d.enabled),
            soundMode = enumValue(o.optString("soundMode"), d.soundMode),
            oscillatorType = enumValue(o.optString("oscillatorType"), d.oscillatorType),
            analogCategory = enumValue(o.optString("analogCategory"), d.analogCategory),
            oscillatorA = decodeOscillatorConfig(o.optJSONObject("oscillatorA"), d.oscillatorA),
            oscillatorB = decodeOscillatorConfig(o.optJSONObject("oscillatorB"), d.oscillatorB),
            oscillatorMix = number(o, "oscillatorMix", 0f, 0f, 1f),
            oscillatorControl = number(o, "oscillatorControl", 0f, 0f, 1f)
        )
    }

    private fun decodeOscillatorConfig(
        o: JSONObject?, d: SynthOscillatorConfig
    ): SynthOscillatorConfig {
        if (o == null) return d
        return SynthOscillatorConfig(
            waveform = enumValue(o.optString("waveform"), d.waveform),
            semitone = intValue(o, "semitone", d.semitone, -48, 48),
            fineTune = number(o, "fineTune", d.fineTune, -100f, 100f),
            detune = number(o, "detune", d.detune, -100f, 100f),
            level = number(o, "level", d.level, 0f, 1f),
            analogCategory = enumValue(o.optString("analogCategory"), d.analogCategory),
            oscillatorControl = number(o, "oscillatorControl", 0f, 0f, 1f),
            oscillatorType = enumValue(o.optString("oscillatorType"), d.oscillatorType),
            fmAmount = number(o, "fmAmount", 0f, 0f, 1f),
            fmRatio = number(o, "fmRatio", 2f, .25f, 16f),
            digitalWave = enumValue(o.optString("digitalWave"), d.digitalWave),
            digitalMorph = number(o, "digitalMorph", 0f, 0f, 1f)
        )
    }

    private fun encodeFilter(v: SynthFilterSettings) = JSONObject().apply {
        put("mode", v.mode.name)
        put("cutoffHz", v.cutoffHz.toDouble())
        put("resonance", v.resonance.toDouble())
        put("drive", v.drive.toDouble())
    }

    private fun decodeFilter(o: JSONObject?): SynthFilterSettings {
        val d = SynthFilterSettings()
        if (o == null) return d
        return SynthFilterSettings(
            mode = enumValue(o.optString("mode"), d.mode),
            cutoffHz = number(o, "cutoffHz", d.cutoffHz, 20f, 20000f),
            resonance = number(o, "resonance", d.resonance, 0f, 1f),
            drive = number(o, "drive", d.drive, 0f, 1f)
        )
    }

    private fun encodeModulation(v: SynthModulationSettings) = JSONObject().apply {
        put("filterAttack", v.filterAttack.toDouble())
        put("filterDecay", v.filterDecay.toDouble())
        put("filterSustain", v.filterSustain.toDouble())
        put("filterRelease", v.filterRelease.toDouble())
        put("filterEnvelopeAmountOctaves", v.filterEnvelopeAmountOctaves.toDouble())
        put("velocityToVolume", v.velocityToVolume.toDouble())
        put("velocityToFilterOctaves", v.velocityToFilterOctaves.toDouble())
    }

    private fun decodeModulation(o: JSONObject?): SynthModulationSettings {
        val d = SynthModulationSettings()
        if (o == null) return d
        return SynthModulationSettings(
            filterAttack = number(o, "filterAttack", d.filterAttack, .001f, 10f),
            filterDecay = number(o, "filterDecay", d.filterDecay, 0f, 10f),
            filterSustain = number(o, "filterSustain", d.filterSustain, 0f, 1f),
            filterRelease = number(o, "filterRelease", d.filterRelease, .001f, 20f),
            filterEnvelopeAmountOctaves = number(
                o, "filterEnvelopeAmountOctaves", d.filterEnvelopeAmountOctaves, -8f, 8f
            ),
            velocityToVolume = number(o, "velocityToVolume", d.velocityToVolume, 0f, 2f),
            velocityToFilterOctaves = number(
                o, "velocityToFilterOctaves", d.velocityToFilterOctaves, -8f, 8f
            )
        )
    }


    private fun encodeEffects(v: LayerEffectsSettings) = JSONObject().apply {
        put("mod1", JSONObject().apply {
            put("enabled", v.mod1.enabled)
            put("type", v.mod1.type.name)
            put("rate", v.mod1.rate.toDouble())
            put("amount", v.mod1.amount.toDouble())
            put("mix", v.mod1.mix.toDouble())
            put("frequency", v.mod1.frequency.toDouble())
            put("resonance", v.mod1.resonance.toDouble())
        })
        put("mod2", JSONObject().apply {
            put("enabled", v.mod2.enabled)
            put("type", v.mod2.type.name)
            put("rate", v.mod2.rate.toDouble())
            put("amount", v.mod2.amount.toDouble())
            put("mix", v.mod2.mix.toDouble())
            put("feedback", v.mod2.feedback.toDouble())
        })
        put("delay", JSONObject().apply {
            put("enabled", v.delay.enabled)
            put("timeMs", v.delay.timeMs.toDouble())
            put("tempoSync", v.delay.tempoSync)
            put("tempoBpm", v.delay.tempoBpm.toDouble())
            put("subdivision", v.delay.subdivision.name)
            put("feedback", v.delay.feedback.toDouble())
            put("mix", v.delay.mix.toDouble())
            put("pingPong", v.delay.pingPong)
            put("analogMode", v.delay.analogMode)
            put("filter", v.delay.filter.name)
            put("feedbackEffect", v.delay.feedbackEffect.name)
        })
        put("ampEq", JSONObject().apply {
            put("enabled", v.ampEq.enabled)
            put("ampModel", v.ampEq.ampModel.name)
            put("drive", v.ampEq.drive.toDouble())
            put("lowPassHz", v.ampEq.lowPassHz.toDouble())
            put("highPassHz", v.ampEq.highPassHz.toDouble())
            put("lowGainDb", v.ampEq.lowGainDb.toDouble())
            put("midGainDb", v.ampEq.midGainDb.toDouble())
            put("midFrequencyHz", v.ampEq.midFrequencyHz.toDouble())
            put("highGainDb", v.ampEq.highGainDb.toDouble())
            put("toRotary", v.ampEq.toRotary)
        })
        put("tubeOverdrive", JSONObject().apply {
            put("enabled", v.tubeOverdrive.enabled)
            put("drive", v.tubeOverdrive.drive.toDouble())
            put("tone", v.tubeOverdrive.tone.toDouble())
            put("level", v.tubeOverdrive.level.toDouble())
        })
        put("compressor", JSONObject().apply {
            put("enabled", v.compressor.enabled)
            put("amount", v.compressor.amount.toDouble())
            put("fast", v.compressor.fast)
            put("thresholdDb", v.compressor.thresholdDb.toDouble())
            put("ratio", v.compressor.ratio.toDouble())
            put("attackMs", v.compressor.attackMs.toDouble())
            put("releaseMs", v.compressor.releaseMs.toDouble())
            put("kneeDb", v.compressor.kneeDb.toDouble())
            put("makeupGainDb", v.compressor.makeupGainDb.toDouble())
            put("detector", v.compressor.detector.name)
        })
        put("reverb", JSONObject().apply {
            put("enabled", v.reverb.enabled)
            put("type", v.reverb.type.name)
            put("roomSize", v.reverb.roomSize.toDouble())
            put("wetMix", v.reverb.wetMix.toDouble())
            put("bright", v.reverb.bright)
            put("chorale", v.reverb.chorale)
        })
    }

    private fun decodeEffects(o: JSONObject?): LayerEffectsSettings {
        val d = LayerEffectsSettings()
        if (o == null) return d

        val m1 = o.optJSONObject("mod1") ?: JSONObject()
        val m2 = o.optJSONObject("mod2") ?: JSONObject()
        val dl = o.optJSONObject("delay") ?: JSONObject()
        val ae = o.optJSONObject("ampEq") ?: JSONObject()
        val td = o.optJSONObject("tubeOverdrive") ?: JSONObject()
        val cp = o.optJSONObject("compressor") ?: JSONObject()
        val rv = o.optJSONObject("reverb") ?: JSONObject()

        return LayerEffectsSettings(
            mod1 = Mod1Settings(
                enabled = m1.optBoolean("enabled", false),
                type = enumValue(m1.optString("type"), Mod1Type.OFF),
                rate = number(m1, "rate", .5f, 0f, 1f),
                amount = number(m1, "amount", .5f, 0f, 1f),
                mix = number(m1, "mix", .5f, 0f, 1f),
                frequency = number(m1, "frequency", .5f, 0f, 1f),
                resonance = number(m1, "resonance", .2f, 0f, 1f)
            ),
            mod2 = Mod2Settings(
                enabled = m2.optBoolean("enabled", false),
                type = enumValue(m2.optString("type"), Mod2Type.OFF),
                rate = number(m2, "rate", .5f, 0f, 1f),
                amount = number(m2, "amount", .5f, 0f, 1f),
                mix = number(m2, "mix", .5f, 0f, 1f),
                feedback = number(m2, "feedback", .3f, 0f, 1f)
            ),
            delay = DelaySettings(
                enabled = dl.optBoolean("enabled", false),
                timeMs = number(dl, "timeMs", 375f, 1f, 3000f),
                tempoSync = dl.optBoolean("tempoSync", false),
                tempoBpm = number(dl, "tempoBpm", 120f, 20f, 300f),
                subdivision = enumValue(
                    dl.optString("subdivision"), DelaySubdivision.QUARTER
                ),
                feedback = number(dl, "feedback", .35f, 0f, .95f),
                mix = number(dl, "mix", .25f, 0f, 1f),
                pingPong = dl.optBoolean("pingPong", false),
                analogMode = dl.optBoolean("analogMode", false),
                filter = enumValue(dl.optString("filter"), DelayFilterType.OFF),
                feedbackEffect = enumValue(
                    dl.optString("feedbackEffect"), DelayFeedbackEffect.OFF
                )
            ),
            ampEq = AmpEqSettings(
                enabled = ae.optBoolean("enabled", false),
                ampModel = enumValue(ae.optString("ampModel"), AmpModel.OFF),
                drive = number(ae, "drive", 0f, 0f, 1f),
                lowPassHz = number(ae, "lowPassHz", 20000f, 20f, 20000f),
                highPassHz = number(ae, "highPassHz", 20f, 20f, 20000f),
                lowGainDb = number(ae, "lowGainDb", 0f, -24f, 24f),
                midGainDb = number(ae, "midGainDb", 0f, -24f, 24f),
                midFrequencyHz = number(ae, "midFrequencyHz", 1000f, 20f, 20000f),
                highGainDb = number(ae, "highGainDb", 0f, -24f, 24f),
                toRotary = ae.optBoolean("toRotary", false)
            ),
            tubeOverdrive = TubeOverdriveSettings(
                enabled = td.optBoolean("enabled", false),
                drive = number(td, "drive", .35f, 0f, 1f),
                tone = number(td, "tone", .5f, 0f, 1f),
                level = number(td, "level", 1f, 0f, 1f)
            ),
            compressor = CompressorSettings(
                enabled = cp.optBoolean("enabled", false),
                amount = number(cp, "amount", .5f, 0f, 1f),
                fast = cp.optBoolean("fast", false),
                thresholdDb = number(cp, "thresholdDb", -18f, -60f, 0f),
                ratio = number(cp, "ratio", 4f, 1f, 20f),
                attackMs = number(cp, "attackMs", 10f, .1f, 200f),
                releaseMs = number(cp, "releaseMs", 120f, 1f, 2000f),
                kneeDb = number(cp, "kneeDb", 6f, 0f, 24f),
                makeupGainDb = number(cp, "makeupGainDb", 0f, -24f, 24f),
                detector = enumValue(cp.optString("detector"), CompressorDetector.PEAK)
            ),
            reverb = ReverbSettings(
                enabled = rv.optBoolean("enabled", false),
                type = enumValue(rv.optString("type"), ReverbType.ROOM),
                roomSize = number(rv, "roomSize", .5f, 0f, 1f),
                wetMix = number(rv, "wetMix", .25f, 0f, 1f),
                bright = rv.optBoolean("bright", false),
                chorale = rv.optBoolean("chorale", false)
            )
        )
    }

    private fun decodePerformance(item: JSONObject): PerformanceSnapshot {
        val layerObject = item.optJSONObject("layers")
            ?: JSONObject()

        val layers = LayerId.values().associateWith { id ->
            decodeLayer(layerObject.optJSONObject(id.name) ?: JSONObject())
        }

        val legacyRotary = layers[LayerId.ORGAN_1]
            ?: layers[LayerId.ORGAN_2]
            ?: PerformanceLayer()

        return PerformanceSnapshot(
            schemaVersion = PerformanceSnapshot.CURRENT_SCHEMA_VERSION,
            name = cleanName(item.optString("name", "Untitled")),
            createdAtMillis = item.optLong("createdAtMillis", System.currentTimeMillis()),
            updatedAtMillis = item.optLong("updatedAtMillis", System.currentTimeMillis()),
            selectedLayer = enumValue(item.optString("selectedLayer"), LayerId.SYNTH_1),
            masterVolume = number(item, "masterVolume", 1f, 0f, 1f),
            organ1AuxEnabled = item.optBoolean("organ1AuxEnabled", false),
            organ2AuxEnabled = item.optBoolean("organ2AuxEnabled", false),
            rotaryMode = intValue(item, "rotaryMode", legacyRotary.rotaryMode, 0, 2),
            rotaryDrive = number(item, "rotaryDrive", legacyRotary.rotaryDrive, 0f, 1f),
            rotaryEnabled = item.optBoolean("rotaryEnabled", legacyRotary.rotaryEnabled),
            rotaryCloseMic = item.optBoolean("rotaryCloseMic", legacyRotary.rotaryCloseMic),
            rotaryStopMode = item.optBoolean("rotaryStopMode", legacyRotary.rotaryStopMode),
            rotaryAngle = intValue(item, "rotaryAngle", legacyRotary.rotaryAngle, 0, 6),
            layers = layers
        )
    }

    private inline fun <reified T : Enum<T>> enumValue(
        value: String,
        fallback: T
    ): T {
        return try {
            enumValueOf<T>(value)
        } catch (_: IllegalArgumentException) {
            fallback
        }
    }

    private fun number(
        o: JSONObject,
        key: String,
        fallback: Float,
        minimum: Float,
        maximum: Float
    ): Float {
        val value = o.optDouble(key, fallback.toDouble())
        if (value.isNaN() || value.isInfinite()) return fallback
        return value.toFloat().coerceIn(minimum, maximum)
    }

    private fun intValue(
        o: JSONObject,
        key: String,
        fallback: Int,
        minimum: Int,
        maximum: Int
    ): Int {
        return o.optInt(key, fallback).coerceIn(minimum, maximum)
    }
}
