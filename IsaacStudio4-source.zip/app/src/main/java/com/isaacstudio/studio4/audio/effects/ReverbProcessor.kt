package com.isaacstudio.studio4.audio.effects

import kotlin.math.pow

class ReverbProcessor(
    private val sampleRate: Int = 44100
) {
    @Volatile var enabled = false
    @Volatile var roomSize = 0.5f
    @Volatile var wetMix = 0.25f

    private val baseDelayTimes = intArrayOf(
        1423, 1601, 1867, 2053,
        2251, 2411, 2593, 2791
    )

    private val buffers = Array(baseDelayTimes.size) { index ->
        val length = (
            baseDelayTimes[index].toFloat() *
            sampleRate / 44100f
        ).toInt().coerceAtLeast(1)

        FloatArray(length)
    }

    private val positions = IntArray(buffers.size)
    private val dampedValues = FloatArray(buffers.size)
    private val feedbackValues = FloatArray(buffers.size)
    private val feedbackGains = FloatArray(buffers.size)

    private val inputSigns = floatArrayOf(
        1f, -1f, 1f, 1f, -1f, 1f, -1f, -1f
    )

    private val outputSigns = floatArrayOf(
        1f, 1f, -1f, 1f, 1f, -1f, -1f, -1f
    )

    fun process(buffer: FloatArray) {
        if (!enabled) return

        val room = roomSize.coerceIn(0f, 1f)
        val wet = wetMix.coerceIn(0f, 1f)

        val decaySeconds = 0.45f + room * 5.55f
        val damping = 0.55f - room * 0.25f

        for (line in buffers.indices) {
            val delaySeconds =
                buffers[line].size.toFloat() / sampleRate

            feedbackGains[line] = 10.0.pow(
                (-3.0 * delaySeconds / decaySeconds).toDouble()
            ).toFloat().coerceIn(0f, 0.9995f)
        }

        val dryLevel = 1f - wet * 0.55f
        val wetLevel = wet * 1.25f

        for (i in buffer.indices) {
            val input = buffer[i]
            var reflections = 0f

            // Read and damp all eight delay lines.
            for (line in buffers.indices) {
                val delayed = buffers[line][positions[line]]

                dampedValues[line] +=
                    damping * (delayed - dampedValues[line])

                reflections +=
                    dampedValues[line] * outputSigns[line]

                feedbackValues[line] = dampedValues[line]
            }

            // Normalized 8-point Hadamard feedback matrix.
            var width = 1

            while (width < feedbackValues.size) {
                var start = 0

                while (start < feedbackValues.size) {
                    for (j in 0 until width) {
                        val a = feedbackValues[start + j]
                        val b = feedbackValues[start + j + width]

                        feedbackValues[start + j] = a + b
                        feedbackValues[start + j + width] = a - b
                    }

                    start += width * 2
                }

                width *= 2
            }

            val normalization = 0.35355339f

            // Feed the transformed signals back into the delay lines.
            for (line in buffers.indices) {
                val feedback =
                    feedbackValues[line] * normalization

                buffers[line][positions[line]] =
                    input * 0.20f * inputSigns[line] +
                    feedback * feedbackGains[line]

                positions[line] =
                    (positions[line] + 1) % buffers[line].size
            }

            val reverbSignal = reflections * 0.32f

            val output =
                input * dryLevel + reverbSignal * wetLevel

            buffer[i] = output.coerceIn(-1f, 1f)
        }
    }

    fun reset() {
        buffers.forEach { it.fill(0f) }
        positions.fill(0)
        dampedValues.fill(0f)
        feedbackValues.fill(0f)
    }
}
