package com.isaacstudio.studio4.audio.effects

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Persistent stereo reverb processor.
 *
 * Each instrument layer owns an independent instance. The processor keeps
 * independent left/right delay networks and receives an immutable settings
 * snapshot per audio block.
 *
 * The normalized Hadamard feedback network is followed by an orthogonal
 * stereo rotation. This allows stereo cross-coupling without increasing
 * feedback energy.
 */
class ReverbProcessor(
    private val sampleRate: Int = 44100
) {
    companion object {
        private const val LINE_COUNT = 8
        private const val NORMALIZATION = 0.35355339f
        private const val MAX_INPUT = 8f
        private const val MAX_INTERNAL = 16f
        private const val MAX_OUTPUT = 32f
        private const val MAX_FEEDBACK = 0.9995f

        private val BASE_DELAYS = intArrayOf(
            1423, 1601, 1867, 2053,
            2251, 2411, 2593, 2791
        )

        private val INPUT_SIGNS = floatArrayOf(
            1f, -1f, 1f, 1f, -1f, 1f, -1f, -1f
        )

        private val OUTPUT_SIGNS = floatArrayOf(
            1f, 1f, -1f, 1f, 1f, -1f, -1f, -1f
        )
    }

    init {
        require(sampleRate > 0) {
            "sampleRate must be greater than zero."
        }
    }

    private val bufferCapacity =
        (sampleRate * 0.14f).toInt().coerceAtLeast(512)

    private val leftBuffers = Array(LINE_COUNT) {
        FloatArray(bufferCapacity)
    }

    private val rightBuffers = Array(LINE_COUNT) {
        FloatArray(bufferCapacity)
    }

    private val positions = IntArray(LINE_COUNT)
    private val delayLengths = IntArray(LINE_COUNT)
    private val dampedLeft = FloatArray(LINE_COUNT)
    private val dampedRight = FloatArray(LINE_COUNT)
    private val feedbackLeft = FloatArray(LINE_COUNT)
    private val feedbackRight = FloatArray(LINE_COUNT)
    private val feedbackGains = FloatArray(LINE_COUNT)

    private var choralePhase = 0f

    private fun safeInput(value: Float): Float {
        return if (value.isFinite()) {
            value.coerceIn(-MAX_INPUT, MAX_INPUT)
        } else {
            0f
        }
    }

    private fun safeInternal(value: Float): Float {
        return if (value.isFinite()) {
            value.coerceIn(-MAX_INTERNAL, MAX_INTERNAL)
        } else {
            0f
        }
    }

    /**
     * Processes stereo buffers in place or into separate output buffers.
     * Input and output arrays may be the same arrays.
     */
    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: ReverbSettings
    ) {
        if (!settings.enabled) return

        val room = if (settings.roomSize.isFinite()) {
            settings.roomSize.coerceIn(0f, 1f)
        } else {
            0.5f
        }

        val wet = if (settings.wetMix.isFinite()) {
            settings.wetMix.coerceIn(0f, 1f)
        } else {
            0.25f
        }

        val delayScale: Float
        val decayScale: Float
        val dampingBase: Float
        val crossFeedback: Float
        val injection: Float
        val reflectionLevel: Float

        when (settings.type) {
            ReverbType.ROOM -> {
                delayScale = 0.58f
                decayScale = 0.62f
                dampingBase = 0.72f
                crossFeedback = 0.12f
                injection = 0.22f
                reflectionLevel = 0.19f
            }

            ReverbType.BOOTH -> {
                delayScale = 0.39f
                decayScale = 0.34f
                dampingBase = 0.82f
                crossFeedback = 0.08f
                injection = 0.25f
                reflectionLevel = 0.22f
            }

            ReverbType.SPRING -> {
                delayScale = 0.27f
                decayScale = 0.72f
                dampingBase = 0.48f
                crossFeedback = 0.20f
                injection = 0.19f
                reflectionLevel = 0.24f
            }

            ReverbType.STAGE -> {
                delayScale = 0.82f
                decayScale = 0.92f
                dampingBase = 0.64f
                crossFeedback = 0.25f
                injection = 0.18f
                reflectionLevel = 0.18f
            }

            ReverbType.HALL -> {
                delayScale = 1.18f
                decayScale = 1.28f
                dampingBase = 0.57f
                crossFeedback = 0.34f
                injection = 0.16f
                reflectionLevel = 0.17f
            }

            ReverbType.CATHEDRAL -> {
                delayScale = 1.62f
                decayScale = 1.75f
                dampingBase = 0.49f
                crossFeedback = 0.42f
                injection = 0.14f
                reflectionLevel = 0.16f
            }
        }

        val decaySeconds = (0.45f + room * 5.55f) * decayScale

        val damping = (
            if (settings.bright) {
                dampingBase * 0.38f
            } else {
                dampingBase
            }
        ).coerceIn(0f, 1f)

        // Orthogonal stereo rotation preserves L² + R².
        val crossAngle = crossFeedback.coerceIn(0f, 0.5f) *
            (PI.toFloat() * 0.5f)

        val crossCos = cos(crossAngle)
        val crossSin = sin(crossAngle)

        for (line in 0 until LINE_COUNT) {
            val requestedDelay = (
                BASE_DELAYS[line].toFloat() *
                    delayScale *
                    sampleRate.toFloat() / 44100f
                ).toInt()

            delayLengths[line] = requestedDelay.coerceIn(
                1,
                bufferCapacity - 2
            )

            val delaySeconds =
                delayLengths[line].toFloat() / sampleRate.toFloat()

            val calculatedGain = 10.0.pow(
                (-3.0 * delaySeconds / decaySeconds).toDouble()
            ).toFloat()

            feedbackGains[line] = if (calculatedGain.isFinite()) {
                calculatedGain.coerceIn(0f, MAX_FEEDBACK)
            } else {
                0f
            }
        }

        val dryLevel = 1f - wet * 0.35f
        val wetLevel = wet * 0.72f

        val modulationDepth = if (settings.chorale) {
            sampleRate * 0.0015f
        } else {
            0f
        }

        val phaseIncrement = 0.23f / sampleRate.toFloat()

        val frameCount = minOf(
            inputLeft.size,
            inputRight.size,
            outputLeft.size,
            outputRight.size
        )

        for (i in 0 until frameCount) {
            val inputL = safeInput(inputLeft[i])
            val inputR = safeInput(inputRight[i])

            var reflectionsL = 0f
            var reflectionsR = 0f

            var triangle = 0f

            if (settings.chorale) {
                triangle = if (choralePhase < 0.5f) {
                    choralePhase * 4f - 1f
                } else {
                    3f - choralePhase * 4f
                }
            }

            val modulation = triangle * modulationDepth

            for (line in 0 until LINE_COUNT) {
                val signedModulation = if ((line and 1) == 0) {
                    modulation
                } else {
                    -modulation
                }

                var readPosition =
                    positions[line].toFloat() -
                        delayLengths[line].toFloat() +
                        signedModulation

                readPosition %= bufferCapacity.toFloat()

                if (readPosition < 0f) {
                    readPosition += bufferCapacity.toFloat()
                }

                val index0 = readPosition.toInt()
                    .coerceIn(0, bufferCapacity - 1)

                val index1 = (index0 + 1) % bufferCapacity
                val fraction = readPosition - index0.toFloat()

                val rawDelayedL =
                    leftBuffers[line][index0] +
                        (leftBuffers[line][index1] -
                            leftBuffers[line][index0]) * fraction

                val rawDelayedR =
                    rightBuffers[line][index0] +
                        (rightBuffers[line][index1] -
                            rightBuffers[line][index0]) * fraction

                var delayedL = safeInternal(rawDelayedL)
                var delayedR = safeInternal(rawDelayedR)

                if (settings.type == ReverbType.SPRING) {
                    // Bounded nonlinear response for Spring feedback.
                    delayedL /= 1f + abs(delayedL) * 0.12f
                    delayedR /= 1f + abs(delayedR) * 0.12f
                }

                val previousL = safeInternal(dampedLeft[line])
                val previousR = safeInternal(dampedRight[line])

                val filteredL = safeInternal(
                    previousL + damping * (delayedL - previousL)
                )

                val filteredR = safeInternal(
                    previousR + damping * (delayedR - previousR)
                )

                dampedLeft[line] = filteredL
                dampedRight[line] = filteredR

                feedbackLeft[line] = filteredL
                feedbackRight[line] = filteredR

                reflectionsL += filteredL * OUTPUT_SIGNS[line]
                reflectionsR += filteredR * OUTPUT_SIGNS[line]
            }

            // Normalized eight-line Hadamard feedback transform.
            var width = 1

            while (width < LINE_COUNT) {
                var start = 0

                while (start < LINE_COUNT) {
                    for (j in 0 until width) {
                        val aL = feedbackLeft[start + j]
                        val bL = feedbackLeft[start + j + width]

                        feedbackLeft[start + j] = aL + bL
                        feedbackLeft[start + j + width] = aL - bL

                        val aR = feedbackRight[start + j]
                        val bR = feedbackRight[start + j + width]

                        feedbackRight[start + j] = aR + bR
                        feedbackRight[start + j + width] = aR - bR
                    }

                    start += width * 2
                }

                width *= 2
            }

            for (line in 0 until LINE_COUNT) {
                val ownL = feedbackLeft[line] * NORMALIZATION
                val ownR = feedbackRight[line] * NORMALIZATION

                val mixedL = ownL * crossCos + ownR * crossSin
                val mixedR = ownR * crossCos - ownL * crossSin

                val nextL = safeInternal(
                    inputL * injection * INPUT_SIGNS[line] +
                        mixedL * feedbackGains[line]
                )

                val nextR = safeInternal(
                    inputR * injection * INPUT_SIGNS[line] +
                        mixedR * feedbackGains[line]
                )

                leftBuffers[line][positions[line]] = nextL
                rightBuffers[line][positions[line]] = nextR

                positions[line]++

                if (positions[line] >= bufferCapacity) {
                    positions[line] = 0
                }
            }

            val mixedOutputL = inputL * dryLevel +
                reflectionsL * reflectionLevel * wetLevel

            val mixedOutputR = inputR * dryLevel +
                reflectionsR * reflectionLevel * wetLevel

            outputLeft[i] = if (mixedOutputL.isFinite()) {
                mixedOutputL.coerceIn(-MAX_OUTPUT, MAX_OUTPUT)
            } else {
                inputL * dryLevel
            }

            outputRight[i] = if (mixedOutputR.isFinite()) {
                mixedOutputR.coerceIn(-MAX_OUTPUT, MAX_OUTPUT)
            } else {
                inputR * dryLevel
            }

            if (settings.chorale) {
                choralePhase += phaseIncrement

                if (choralePhase >= 1f) {
                    choralePhase -= 1f
                }
            }
        }
    }

    fun reset() {
        leftBuffers.forEach { it.fill(0f) }
        rightBuffers.forEach { it.fill(0f) }

        positions.fill(0)
        delayLengths.fill(0)
        dampedLeft.fill(0f)
        dampedRight.fill(0f)
        feedbackLeft.fill(0f)
        feedbackRight.fill(0f)
        feedbackGains.fill(0f)

        choralePhase = 0f
    }
}
