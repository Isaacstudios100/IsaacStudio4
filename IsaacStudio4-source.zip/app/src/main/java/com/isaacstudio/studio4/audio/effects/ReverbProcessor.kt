package com.isaacstudio.studio4.audio.effects

class ReverbProcessor(
    private val sampleRate: Int = 44100
) {
    @Volatile var enabled = false
    @Volatile var roomSize = 0.5f
    @Volatile var wetMix = 0.25f

    private val delayTimes = intArrayOf(1423, 1601, 1867, 2053)
    private val buffers = Array(delayTimes.size) { index ->
        FloatArray(delayTimes[index])
    }

    private var positions = IntArray(delayTimes.size)

    fun process(buffer: FloatArray) {
        if (!enabled) return

        val room = roomSize.coerceIn(0f, 1f)
        val wet = wetMix.coerceIn(0f, 1f)

        val feedback = 0.25f + room * 0.55f
        val dryLevel = 1f - wet * 0.5f

        for (i in buffer.indices) {
            val input = buffer[i]
            var reflections = 0f

            for (line in buffers.indices) {
                val delayBuffer = buffers[line]
                val position = positions[line]
                val delayed = delayBuffer[position]

                reflections += delayed

                delayBuffer[position] =
                    input * 0.25f + delayed * feedback

                positions[line] =
                    (position + 1) % delayBuffer.size
            }

            val reverbSignal = reflections * 0.25f

            buffer[i] = (
                input * dryLevel + reverbSignal * wet
            ).coerceIn(-1f, 1f)
        }
    }

    fun reset() {
        buffers.forEach { it.fill(0f) }
        positions = IntArray(buffers.size)
    }
}
