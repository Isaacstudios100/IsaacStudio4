package com.isaacstudio.studio4.audio.effects

import kotlin.math.pow

/**
 * Persistent stereo reverb processor.
 *
 * Each layer owns one instance. The processor keeps independent left/right
 * delay networks and receives an immutable settings snapshot per audio block.
 */
class ReverbProcessor(
    private val sampleRate: Int = 44100
) {
    companion object {
        private const val LINE_COUNT = 8
        private val BASE_DELAYS = intArrayOf(
            1423, 1601, 1867, 2053,
            2251, 2411, 2593, 2791
        )

        private val INPUT_SIGNS = floatArrayOf(
            1f, -1f, 1f, 1f, -1f, 1f, -1f, -1f
        )

        private val OUTPUT_SIGNS = floatArrayOf(
            1f, 1f, -1f, 1f, 1f, -1f, -1f, -1f
        )
    }

    private val bufferCapacity = (sampleRate * 0.14f).toInt().coerceAtLeast(512)

    private val leftBuffers = Array(LINE_COUNT) {
        FloatArray(bufferCapacity)
    }

    private val rightBuffers = Array(LINE_COUNT) {
        FloatArray(bufferCapacity)
    }

    private val positions = IntArray(LINE_COUNT)
    private val delayLengths = IntArray(LINE_COUNT)
    private val dampedLeft = FloatArray(LINE_COUNT)
    private val dampedRight = FloatArray(LINE_COUNT)
    private val feedbackLeft = FloatArray(LINE_COUNT)
    private val feedbackRight = FloatArray(LINE_COUNT)
    private val feedbackGains = FloatArray(LINE_COUNT)

    private var choralePhase = 0f

    /**
     * Processes stereo buffers in place or into separate output buffers.
     * Input and output arrays may be the same arrays.
     */
    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: ReverbSettings
    ) {
        if (!settings.enabled) return

        val room = settings.roomSize.coerceIn(0f, 1f)
        val wet = settings.wetMix.coerceIn(0f, 1f)

        val delayScale: Float
        val decayScale: Float
        val dampingBase: Float
        val crossFeedback: Float
        val injection: Float
        val reflectionLevel: Float

        when (settings.type) {
            ReverbType.ROOM -> {
                delayScale = 0.58f
                decayScale = 0.62f
                dampingBase = 0.72f
                crossFeedback = 0.12f
                injection = 0.22f
                reflectionLevel = 0.19f
            }
            ReverbType.BOOTH -> {
                delayScale = 0.39f
                decayScale = 0.34f
                dampingBase = 0.82f
                crossFeedback = 0.08f
                injection = 0.25f
                reflectionLevel = 0.22f
            }
            ReverbType.SPRING -> {
                delayScale = 0.27f
                decayScale = 0.72f
                dampingBase = 0.48f
                crossFeedback = 0.20f
                injection = 0.19f
                reflectionLevel = 0.24f
            }
            ReverbType.STAGE -> {
                delayScale = 0.82f
                decayScale = 0.92f
                dampingBase = 0.64f
                crossFeedback = 0.25f
                injection = 0.18f
                reflectionLevel = 0.18f
            }
            ReverbType.HALL -> {
                delayScale = 1.18f
                decayScale = 1.28f
                dampingBase = 0.57f
                crossFeedback = 0.34f
                injection = 0.16f
                reflectionLevel = 0.17f
            }
            ReverbType.CATHEDRAL -> {
                delayScale = 1.62f
                decayScale = 1.75f
                dampingBase = 0.49f
                crossFeedback = 0.42f
                injection = 0.14f
                reflectionLevel = 0.16f
            }
        }

        val decaySeconds = (0.45f + room * 5.55f) * decayScale
        val damping = if (settings.bright) {
            dampingBase * 0.38f
        } else {
            dampingBase
        }

        for (line in 0 until LINE_COUNT) {
            val requestedDelay = (
                BASE_DELAYS[line] * delayScale * sampleRate / 44100f
            ).toInt()

            delayLengths[line] = requestedDelay.coerceIn(
                1,
                bufferCapacity - 2
            )

            val delaySeconds = delayLengths[line].toFloat() / sampleRate
            feedbackGains[line] = 10.0.pow(
                (-3.0 * delaySeconds / decaySeconds).toDouble()
            ).toFloat().coerceIn(0f, 0.9995f)
        }

        val dryLevel = 1f - wet * 0.35f
        val wetLevel = wet * 0.72f
        val modulationDepth = if (settings.chorale) {
            sampleRate * 0.0015f
        } else {
            0f
        }
        val phaseIncrement = 0.23f / sampleRate

        val frameCount = minOf(
            inputLeft.size,
            inputRight.size,
            outputLeft.size,
            outputRight.size
        )

        for (i in 0 until frameCount) {
            val inputL = inputLeft[i]
            val inputR = inputRight[i]

            var reflectionsL = 0f
            var reflectionsR = 0f

            var triangle = 0f
            if (settings.chorale) {
                triangle = if (choralePhase < 0.5f) {
                    choralePhase * 4f - 1f
                } else {
                    3f - choralePhase * 4f
                }
            }

            val modulation = triangle * modulationDepth

            for (line in 0 until LINE_COUNT) {
                val signedModulation = if ((line and 1) == 0) {
                    modulation
                } else {
                    -modulation
                }

                var readPosition =
                    positions[line].toFloat() -
                    delayLengths[line] +
                    signedModulation

                while (readPosition < 0f) {
                    readPosition += bufferCapacity
                }
                while (readPosition >= bufferCapacity) {
                    readPosition -= bufferCapacity
                }

                val truncated = readPosition.toInt()
                val index0 = if (truncated > readPosition) {
                    truncated - 1
                } else {
                    truncated
                }
                val index1 = (index0 + 1) % bufferCapacity
                val fraction = readPosition - index0

                var delayedL = leftBuffers[line][index0] +
                    (leftBuffers[line][index1] -
                    leftBuffers[line][index0]) * fraction

                var delayedR = rightBuffers[line][index0] +
                    (rightBuffers[line][index1] -
                    rightBuffers[line][index0]) * fraction

                if (settings.type == ReverbType.SPRING) {
                    delayedL -= delayedL * delayedL * delayedL * 0.18f
                    delayedR -= delayedR * delayedR * delayedR * 0.18f
                }

                dampedLeft[line] += damping *
                    (delayedL - dampedLeft[line])
                dampedRight[line] += damping *
                    (delayedR - dampedRight[line])

                feedbackLeft[line] = dampedLeft[line]
                feedbackRight[line] = dampedRight[line]

                reflectionsL += dampedLeft[line] * OUTPUT_SIGNS[line]
                reflectionsR += dampedRight[line] * OUTPUT_SIGNS[line]
            }

            // Normalized eight-line Hadamard feedback transform.
            var width = 1
            while (width < LINE_COUNT) {
                var start = 0
                while (start < LINE_COUNT) {
                    for (j in 0 until width) {
                        val aL = feedbackLeft[start + j]
                        val bL = feedbackLeft[start + j + width]
                        feedbackLeft[start + j] = aL + bL
                        feedbackLeft[start + j + width] = aL - bL

                        val aR = feedbackRight[start + j]
                        val bR = feedbackRight[start + j + width]
                        feedbackRight[start + j] = aR + bR
                        feedbackRight[start + j + width] = aR - bR
                    }
                    start += width * 2
                }
                width *= 2
            }

            val normalization = 0.35355339f

            for (line in 0 until LINE_COUNT) {
                val ownL = feedbackLeft[line] * normalization
                val ownR = feedbackRight[line] * normalization

                val crossL = feedbackRight[line] *
                    normalization * crossFeedback
                val crossR = feedbackLeft[line] *
                    normalization * crossFeedback

                leftBuffers[line][positions[line]] =
                    inputL * injection * INPUT_SIGNS[line] +
                    (ownL + crossL) * feedbackGains[line]

                rightBuffers[line][positions[line]] =
                    inputR * injection * INPUT_SIGNS[line] +
                    (ownR + crossR) * feedbackGains[line]

                positions[line]++
                if (positions[line] >= bufferCapacity) {
                    positions[line] = 0
                }
            }

            outputLeft[i] = inputL * dryLevel +
                reflectionsL * reflectionLevel * wetLevel

            outputRight[i] = inputR * dryLevel +
                reflectionsR * reflectionLevel * wetLevel

            if (settings.chorale) {
                choralePhase += phaseIncrement
                if (choralePhase >= 1f) choralePhase -= 1f
            }
        }
    }

    fun reset() {
        leftBuffers.forEach { it.fill(0f) }
        rightBuffers.forEach { it.fill(0f) }
        positions.fill(0)
        dampedLeft.fill(0f)
        dampedRight.fill(0f)
        feedbackLeft.fill(0f)
        feedbackRight.fill(0f)
        feedbackGains.fill(0f)
        choralePhase = 0f
    }
}
