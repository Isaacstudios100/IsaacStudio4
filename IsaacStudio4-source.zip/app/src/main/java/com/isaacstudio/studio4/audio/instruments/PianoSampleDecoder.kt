package com.isaacstudio.studio4.audio.instruments

import android.content.res.AssetManager
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Decodes packaged mono Opus samples away from the audio render thread.
 */
internal class PianoSampleDecoder(
    private val assets: AssetManager
) {
    fun decode(id: PianoSampleId): PianoPcmSample? {
        val path = id.assetPath()
        return decodeWithMediaCodec(path)
            ?: decodeWithNative(path)
    }


    private fun decodeWithMediaCodec(path: String): PianoPcmSample? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            assets.openFd(path).use { fd ->
                extractor.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
            }
            var track = -1
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    track = i
                    break
                }
            }
            if (track < 0) return null
            extractor.selectTrack(track)
            val inputFormat = extractor.getTrackFormat(track)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val output = ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var outputFormat: MediaFormat? = null
            val deadline = android.os.SystemClock.elapsedRealtime() + 20_000L

            while (!outputDone && android.os.SystemClock.elapsedRealtime() < deadline) {
                if (!inputDone) {
                    val index = codec.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val buffer = codec.getInputBuffer(index) ?: return null
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(index, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val index = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> outputFormat = codec.outputFormat
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (index >= 0) {
                        val buffer = codec.getOutputBuffer(index)
                        if (buffer != null && info.size > 0) {
                            val chunk = buffer.duplicate()
                            chunk.position(info.offset)
                            chunk.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size)
                            chunk.get(bytes)
                            output.write(bytes)
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        codec.releaseOutputBuffer(index, false)
                    }
                }
            }
            val format = outputFormat ?: codec.outputFormat
            if (!outputDone || format.getInteger(MediaFormat.KEY_SAMPLE_RATE) != 48_000 ||
                format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) != 1 ||
                (format.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                 format.getInteger(MediaFormat.KEY_PCM_ENCODING) != AudioFormat.ENCODING_PCM_16BIT)
            ) return null

            val bytes = output.toByteArray()
            if (bytes.isEmpty() || bytes.size % 2 != 0) return null
            val pcm = ShortArray(bytes.size / 2)
            ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(pcm)
            return PianoPcmSample(pcm, 48_000)
        } catch (_: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    private fun decodeWithNative(path: String): PianoPcmSample? {
        return try {
            val data = assets.open(path).use { it.readBytes() }
            val pcm = NativeOpusDecoder.decodeOggToPcm16(data)
            if (pcm == null || pcm.isEmpty()) null
            else PianoPcmSample(pcm, 48_000)
        } catch (_: Exception) {
            null
        } catch (_: LinkageError) {
            null
        }
    }



}
