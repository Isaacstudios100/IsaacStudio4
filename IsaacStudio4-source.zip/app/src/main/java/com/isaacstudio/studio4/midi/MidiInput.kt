package com.isaacstudio.studio4.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import java.io.IOException

/**
 * Listens for USB MIDI devices and forwards note events.
 * Supports running status and messages split across packets.
 */
class MidiInput(
    context: Context,
private val onNoteOn: (note: Int, velocity: Float, deviceId: Int, channel: Int) -> Unit,
private val onNoteOff: (note: Int, deviceId: Int, channel: Int) -> Unit,
private val onSourceDisconnected: (deviceId: Int) -> Unit,
private val onStatus: (String) -> Unit
) {
    private val manager =
        context.getSystemService(Context.MIDI_SERVICE) as MidiManager

    private val handler = Handler(Looper.getMainLooper())

    private data class OpenMidiDevice(
        val device: MidiDevice,
        val port: MidiOutputPort
    )

    private val openDevices = mutableMapOf<Int, OpenMidiDevice>()
    private val openingDeviceIds = mutableSetOf<Int>()

    private var started = false

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            openDevice(info)
        }

override fun onDeviceRemoved(info: MidiDeviceInfo) {
    closeDevice(info.id)
    onSourceDisconnected(info.id)
    onStatus("MIDI keyboard disconnected")
}
    }

    /**
     * Each device gets its own receiver so MIDI messages
     * from separate devices cannot interfere with each other.
     */
private inner class NoteReceiver(
    private val deviceId: Int
) : MidiReceiver() {

        private var runningStatus = 0
        private var pendingStatus = 0
        private var expectedData = 0
        private var dataCount = 0
        private val messageData = IntArray(2)

        private var insideSysEx = false

        override fun onSend(
            data: ByteArray,
            offset: Int,
            count: Int,
            timestamp: Long
        ) {
            val end = (offset + count).coerceAtMost(data.size)

            for (i in offset until end) {
                val value = data[i].toInt() and 0xFF

                // MIDI real-time messages can appear anywhere.
                if (value >= 0xF8) {
                    continue
                }

                // Ignore the contents of System Exclusive messages.
                if (insideSysEx) {
                    if (value == 0xF7) {
                        insideSysEx = false
                    }
                    continue
                }

                // A new status byte.
                if ((value and 0x80) != 0) {

                    // Start of System Exclusive.
                    if (value == 0xF0) {
                        insideSysEx = true
                        runningStatus = 0
                        pendingStatus = 0
                        dataCount = 0
                        continue
                    }

                    if (value in 0x80..0xEF) {
                        // Channel message.
                        runningStatus = value
                        pendingStatus = value
                        expectedData = if (
                            (value and 0xF0) == 0xC0 ||
                            (value and 0xF0) == 0xD0
                        ) 1 else 2

                        dataCount = 0
                    } else {
                        // System Common messages cancel running status.
                        runningStatus = 0
                        dataCount = 0

                        expectedData = when (value) {
                            0xF1, 0xF3 -> 1
                            0xF2 -> 2
                            else -> 0
                        }

                        pendingStatus =
                            if (expectedData > 0) value else 0
                    }

                    continue
                }

                // Ignore data bytes without a valid status.
                if (pendingStatus == 0) {
                    if (runningStatus == 0) continue

                    pendingStatus = runningStatus
                    expectedData = if (
                        (runningStatus and 0xF0) == 0xC0 ||
                        (runningStatus and 0xF0) == 0xD0
                    ) 1 else 2

                    dataCount = 0
                }

                if (dataCount < messageData.size) {
                    messageData[dataCount] = value and 0x7F
                    dataCount++
                }

                if (dataCount >= expectedData) {
                    processMessage(
                        pendingStatus,
                        messageData[0],
                        if (expectedData > 1) messageData[1] else 0
                    )

                    dataCount = 0

                    // Channel messages may continue using running status.
                    pendingStatus =
                        if (pendingStatus in 0x80..0xEF) {
                            runningStatus
                        } else {
                            0
                        }
                }
            }
        }

private fun processMessage(
    status: Int,
    data1: Int,
    data2: Int
) {
    val type = status and 0xF0
    val channel = status and 0x0F

    when (type) {
        0x90 -> {
            if (data2 > 0) {
                handler.post {
                    if (started) {
                        onNoteOn(
                            data1,
                            data2 / 127f,
                            deviceId,
                            channel
                        )
                    }
                }
            } else {
                handler.post {
                    if (started) {
                        onNoteOff(data1, deviceId, channel)
                    }
                }
            }
        }

        0x80 -> {
            handler.post {
                if (started) {
                    onNoteOff(data1, deviceId, channel)
                }
            }
        }
    }
}
    }

    fun start() {
        if (started) return

        started = true

        manager.registerDeviceCallback(deviceCallback, handler)

        val devices = manager.devices

        devices.forEach { info ->
            openDevice(info)
        }

        if (devices.none { it.outputPortCount > 0 }) {
            onStatus("No MIDI keyboard connected")
        }
    }

    fun stop() {
        if (started) {
            started = false
            try {
                manager.unregisterDeviceCallback(deviceCallback)
            } catch (_: Exception) {
            }
        }

        openingDeviceIds.clear()

        openDevices.keys.toList().forEach { id ->
            closeDevice(id)
        }
    }

    private fun openDevice(info: MidiDeviceInfo) {
        if (!started) return
        if (info.outputPortCount == 0) return
        if (openDevices.containsKey(info.id)) return
        if (!openingDeviceIds.add(info.id)) return

        val name = info.properties.getString(
            MidiDeviceInfo.PROPERTY_NAME
        ) ?: "MIDI device"

        manager.openDevice(
            info,
            MidiManager.OnDeviceOpenedListener { device ->

                val wasOpening = openingDeviceIds.remove(info.id)

                if (device == null) {
                    if (started && wasOpening) {
                        onStatus("Could not open $name")
                    }
                    return@OnDeviceOpenedListener
                }

                // Reject devices removed or stopped while opening.
                if (!started || !wasOpening) {
                    try {
                        device.close()
                    } catch (_: IOException) {
                    }
                    return@OnDeviceOpenedListener
                }

                val port = device.openOutputPort(0)

                if (port == null) {
                    try {
                        device.close()
                    } catch (_: IOException) {
                    }

                    onStatus("No output port on $name")
                    return@OnDeviceOpenedListener
                }

                try {
port.connect(NoteReceiver(info.id))

                    openDevices[info.id] = OpenMidiDevice(
                        device = device,
                        port = port
                    )

                    onStatus("MIDI keyboard: $name")

                } catch (_: IOException) {
                    try {
                        port.close()
                    } catch (_: IOException) {
                    }

                    try {
                        device.close()
                    } catch (_: IOException) {
                    }

                    onStatus("Could not connect to $name")
                }
            },
            handler
        )
    }

    private fun closeDevice(id: Int) {
        openingDeviceIds.remove(id)

        val connection = openDevices.remove(id) ?: return

        try {
            connection.port.close()
        } catch (_: IOException) {
        }

        try {
            connection.device.close()
        } catch (_: IOException) {
        }
    }
}
