
package com.isaacstudio.studio4.audio

import java.util.ArrayDeque
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

enum class Waveform {
    SINE, TRIANGLE, SAWTOOTH, SQUARE
}

class SynthEngine : AudioRenderer {

    @Volatile
    override var isRenderingEnabled = true

    private val sampleRate = 44100
    private val voices = Array(16) { Voice() }

    // Note events are queued separately from audio rendering.
    private val eventLock = Any()
    private val pendingEvents = ArrayDeque<NoteEvent>()
    private val eventBatch = arrayOfNulls<NoteEvent>(256)

    private var nextVoiceId = 1L

    @Volatile var volume = 0.7f
    @Volatile var layerVolume = 1.0f
    @Volatile var waveform = Waveform.SAWTOOTH
    @Volatile var transposeSemitones = 0

    @Volatile var attack = 0.005f
    @Volatile var decay = 0.12f
    @Volatile var sustain = 0.7f
    @Volatile var release = 0.3f

@Volatile
var oscillatorSettings = SynthOscillatorSettings()

    private enum class Stage {
        OFF, ATTACK, DECAY, SUSTAIN, RELEASE
    }

    private class Voice {
        var voiceId = 0L
        var note = -1
        var sourceNote = -1
var freq = 0.0
var velocity = 0f

// Independent oscillator phases.
var phase = 0.0
var phaseB = 0.0

var env = 0.0
        var releaseLevel = 0.0
        var releaseStep = 0.0
        var stage = Stage.OFF
    }

    private data class NoteEvent(
        val type: Int,
        val voiceId: Long = 0L,
        val sourceNote: Int = 0,
        val playedNote: Int = 0,
        val velocity: Float = 0f
    )

    companion object {
        private const val EVENT_NOTE_ON = 1
        private const val EVENT_NOTE_OFF = 2
        private const val EVENT_NOTE_OFF_VOICE = 3
    }

    fun start() {
        isRenderingEnabled = true
    }

    fun stop() {
        isRenderingEnabled = false
    }

    fun noteOn(note: Int, velocity: Float): Long {
        synchronized(eventLock) {
            val voiceId = nextVoiceId++

            val playedNote = note + transposeSemitones

            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_ON,
                    voiceId = voiceId,
                    sourceNote = note,
                    playedNote = playedNote,
                    velocity = velocity.coerceIn(0f, 1f)
                )
            )

            return voiceId
        }
    }

    fun noteOff(note: Int) {
        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF,
                    sourceNote = note
                )
            )
        }
    }

    fun noteOffVoice(voiceId: Long) {
        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF_VOICE,
                    voiceId = voiceId
                )
            )
        }
    }

    private fun processEvent(event: NoteEvent) {

        when (event.type) {

            EVENT_NOTE_ON -> {

                val voice =
                    voices.firstOrNull { it.stage == Stage.OFF }
                        ?: voices.firstOrNull { it.stage == Stage.RELEASE }
                        ?: voices[0]

                voice.voiceId = event.voiceId
                voice.note = event.playedNote
                voice.sourceNote = event.sourceNote

                voice.freq = 440.0 * 2.0.pow(
                    (event.playedNote - 69) / 12.0
                )

voice.velocity = event.velocity
voice.phase = 0.0
voice.phaseB = 0.0
voice.env = 0.0
                voice.releaseLevel = 0.0
                voice.releaseStep = 0.0
                voice.stage = Stage.ATTACK
            }

            EVENT_NOTE_OFF -> {

                for (voice in voices) {
                    if (
                        voice.sourceNote == event.sourceNote &&
                        voice.stage != Stage.OFF &&
                        voice.stage != Stage.RELEASE
                    ) {
                        voice.releaseLevel = voice.env
                        voice.releaseStep =
                            voice.releaseLevel /
                            (release.coerceAtLeast(0.01f) * sampleRate)

                        voice.stage = Stage.RELEASE
                    }
                }
            }

            EVENT_NOTE_OFF_VOICE -> {

                val voice = voices.firstOrNull {
                    it.voiceId == event.voiceId &&
                    it.stage != Stage.OFF &&
                    it.stage != Stage.RELEASE
                }

                if (voice != null) {
                    voice.releaseLevel = voice.env
                    voice.releaseStep =
                        voice.releaseLevel /
                        (release.coerceAtLeast(0.01f) * sampleRate)

                    voice.stage = Stage.RELEASE
                }
            }
        }
    }

    private fun processPendingEvents() {

        var eventCount = 0

        synchronized(eventLock) {
            while (eventCount < eventBatch.size) {
                val event = pendingEvents.pollFirst() ?: break

                eventBatch[eventCount] = event
                eventCount++
            }
        }

        for (i in 0 until eventCount) {
            val event = eventBatch[i] ?: continue

            processEvent(event)

            eventBatch[i] = null
        }
    }

    private fun waveformSample(
        phase: Double,
        currentWaveform: Waveform
    ): Double {

        return when (currentWaveform) {

            Waveform.SINE ->
                sin(2.0 * PI * phase)

            Waveform.TRIANGLE ->
                1.0 - 4.0 * abs(phase - 0.5)

            Waveform.SAWTOOTH ->
                2.0 * phase - 1.0

            Waveform.SQUARE ->
                if (phase < 0.5) 1.0 else -1.0
        }
    }

    private fun oscillatorFrequency(
        baseFrequency: Double,
        config: SynthOscillatorConfig
    ): Double {
        val cents =
            (config.semitone * 100.0) +
            config.fineTune.toDouble() +
            config.detune.toDouble()

        return baseFrequency * 2.0.pow(cents / 1200.0)
    }

    private fun oscillatorSample(
        phase: Double,
        config: SynthOscillatorConfig
    ): Double {
        return waveformSample(
            phase,
            config.waveform
        ) * config.level.coerceIn(0f, 1f)
    }

    private fun oscillatorGainA(mix: Float): Double {
        val balance = mix.coerceIn(0f, 1f).toDouble()
        return sqrt(1.0 - balance)
    }

    private fun oscillatorGainB(mix: Float): Double {
        val balance = mix.coerceIn(0f, 1f).toDouble()
        return sqrt(balance)
    }

    override fun renderInto(buffer: FloatArray) {
        if (!isRenderingEnabled) return

        // Process queued note commands on the audio thread.
        processPendingEvents()

        // Cache existing controls once per audio block.
        val currentWaveform = waveform
        val currentVolume = volume.coerceIn(0f, 1f)
        val currentLayerVolume = layerVolume.coerceIn(0f, 1f)

        // Cache oscillator settings once per audio block.
        val settings = oscillatorSettings
        val useDualOscillators = settings.enabled

        val oscillatorA = settings.oscillatorA
        val oscillatorB = settings.oscillatorB

        val gainA = oscillatorGainA(settings.oscillatorMix)
        val gainB = oscillatorGainB(settings.oscillatorMix)

        val frequencyRatioA =
            oscillatorFrequency(1.0, oscillatorA)

        val frequencyRatioB =
            oscillatorFrequency(1.0, oscillatorB)

        val levelA = oscillatorA.level.coerceIn(0f, 1f)
        val levelB = oscillatorB.level.coerceIn(0f, 1f)

        val attackStep =
            1.0 / (attack.coerceAtLeast(0.001f) * sampleRate)

        val currentSustain =
            sustain.coerceIn(0f, 1f).toDouble()

        val decayStep =
            (1.0 - currentSustain) /
            (decay.coerceAtLeast(0.001f) * sampleRate)

        val outputGain =
            currentVolume * currentLayerVolume * 0.2

        for (i in buffer.indices) {
            var mix = 0.0

            for (voice in voices) {
                if (voice.stage == Stage.OFF) continue

                when (voice.stage) {
                    Stage.ATTACK -> {
                        voice.env = minOf(
                            1.0,
                            voice.env + attackStep
                        )

                        if (voice.env >= 1.0) {
                            voice.stage = Stage.DECAY
                        }
                    }

                    Stage.DECAY -> {
                        voice.env = maxOf(
                            currentSustain,
                            voice.env - decayStep
                        )

                        if (voice.env <= currentSustain) {
                            voice.stage = Stage.SUSTAIN
                        }
                    }

                    Stage.SUSTAIN -> {
                        voice.env = currentSustain
                    }

                    Stage.RELEASE -> {
                        voice.env = maxOf(
                            0.0,
                            voice.env - voice.releaseStep
                        )

                        if (voice.env <= 0.0) {
                            voice.note = -1
                            voice.sourceNote = -1
                            voice.stage = Stage.OFF
                            continue
                        }
                    }

                    Stage.OFF -> continue
                }

                val tone: Double

                if (useDualOscillators) {
                    val toneA =
                        waveformSample(
                            voice.phase,
                            oscillatorA.waveform
                        ) * levelA

                    val toneB =
                        waveformSample(
                            voice.phaseB,
                            oscillatorB.waveform
                        ) * levelB

                    tone = toneA * gainA + toneB * gainB

                    voice.phase +=
                        voice.freq * frequencyRatioA / sampleRate

                    voice.phaseB +=
                        voice.freq * frequencyRatioB / sampleRate

                    if (voice.phaseB >= 1.0) {
                        voice.phaseB -= 1.0
                    }
                } else {
                    // Original single-oscillator sound path.
                    tone = waveformSample(
                        voice.phase,
                        currentWaveform
                    )

                    voice.phase += voice.freq / sampleRate
                }

                mix += tone * voice.env * voice.velocity

                if (voice.phase >= 1.0) {
                    voice.phase -= 1.0
                }
            }

            buffer[i] += (mix * outputGain).toFloat()
        }
    }
}

