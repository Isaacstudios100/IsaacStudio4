
package com.isaacstudio.studio4.audio.instruments

import com.isaacstudio.studio4.audio.AudioRenderer
import java.util.ArrayDeque
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

class PianoEngine : AudioRenderer {

    @Volatile
    override var isRenderingEnabled = true

    @Volatile
    var layerVolume = 1.0f

    @Volatile
    var soundModel: PianoSoundModel = PianoSoundModel.STUDIO_GRAND

    companion object {
private const val SINE_TABLE_SIZE = 4096
private const val SINE_TABLE_MASK = SINE_TABLE_SIZE - 1

private val SINE_TABLE = DoubleArray(SINE_TABLE_SIZE) { index ->
    sin(2.0 * PI * index / SINE_TABLE_SIZE)
}
private fun fastSin(angle: Double): Double {
    val position = angle * (SINE_TABLE_SIZE / (2.0 * PI))
    val basePosition = position.toInt()
    val index = basePosition and SINE_TABLE_MASK
    val nextIndex = (index + 1) and SINE_TABLE_MASK
    val fraction = position - basePosition

    return SINE_TABLE[index] +
        (SINE_TABLE[nextIndex] - SINE_TABLE[index]) * fraction
}
        private const val SAMPLE_RATE = 44100
        private const val VOICE_COUNT = 16

        private const val EVENT_NOTE_ON = 1
        private const val EVENT_NOTE_OFF = 2
        private const val EVENT_NOTE_OFF_VOICE = 3
        private const val EVENT_SET_MIDI_CONTROLS = 4

        private const val ATTACK_SAMPLES = 264L

        private val ENVELOPE_DECAY_STEP =
            exp(-0.55 / SAMPLE_RATE)

        private val RELEASE_DECAY_STEP =
            exp(-12.0 / SAMPLE_RATE)

private val HAMMER_DECAY_STEP =
    exp(-85.0 / SAMPLE_RATE)

        private val ATTACK_ENVELOPE = DoubleArray(
            ATTACK_SAMPLES.toInt()
        ) { age ->
            (age.toDouble() / ATTACK_SAMPLES) *
                exp(-(age.toDouble() / SAMPLE_RATE) * 0.55)
        }

        private val ATTACK_END_ENVELOPE =
            exp(-(ATTACK_SAMPLES.toDouble() / SAMPLE_RATE) * 0.55)

        private val HARMONIC_NUMBERS =
            doubleArrayOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0)

        private val HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.42, 0.21, 0.11, 0.055, 0.025)

        private val BRIGHT_HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.62, 0.38, 0.24, 0.15, 0.09)

        private val SOFT_HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.20, 0.075, 0.025, 0.009, 0.003)

        private val ELECTRIC_HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.78, 0.62, 0.45, 0.30, 0.18)

        private val ELECTRIC_PARTIAL_RATIOS =
            doubleArrayOf(1.0, 2.76, 5.40, 8.93, 13.3, 18.6)

        private val HARMONIC_DECAY_RATES =
            doubleArrayOf(0.65, 2.0, 3.8, 5.8, 8.0, 10.0)

        private val HARMONIC_DECAY_STEPS =
            DoubleArray(6) {
                exp(-HARMONIC_DECAY_RATES[it] / SAMPLE_RATE)
            }
    }

    private data class Voice(
        var soundModel: PianoSoundModel = PianoSoundModel.STUDIO_GRAND,
        var limitPartialsAtNyquist: Boolean = false,
        var voiceId: Long = 0L,
        var note: Int = -1,
        var phase: Double = 0.0,
        var frequency: Double = 440.0,
        var inharmonicity: Double = 0.00006,
        var velocity: Double = 0.0,
        var midiPitchBendSemitones: Double = 0.0,
        var midiGain: Double = 1.0,
        var midiModulation: Double = 0.0,
        var midiModPhase: Double = 0.0,
        var age: Long = 0L,
        var active: Boolean = false,
        var releasing: Boolean = false,
        var releaseLevel: Double = 1.0,
        var releaseAge: Long = 0L,

        var envelopeValue: Double = 0.0,
        var releaseAmplitude: Double = 0.0,
        var hammerDecay: Double = 1.0,

val harmonicRatios: DoubleArray = DoubleArray(6),
val harmonicBrightness: DoubleArray = DoubleArray(6),
val harmonicDecay: DoubleArray = DoubleArray(6),
        val harmonicDecaySteps: DoubleArray = DoubleArray(6),
        var envelopeDecayStep: Double = ENVELOPE_DECAY_STEP,
        var attackSamples: Long = ATTACK_SAMPLES,
        var attackDecayRate: Double = 0.55,
        var useOriginalAttack: Boolean = true,
        var hammerDecayStep: Double = HAMMER_DECAY_STEP,
        var hammerFundamentalRatio: Double = 7.3,
        var hammerUpperRatio: Double = 9.1,
        var hammerFundamentalLevel: Double = 0.075,
        var hammerUpperLevel: Double = 0.035
    )

    private data class NoteEvent(
        val type: Int,
        val voiceId: Long = 0L,
        val note: Int = 0,
        val velocity: Float = 0.8f,
        val pitchBendSemitones: Double = 0.0,
        val midiGain: Double = 1.0,
        val modulation: Double = 0.0
    )

    private val voices = Array(VOICE_COUNT) { Voice() }

    // Note events are separated from audio rendering.
    private val eventLock = Any()
    private val pendingEvents = ArrayDeque<NoteEvent>()
    private val eventBatch = arrayOfNulls<NoteEvent>(256)

    private var nextVoiceId = 1L

    fun start() {
        isRenderingEnabled = true
    }

    fun stop() {
        isRenderingEnabled = false
    }

    fun noteOn(note: Int, velocity: Float = 0.8f): Long {

        synchronized(eventLock) {
            val voiceId = nextVoiceId++

            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_ON,
                    voiceId = voiceId,
                    note = note.coerceIn(0, 127),
                    velocity = velocity.coerceIn(0f, 1f)
                )
            )

            return voiceId
        }
    }

    fun noteOff(note: Int) {

        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF,
                    note = note
                )
            )
        }
    }

    fun setMidiControls(
        voiceId: Long,
        pitchBendSemitones: Double,
        gain: Double,
        modulation: Double
    ) {
        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_SET_MIDI_CONTROLS,
                    voiceId = voiceId,
                    pitchBendSemitones = pitchBendSemitones.coerceIn(-2.0, 2.0),
                    midiGain = gain.coerceIn(0.0, 1.0),
                    modulation = modulation.coerceIn(0.0, 1.0)
                )
            )
        }
    }
    
    fun noteOffVoice(voiceId: Long) {

        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF_VOICE,
                    voiceId = voiceId
                )
            )
        }
    }

    private fun initializeVoice(
        voice: Voice,
        event: NoteEvent
    ) {
        val safeNote = event.note
        val model = soundModel
        val profile = PianoSoundProfiles.forModel(model)

        voice.soundModel = model
        voice.limitPartialsAtNyquist = profile.limitPartialsAtNyquist

        voice.voiceId = event.voiceId
        voice.midiPitchBendSemitones = 0.0
        voice.midiGain = 1.0
        voice.midiModulation = 0.0
        voice.midiModPhase = 0.0
        voice.note = safeNote
        voice.phase = 0.0

        voice.frequency = 440.0 * 2.0.pow(
            (safeNote - 69) / 12.0
        )

        val baseInharmonicity = (
            0.00006 * sqrt(voice.frequency / 440.0)
        ).coerceIn(0.00004, 0.00035)

        voice.inharmonicity = (
            baseInharmonicity * profile.inharmonicityScale
        ).coerceIn(0.00004, 0.0008)

        voice.velocity = event.velocity.toDouble()
        voice.useOriginalAttack = profile.useOriginalAttack
        voice.attackSamples = profile.attackSamples
        voice.attackDecayRate = profile.attackDecayRate

        val brightness = 0.55 + voice.velocity * 0.90

        voice.envelopeDecayStep = if (profile.useOriginalAttack) {
            ENVELOPE_DECAY_STEP
        } else {
            exp(-profile.envelopeDecayRate / SAMPLE_RATE)
        }

        voice.hammerDecayStep = if (profile.useOriginalAttack) {
            HAMMER_DECAY_STEP
        } else {
            exp(-profile.hammerDecayRate / SAMPLE_RATE)
        }

        voice.hammerFundamentalRatio = profile.hammerFundamentalRatio
        voice.hammerUpperRatio = profile.hammerUpperRatio
        voice.hammerFundamentalLevel = profile.hammerFundamentalLevel
        voice.hammerUpperLevel = profile.hammerUpperLevel

        for (h in 0..5) {
            val harmonic = HARMONIC_NUMBERS[h]
            val partial = profile.partialRatios?.get(h) ?: harmonic.toDouble()

            voice.harmonicRatios[h] = if (profile.partialRatios != null) {
                partial * sqrt(
                    1.0 + voice.inharmonicity * partial * partial
                )
            } else {
                sqrt(
                    1.0 + voice.inharmonicity * harmonic * harmonic
                ) * harmonic
            }

            voice.harmonicBrightness[h] =
                profile.harmonicAmplitudes[h] *
                brightness.pow(1.0 + h * 0.5)

            voice.harmonicDecaySteps[h] = if (
                profile.useOriginalHarmonicDecay
            ) {
                HARMONIC_DECAY_STEPS[h]
            } else {
                exp(
                    -(HARMONIC_DECAY_RATES[h] * profile.decayRateScale) /
                        SAMPLE_RATE
                )
            }

            voice.harmonicDecay[h] = 1.0
        }

        voice.age = 0L
        voice.active = true
        voice.releasing = false

        voice.releaseLevel = 1.0
        voice.releaseAge = 0L

        voice.envelopeValue = 0.0
        voice.releaseAmplitude = 0.0
        voice.hammerDecay = 1.0
    }

    private fun releaseVoice(voice: Voice) {

        if (!voice.active || voice.releasing) return

        voice.releasing = true
        voice.releaseLevel = voice.envelopeValue
        voice.releaseAmplitude = voice.envelopeValue
        voice.releaseAge = 0L
    }

    private fun processEvent(event: NoteEvent) {

        when (event.type) {

            EVENT_NOTE_ON -> {

                val voice =
                    voices.firstOrNull { !it.active }
                        ?: voices.firstOrNull { it.releasing }
                        ?: voices.maxByOrNull { it.age }

                if (voice != null) {
                    initializeVoice(voice, event)
                }
            }

            EVENT_NOTE_OFF -> {

                for (voice in voices) {
                    if (voice.active && voice.note == event.note) {
                        releaseVoice(voice)
                    }
                }
            }

            EVENT_SET_MIDI_CONTROLS -> {
                val voice = voices.firstOrNull {
                    it.active && it.voiceId == event.voiceId
                }
                if (voice != null) {
                    voice.midiPitchBendSemitones = event.pitchBendSemitones
                    voice.midiGain = event.midiGain
                    voice.midiModulation = event.modulation
                }
            }
            
            EVENT_NOTE_OFF_VOICE -> {

                val voice = voices.firstOrNull {
                    it.active && it.voiceId == event.voiceId
                }

                if (voice != null) {
                    releaseVoice(voice)
                }
            }
        }
    }

    private fun processPendingEvents() {

        var eventCount = 0

        synchronized(eventLock) {
            while (eventCount < eventBatch.size) {

                val event = pendingEvents.pollFirst() ?: break

                eventBatch[eventCount] = event
                eventCount++
            }
        }

        for (i in 0 until eventCount) {

            val event = eventBatch[i] ?: continue

            processEvent(event)

            eventBatch[i] = null
        }
    }

    override fun renderInto(buffer: FloatArray) {

        if (!isRenderingEnabled) return

        processPendingEvents()

        val currentLayerVolume =
            layerVolume.coerceIn(0f, 1f)

        val outputGain = 0.12 * currentLayerVolume

        for (i in buffer.indices) {

            var sample = 0.0

            for (voice in voices) {

                if (!voice.active) continue

                // Update the original piano envelope.
                val amplitude: Double

                if (voice.releasing) {

                    amplitude = voice.releaseAmplitude

                    voice.releaseAmplitude *= RELEASE_DECAY_STEP
                    voice.releaseAge++

                } else {

                    when {
                        voice.age < voice.attackSamples -> {
                            voice.envelopeValue =
                                if (voice.useOriginalAttack) {
                                    ATTACK_ENVELOPE[voice.age.toInt()]
                                } else {
                                    (voice.age.toDouble() /
                                        voice.attackSamples) *
                                        exp(
                                            -(voice.age.toDouble() /
                                                SAMPLE_RATE) *
                                                voice.attackDecayRate
                                        )
                                }
                        }

                        voice.age == voice.attackSamples -> {
                            voice.envelopeValue =
                                if (voice.useOriginalAttack) {
                                    ATTACK_END_ENVELOPE
                                } else {
                                    exp(
                                        -(voice.attackSamples.toDouble() /
                                            SAMPLE_RATE) *
                                            voice.attackDecayRate
                                    )
                                }
                        }

                        else -> {
                            voice.envelopeValue *= voice.envelopeDecayStep
                        }
                    }

                    amplitude = voice.envelopeValue
                }

                val midiVibratoSemitones =
                    kotlin.math.sin(voice.midiModPhase * 2.0 * kotlin.math.PI) *
                    0.5 * voice.midiModulation
                voice.midiModPhase += 5.0 / SAMPLE_RATE
                if (voice.midiModPhase >= 1.0) voice.midiModPhase -= 1.0
                val midiFrequencyMultiplier = 2.0.pow(
                    (voice.midiPitchBendSemitones + midiVibratoSemitones) / 12.0
                )
                val bentFrequency = voice.frequency * midiFrequencyMultiplier
                val angle = 2.0 * PI * voice.phase

                // Six harmonics retain their original inharmonic character.
                var tone = 0.0

                for (h in 0..5) {
                    val partialFrequency =
                        bentFrequency * voice.harmonicRatios[h]

                    if (
                        !voice.limitPartialsAtNyquist ||
                        partialFrequency < SAMPLE_RATE * 0.5
                    ) {
                        tone += fastSin(
                            angle * voice.harmonicRatios[h]
                        ) *
                            voice.harmonicBrightness[h] *
                            voice.harmonicDecay[h]
                    }

                    voice.harmonicDecay[h] *=
                        voice.harmonicDecaySteps[h]
                }

                // Preserve the original hammer transient.
                val hammerTransient =
                    voice.hammerDecay *
                    (
                        fastSin(angle * voice.hammerFundamentalRatio) *
                            voice.hammerFundamentalLevel +
                        fastSin(angle * voice.hammerUpperRatio) *
                            voice.hammerUpperLevel
                    ) *
                    (0.25 + voice.velocity)

                voice.hammerDecay *= voice.hammerDecayStep

                sample += (
                    tone + hammerTransient
                ) * amplitude * voice.velocity * voice.midiGain

                voice.phase += bentFrequency / SAMPLE_RATE

                if (voice.phase >= 1.0) {
                    voice.phase -= 1.0
                }

                voice.age++

                if (voice.releasing && amplitude < 0.001) {
                    voice.active = false
                    voice.note = -1
                }
            }

            buffer[i] += (
                sample * outputGain
            ).coerceIn(-1.0, 1.0).toFloat()
        }
    }
}

