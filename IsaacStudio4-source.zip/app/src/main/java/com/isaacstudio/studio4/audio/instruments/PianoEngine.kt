
package com.isaacstudio.studio4.audio.instruments

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import com.isaacstudio.studio4.audio.effects.ReverbProcessor

class PianoEngine {

    companion object {
        private const val SAMPLE_RATE = 44100
        private const val VOICE_COUNT = 16
    }

    private data class Voice(
var voiceId: Long = 0L,
        var note: Int = -1,
        var phase: Double = 0.0,
        var frequency: Double = 440.0,
        var inharmonicity: Double = 0.00006,
        var velocity: Double = 0.0,
        var age: Long = 0,
        var active: Boolean = false,
        var releasing: Boolean = false,
        var releaseLevel: Double = 1.0,
        var releaseAge: Long = 0
    )

    private val voices = Array(VOICE_COUNT) { Voice() }
private var nextVoiceId = 1L
    private val reverb = ReverbProcessor()
    private val lifecycleLock = Any()

    @Volatile
    private var running = false

    private var audioTrack: AudioTrack? = null
    private var renderThread: Thread? = null

    fun configureReverb(
        enabled: Boolean,
        roomSize: Float,
        wetMix: Float
    ) {
        reverb.enabled = enabled
        reverb.roomSize = roomSize
        reverb.wetMix = wetMix
    }

    fun start() {
        synchronized(lifecycleLock) {
            if (running) return

            val minBuffer = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_FLOAT
            )

            if (minBuffer <= 0) return

            val newTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuffer, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            if (newTrack.state != AudioTrack.STATE_INITIALIZED) {
                newTrack.release()
                return
            }

            audioTrack = newTrack
            running = true

            try {
                newTrack.play()

                renderThread = Thread(
                    { renderAudio() },
                    "IsaacStudio4-Piano"
                ).apply {
                    priority = Thread.MAX_PRIORITY
                    start()
                }

            } catch (error: Exception) {
                running = false
                audioTrack = null
                renderThread = null

                try {
                    newTrack.release()
                } catch (_: Exception) {
                }
            }
        }
    }

fun noteOn(note: Int, velocity: Float = 0.8f): Long {
    return synchronized(voices) {
        val safeNote = note.coerceIn(0, 127)

        val voice = voices.firstOrNull { !it.active }
            ?: voices.firstOrNull { it.releasing }
            ?: voices.maxByOrNull { it.age }

        if (voice == null) {
            0L
        } else {
            voice.apply {
                voiceId = nextVoiceId++
                this.note = safeNote
                phase = 0.0

                frequency = 440.0 *
                    2.0.pow((safeNote - 69) / 12.0)

                inharmonicity = (
                    0.00006 * sqrt(frequency / 440.0)
                ).coerceIn(0.00004, 0.00035)

                this.velocity = velocity.coerceIn(0f, 1f).toDouble()

                age = 0
                active = true
                releasing = false
                releaseLevel = 1.0
                releaseAge = 0
            }

            voice.voiceId
        }
    }
}

    fun noteOff(note: Int) {
        synchronized(voices) {
            voices.filter {
                it.active && it.note == note && !it.releasing
            }.forEach {
                it.releasing = true
                it.releaseLevel = envelope(it.age)
                it.releaseAge = 0
            }
        }
    }

fun noteOffVoice(voiceId: Long) {
    synchronized(voices) {
        val voice = voices.firstOrNull {
            it.active &&
                it.voiceId == voiceId &&
                !it.releasing
        } ?: return

        voice.releasing = true
        voice.releaseLevel = envelope(voice.age)
        voice.releaseAge = 0
    }
}
    private fun envelope(age: Long): Double {
        val seconds = age.toDouble() / SAMPLE_RATE
        val attack = (seconds / 0.006).coerceIn(0.0, 1.0)

        return attack * exp(-seconds * 0.55)
    }

    private fun renderAudio() {
        val buffer = FloatArray(512)

        while (running) {
            synchronized(voices) {
                for (i in buffer.indices) {
                    var sample = 0.0

                    for (voice in voices) {
                        if (!voice.active) continue

                        val angle = 2.0 * PI * voice.phase
                        val seconds = voice.age.toDouble() / SAMPLE_RATE

                        val brightness = 0.55 + voice.velocity * 0.90

                        val harmonic1 = sin(angle)

                        val harmonic2 = sin(
                            angle * 2.0 * sqrt(
                                1.0 + voice.inharmonicity * 4.0
                            )
                        )

                        val harmonic3 = sin(
                            angle * 3.0 * sqrt(
                                1.0 + voice.inharmonicity * 9.0
                            )
                        )

                        val harmonic4 = sin(
                            angle * 4.0 * sqrt(
                                1.0 + voice.inharmonicity * 16.0
                            )
                        )

                        val harmonic5 = sin(
                            angle * 5.0 * sqrt(
                                1.0 + voice.inharmonicity * 25.0
                            )
                        )

                        val harmonic6 = sin(
                            angle * 6.0 * sqrt(
                                1.0 + voice.inharmonicity * 36.0
                            )
                        )

                        val tone =
                            harmonic1 * exp(-seconds * 0.65) +
                            harmonic2 * 0.42 * brightness *
                                exp(-seconds * 2.0) +
                            harmonic3 * 0.21 * brightness.pow(1.5) *
                                exp(-seconds * 3.8) +
                            harmonic4 * 0.11 * brightness.pow(2.0) *
                                exp(-seconds * 5.8) +
                            harmonic5 * 0.055 * brightness.pow(2.5) *
                                exp(-seconds * 8.0) +
                            harmonic6 * 0.025 * brightness.pow(3.0) *
                                exp(-seconds * 10.0)

                        val hammerTransient =
                            exp(-seconds * 85.0) *
                            (
                                sin(angle * 7.3) * 0.075 +
                                sin(angle * 9.1) * 0.035
                            ) * (0.25 + voice.velocity)

                        var amplitude = envelope(voice.age)

                        if (voice.releasing) {
                            val releaseTime =
                                voice.releaseAge.toDouble() / SAMPLE_RATE

                            amplitude = voice.releaseLevel *
                                exp(-releaseTime * 12.0)
                        }

                        sample += (tone + hammerTransient) *
                            amplitude * voice.velocity

                        voice.phase += voice.frequency / SAMPLE_RATE

                        if (voice.phase >= 1.0) {
                            voice.phase -= 1.0
                        }

                        voice.age++

                        if (voice.releasing) {
                            voice.releaseAge++

                            if (amplitude < 0.001) {
                                voice.active = false
                                voice.note = -1
                            }
                        }
                    }

                    buffer[i] = (sample * 0.12)
                        .coerceIn(-1.0, 1.0)
                        .toFloat()
                }
            }

            reverb.process(buffer)

            val currentTrack = audioTrack ?: break

            if (running) {
                currentTrack.write(
                    buffer,
                    0,
                    buffer.size,
                    AudioTrack.WRITE_BLOCKING
                )
            }
        }
    }

fun stop() {
    val threadToStop: Thread?
    val trackToStop: AudioTrack?

    synchronized(lifecycleLock) {
        if (!running && audioTrack == null) return

        running = false

        threadToStop = renderThread
        trackToStop = audioTrack

        renderThread = null
        audioTrack = null
    }

    try {
        trackToStop?.stop()
    } catch (_: Exception) {
    }

    try {
        threadToStop?.join()
    } catch (_: InterruptedException) {
        Thread.currentThread().interrupt()
    }

    try {
        trackToStop?.release()
    } catch (_: Exception) {
    }
}
}
