
package com.isaacstudio.studio4.audio.instruments

import com.isaacstudio.studio4.audio.AudioRenderer
import java.util.ArrayDeque
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.cos
import java.util.concurrent.Executor
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

class PianoEngine : AudioRenderer {

    @Volatile
    override var isRenderingEnabled = true

    @Volatile
    var layerVolume = 1.0f

    @Volatile
    var soundModel: PianoSoundModel = PianoSoundModel.STUDIO_GRAND

    companion object {
private const val SINE_TABLE_SIZE = 4096
private const val SINE_TABLE_MASK = SINE_TABLE_SIZE - 1

private val SINE_TABLE = DoubleArray(SINE_TABLE_SIZE) { index ->
    sin(2.0 * PI * index / SINE_TABLE_SIZE)
}
private fun fastSin(angle: Double): Double {
    val position = angle * (SINE_TABLE_SIZE / (2.0 * PI))
    val basePosition = position.toInt()
    val index = basePosition and SINE_TABLE_MASK
    val nextIndex = (index + 1) and SINE_TABLE_MASK
    val fraction = position - basePosition

    return SINE_TABLE[index] +
        (SINE_TABLE[nextIndex] - SINE_TABLE[index]) * fraction
}
        private const val SAMPLE_RATE = 44100
        private const val VOICE_COUNT = 16

        private const val EVENT_NOTE_ON = 1
        private const val EVENT_NOTE_OFF = 2
        private const val EVENT_NOTE_OFF_VOICE = 3
        private const val EVENT_SET_MIDI_CONTROLS = 4
        private const val EVENT_SAMPLE_READY = 5

        private val DIRECT_CALLBACK_EXECUTOR = Executor { command ->
            command.run()
        }

        private const val ATTACK_SAMPLES = 264L

        private val ENVELOPE_DECAY_STEP =
            exp(-0.55 / SAMPLE_RATE)

        private val RELEASE_DECAY_STEP =
            exp(-12.0 / SAMPLE_RATE)

private val HAMMER_DECAY_STEP =
    exp(-85.0 / SAMPLE_RATE)

        private val ATTACK_ENVELOPE = DoubleArray(
            ATTACK_SAMPLES.toInt()
        ) { age ->
            (age.toDouble() / ATTACK_SAMPLES) *
                exp(-(age.toDouble() / SAMPLE_RATE) * 0.55)
        }

        private val ATTACK_END_ENVELOPE =
            exp(-(ATTACK_SAMPLES.toDouble() / SAMPLE_RATE) * 0.55)

        private val HARMONIC_NUMBERS =
            doubleArrayOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0)

        private val HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.42, 0.21, 0.11, 0.055, 0.025)

        private val BRIGHT_HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.62, 0.38, 0.24, 0.15, 0.09)

        private val SOFT_HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.20, 0.075, 0.025, 0.009, 0.003)

        private val ELECTRIC_HARMONIC_AMPLITUDES =
            doubleArrayOf(1.0, 0.78, 0.62, 0.45, 0.30, 0.18)

        private val ELECTRIC_PARTIAL_RATIOS =
            doubleArrayOf(1.0, 2.76, 5.40, 8.93, 13.3, 18.6)

        private val HARMONIC_DECAY_RATES =
            doubleArrayOf(0.65, 2.0, 3.8, 5.8, 8.0, 10.0)

        private val HARMONIC_DECAY_STEPS =
            DoubleArray(6) {
                exp(-HARMONIC_DECAY_RATES[it] / SAMPLE_RATE)
            }
    }

    private data class Voice(
        var soundModel: PianoSoundModel = PianoSoundModel.STUDIO_GRAND,
        var limitPartialsAtNyquist: Boolean = false,
        var voiceId: Long = 0L,
        var note: Int = -1,
        var phase: Double = 0.0,
        var frequency: Double = 440.0,
        var inharmonicity: Double = 0.00006,
        var velocity: Double = 0.0,
        var midiPitchBendSemitones: Double = 0.0,
        var midiGain: Double = 1.0,
        var midiModulation: Double = 0.0,
        var midiModPhase: Double = 0.0,
        var age: Long = 0L,
        var active: Boolean = false,
        var releasing: Boolean = false,
        var releaseLevel: Double = 1.0,
        var releaseAge: Long = 0L,

        var envelopeValue: Double = 0.0,
        var releaseAmplitude: Double = 0.0,
        var hammerDecay: Double = 1.0,

val harmonicRatios: DoubleArray = DoubleArray(6),
val harmonicBrightness: DoubleArray = DoubleArray(6),
val harmonicDecay: DoubleArray = DoubleArray(6),
        val harmonicDecaySteps: DoubleArray = DoubleArray(6),
        var envelopeDecayStep: Double = ENVELOPE_DECAY_STEP,
        var attackSamples: Long = ATTACK_SAMPLES,
        var attackDecayRate: Double = 0.55,
        var useOriginalAttack: Boolean = true,
        var hammerDecayStep: Double = HAMMER_DECAY_STEP,
        var hammerFundamentalRatio: Double = 7.3,
        var hammerUpperRatio: Double = 9.1,
        var hammerFundamentalLevel: Double = 0.075,
        var hammerUpperLevel: Double = 0.035,

        var sampleToken1: PianoSampleLoadToken? = null,
        var sampleToken2: PianoSampleLoadToken? = null,
        var sampleLease1: PianoSampleLease? = null,
        var sampleLease2: PianoSampleLease? = null,
        var samplePending1: Boolean = false,
        var samplePending2: Boolean = false,
        var sampleFailed1: Boolean = false,
        var sampleFailed2: Boolean = false,
        var samplePosition1: Double = 0.0,
        var samplePosition2: Double = 0.0,
        var sampleGain1: Double = 0.0,
        var sampleGain2: Double = 0.0
    )

    private data class SamplePlan(
        val id1: PianoSampleId?,
        val id2: PianoSampleId?,
        val gain1: Double,
        val gain2: Double,
        val token1: PianoSampleLoadToken?,
        val token2: PianoSampleLoadToken?
    )

    private data class NoteEvent(
        val type: Int,
        val voiceId: Long = 0L,
        val note: Int = 0,
        val velocity: Float = 0.8f,
        val pitchBendSemitones: Double = 0.0,
        val midiGain: Double = 1.0,
        val modulation: Double = 0.0,
        val model: PianoSoundModel = PianoSoundModel.STUDIO_GRAND,
        val samplePlan: SamplePlan? = null,
        val sampleToken: PianoSampleLoadToken? = null,
        val sampleSlot: Int = 0,
        val sampleLease: PianoSampleLease? = null
    )

    private val voices = Array(VOICE_COUNT) { Voice() }

    @Volatile
    private var sampleBank: PianoSampleBank? = null

    @Volatile
    private var isShutdown = false

    private val sampleRequestExecutor: ExecutorService =
        Executors.newFixedThreadPool(2) { task ->
            Thread(task, "Isaac-Piano-Sample-Request").apply {
                isDaemon = true
            }
        }

    internal fun attachSampleBank(bank: PianoSampleBank) {
        check(!isShutdown) { "PianoEngine is already shut down" }
        sampleBank = bank
    }

    internal fun shutdown() {
        synchronized(eventLock) {
            if (isShutdown) return
            isShutdown = true
        }

        stop()

        synchronized(eventLock) {
            while (true) {
                val event = pendingEvents.pollFirst() ?: break
                event.samplePlan?.token1?.cancel()
                event.samplePlan?.token2?.cancel()
                event.sampleLease?.close()
            }
        }

        for (voice in voices) {
            clearVoiceSamples(voice)
            voice.active = false
            voice.note = -1
        }

        sampleRequestExecutor.shutdownNow()
        sampleBank = null
    }

    // Note events are separated from audio rendering.
    private val eventLock = Any()
    private val pendingEvents = ArrayDeque<NoteEvent>()
    private val eventBatch = arrayOfNulls<NoteEvent>(256)

    private var nextVoiceId = 1L

    fun start() {
        isRenderingEnabled = true
    }

    fun stop() {
        isRenderingEnabled = false
    }

    private fun createSamplePlan(
        note: Int,
        velocity: Float,
        model: PianoSoundModel
    ): SamplePlan? {
        if (model != PianoSoundModel.STUDIO_UPRIGHT &&
            model != PianoSoundModel.VINTAGE_UPRIGHT &&
            model != PianoSoundModel.FELT_UPRIGHT
        ) return null

        if (note !in PianoSampleId.MIN_KEY..PianoSampleId.MAX_KEY) {
            return null
        }

        val midiVelocity = (velocity * 127f + 0.5f).toInt().coerceIn(1, 127)

        var layer1 = 0
        var layer2 = 0
        var gain1 = 0.0
        var gain2 = 0.0

        when (midiVelocity) {
            in 1..23 -> {
                layer1 = 1
                gain1 = 1.0
            }
            in 24..39 -> {
                val t = (midiVelocity - 24).toDouble() / 15.0
                layer1 = 1
                layer2 = 2
                gain1 = cos(t * PI * 0.5)
                gain2 = sin(t * PI * 0.5)
            }
            in 40..55 -> {
                layer1 = 2
                gain1 = 1.0
            }
            in 56..71 -> {
                val t = (midiVelocity - 56).toDouble() / 15.0
                layer1 = 2
                layer2 = 3
                gain1 = cos(t * PI * 0.5)
                gain2 = sin(t * PI * 0.5)
            }
            in 72..87 -> {
                layer1 = 3
                gain1 = 1.0
            }
            in 88..103 -> {
                val t = (midiVelocity - 88).toDouble() / 15.0
                layer1 = 3
                layer2 = 4
                gain1 = cos(t * PI * 0.5)
                gain2 = sin(t * PI * 0.5)
            }
            else -> {
                layer1 = 4
                gain1 = 1.0
            }
        }

        return SamplePlan(
            id1 = PianoSampleId(note, layer1),
            id2 = if (layer2 == 0) null else PianoSampleId(note, layer2),
            gain1 = gain1,
            gain2 = gain2,
            token1 = PianoSampleLoadToken(),
            token2 = if (layer2 == 0) null else PianoSampleLoadToken()
        )
    }

    fun noteOn(note: Int, velocity: Float = 0.8f): Long {
        val safeNote = note.coerceIn(0, 127)
        val safeVelocity = velocity.coerceIn(0f, 1f)
        val model = soundModel
        val plan = if (!isShutdown && sampleBank != null) {
            createSamplePlan(safeNote, safeVelocity, model)
        } else {
            null
        }

        val voiceId: Long
        synchronized(eventLock) {
            if (isShutdown) return -1L

            voiceId = nextVoiceId++
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_ON,
                    voiceId = voiceId,
                    note = safeNote,
                    velocity = safeVelocity,
                    model = model,
                    samplePlan = plan
                )
            )
        }

        if (plan != null) {
            scheduleSampleRequests(voiceId, plan)
        }

        return voiceId
    }

    private fun enqueueSampleResult(
        voiceId: Long,
        token: PianoSampleLoadToken,
        slot: Int,
        lease: PianoSampleLease?
    ) {
        if (isShutdown || token.isCancelled) {
            lease?.close()
            return
        }

        synchronized(eventLock) {
            if (isShutdown || token.isCancelled) {
                lease?.close()
            } else {
                pendingEvents.addLast(
                    NoteEvent(
                        type = EVENT_SAMPLE_READY,
                        voiceId = voiceId,
                        sampleToken = token,
                        sampleSlot = slot,
                        sampleLease = lease
                    )
                )
            }
        }
    }

    private fun scheduleSampleRequests(
        voiceId: Long,
        plan: SamplePlan
    ) {
        fun submit(
            id: PianoSampleId?,
            token: PianoSampleLoadToken?,
            slot: Int
        ) {
            if (id == null || token == null) return

            try {
                sampleRequestExecutor.execute {
                    if (isShutdown || token.isCancelled) return@execute

                    val bank = sampleBank
                    if (bank == null || isShutdown) {
                        enqueueSampleResult(voiceId, token, slot, null)
                        return@execute
                    }

                    try {
                        val request = bank.requestSample(
                            id,
                            DIRECT_CALLBACK_EXECUTOR
                        ) { lease ->
                            enqueueSampleResult(voiceId, token, slot, lease)
                        }
                        token.attach(request)
                    } catch (_: Exception) {
                        enqueueSampleResult(voiceId, token, slot, null)
                    }
                }
            } catch (_: RejectedExecutionException) {
                enqueueSampleResult(voiceId, token, slot, null)
            }
        }

        submit(plan.id1, plan.token1, 1)
        submit(plan.id2, plan.token2, 2)
    }

    private fun cancelPendingSamples(voice: Voice) {
        voice.sampleToken1?.cancel()
        voice.sampleToken2?.cancel()
        voice.samplePending1 = false
        voice.samplePending2 = false
    }

    private fun clearVoiceSamples(voice: Voice) {
        cancelPendingSamples(voice)
        voice.sampleLease1?.close()
        voice.sampleLease2?.close()
        voice.sampleToken1 = null
        voice.sampleToken2 = null
        voice.sampleLease1 = null
        voice.sampleLease2 = null
        voice.sampleFailed1 = false
        voice.sampleFailed2 = false
        voice.samplePosition1 = 0.0
        voice.samplePosition2 = 0.0
        voice.sampleGain1 = 0.0
        voice.sampleGain2 = 0.0
    }

    fun noteOff(note: Int) {

        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF,
                    note = note
                )
            )
        }
    }

    fun setMidiControls(
        voiceId: Long,
        pitchBendSemitones: Double,
        gain: Double,
        modulation: Double
    ) {
        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_SET_MIDI_CONTROLS,
                    voiceId = voiceId,
                    pitchBendSemitones = pitchBendSemitones.coerceIn(-2.0, 2.0),
                    midiGain = gain.coerceIn(0.0, 1.0),
                    modulation = modulation.coerceIn(0.0, 1.0)
                )
            )
        }
    }
    
    fun noteOffVoice(voiceId: Long) {

        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF_VOICE,
                    voiceId = voiceId
                )
            )
        }
    }

    private fun initializeVoice(
        voice: Voice,
        event: NoteEvent
    ) {
        clearVoiceSamples(voice)

        val plan = event.samplePlan
        if (plan != null) {
            voice.sampleToken1 = plan.token1
            voice.sampleToken2 = plan.token2
            voice.samplePending1 = plan.id1 != null
            voice.samplePending2 = plan.id2 != null
            voice.sampleGain1 = plan.gain1
            voice.sampleGain2 = plan.gain2
        }

        val safeNote = event.note
        val model = event.model
        val profile = PianoSoundProfiles.forModel(model)

        voice.soundModel = model
        voice.limitPartialsAtNyquist = profile.limitPartialsAtNyquist

        voice.voiceId = event.voiceId
        voice.midiPitchBendSemitones = 0.0
        voice.midiGain = 1.0
        voice.midiModulation = 0.0
        voice.midiModPhase = 0.0
        voice.note = safeNote
        voice.phase = 0.0

        voice.frequency = 440.0 * 2.0.pow(
            (safeNote - 69) / 12.0
        )

        val baseInharmonicity = (
            0.00006 * sqrt(voice.frequency / 440.0)
        ).coerceIn(0.00004, 0.00035)

        voice.inharmonicity = (
            baseInharmonicity * profile.inharmonicityScale
        ).coerceIn(0.00004, 0.0008)

        voice.velocity = event.velocity.toDouble()
        voice.useOriginalAttack = profile.useOriginalAttack
        voice.attackSamples = profile.attackSamples
        voice.attackDecayRate = profile.attackDecayRate

        val brightness = 0.55 + voice.velocity * 0.90

        voice.envelopeDecayStep = if (profile.useOriginalAttack) {
            ENVELOPE_DECAY_STEP
        } else {
            exp(-profile.envelopeDecayRate / SAMPLE_RATE)
        }

        voice.hammerDecayStep = if (profile.useOriginalAttack) {
            HAMMER_DECAY_STEP
        } else {
            exp(-profile.hammerDecayRate / SAMPLE_RATE)
        }

        voice.hammerFundamentalRatio = profile.hammerFundamentalRatio
        voice.hammerUpperRatio = profile.hammerUpperRatio
        voice.hammerFundamentalLevel = profile.hammerFundamentalLevel
        voice.hammerUpperLevel = profile.hammerUpperLevel

        for (h in 0..5) {
            val harmonic = HARMONIC_NUMBERS[h]
            val partial = profile.partialRatios?.get(h) ?: harmonic.toDouble()

            voice.harmonicRatios[h] = if (profile.partialRatios != null) {
                partial * sqrt(
                    1.0 + voice.inharmonicity * partial * partial
                )
            } else {
                sqrt(
                    1.0 + voice.inharmonicity * harmonic * harmonic
                ) * harmonic
            }

            voice.harmonicBrightness[h] =
                profile.harmonicAmplitudes[h] *
                brightness.pow(1.0 + h * 0.5)

            voice.harmonicDecaySteps[h] = if (
                profile.useOriginalHarmonicDecay
            ) {
                HARMONIC_DECAY_STEPS[h]
            } else {
                exp(
                    -(HARMONIC_DECAY_RATES[h] * profile.decayRateScale) /
                        SAMPLE_RATE
                )
            }

            voice.harmonicDecay[h] = 1.0
        }

        voice.age = 0L
        voice.active = true
        voice.releasing = false

        voice.releaseLevel = 1.0
        voice.releaseAge = 0L

        voice.envelopeValue = 0.0
        voice.releaseAmplitude = 0.0
        voice.hammerDecay = 1.0
    }

    private fun releaseVoice(voice: Voice) {

        if (!voice.active || voice.releasing) return

        voice.releasing = true
        cancelPendingSamples(voice)
        voice.releaseLevel = voice.envelopeValue
        voice.releaseAmplitude = voice.envelopeValue
        voice.releaseAge = 0L
    }

    private fun processEvent(event: NoteEvent) {

        when (event.type) {

            EVENT_NOTE_ON -> {

                val voice =
                    voices.firstOrNull { !it.active }
                        ?: voices.firstOrNull { it.releasing }
                        ?: voices.maxByOrNull { it.age }

                if (voice != null) {
                    initializeVoice(voice, event)
                }
            }

            EVENT_NOTE_OFF -> {

                for (voice in voices) {
                    if (voice.active && voice.note == event.note) {
                        releaseVoice(voice)
                    }
                }
            }

            EVENT_SET_MIDI_CONTROLS -> {
                val voice = voices.firstOrNull {
                    it.active && it.voiceId == event.voiceId
                }
                if (voice != null) {
                    voice.midiPitchBendSemitones = event.pitchBendSemitones
                    voice.midiGain = event.midiGain
                    voice.midiModulation = event.modulation
                }
            }
            
            EVENT_SAMPLE_READY -> {
                val voice = voices.firstOrNull {
                    it.active && it.voiceId == event.voiceId
                }
                val token = event.sampleToken

                if (voice == null || token == null || token.isCancelled) {
                    event.sampleLease?.close()
                } else {
                    val validSlot = when (event.sampleSlot) {
                        1 -> voice.sampleToken1 === token
                        2 -> voice.sampleToken2 === token
                        else -> false
                    }

                    if (!validSlot) {
                        event.sampleLease?.close()
                    } else if (event.sampleSlot == 1) {
                        voice.samplePending1 = false
                        if (event.sampleLease == null) {
                            voice.sampleFailed1 = true
                        } else {
                            voice.sampleLease1?.close()
                            voice.sampleLease1 = event.sampleLease
                            voice.samplePosition1 = 0.0
                        }
                    } else {
                        voice.samplePending2 = false
                        if (event.sampleLease == null) {
                            voice.sampleFailed2 = true
                        } else {
                            voice.sampleLease2?.close()
                            voice.sampleLease2 = event.sampleLease
                            voice.samplePosition2 = 0.0
                        }
                    }
                }
            }

            EVENT_NOTE_OFF_VOICE -> {

                val voice = voices.firstOrNull {
                    it.active && it.voiceId == event.voiceId
                }

                if (voice != null) {
                    releaseVoice(voice)
                }
            }
        }
    }

    private fun processPendingEvents() {

        var eventCount = 0

        synchronized(eventLock) {
            while (eventCount < eventBatch.size) {

                val event = pendingEvents.pollFirst() ?: break

                eventBatch[eventCount] = event
                eventCount++
            }
        }

        for (i in 0 until eventCount) {

            val event = eventBatch[i] ?: continue

            processEvent(event)

            eventBatch[i] = null
        }
    }

    private fun readInterpolatedSample(
        sample: PianoPcmSample,
        position: Double
    ): Double {
        val index = position.toInt()
        if (index < 0 || index >= sample.frameCount) return 0.0

        val nextIndex = (index + 1).coerceAtMost(sample.frameCount - 1)
        val fraction = position - index.toDouble()
        val first = sample.pcm16[index].toDouble() / 32768.0
        val second = sample.pcm16[nextIndex].toDouble() / 32768.0
        return first + (second - first) * fraction
    }

    override fun renderInto(buffer: FloatArray) {
        if (!isRenderingEnabled) return

        processPendingEvents()

        val currentLayerVolume = layerVolume.coerceIn(0f, 1f)
        val outputGain = 0.12 * currentLayerVolume

        for (i in buffer.indices) {
            var sample = 0.0

            for (voice in voices) {
                if (!voice.active) continue

                val lease1 = voice.sampleLease1
                val lease2 = voice.sampleLease2
                val hasSamplePlan =
                    voice.sampleToken1 != null || voice.sampleToken2 != null
                val samplesPending =
                    voice.samplePending1 || voice.samplePending2
                val waitingForSamples = hasSamplePlan && samplesPending

                // Freeze note age and envelope until the requested samples arrive.
                val amplitude: Double
                if (waitingForSamples) {
                    amplitude = 0.0
                } else if (voice.releasing) {
                    amplitude = voice.releaseAmplitude
                    voice.releaseAmplitude *= RELEASE_DECAY_STEP
                    voice.releaseAge++
                } else {
                    when {
                        voice.age < voice.attackSamples -> {
                            voice.envelopeValue =
                                if (voice.useOriginalAttack) {
                                    ATTACK_ENVELOPE[voice.age.toInt()]
                                } else {
                                    (voice.age.toDouble() / voice.attackSamples) *
                                        exp(
                                            -(voice.age.toDouble() / SAMPLE_RATE) *
                                                voice.attackDecayRate
                                        )
                                }
                        }

                        voice.age == voice.attackSamples -> {
                            voice.envelopeValue =
                                if (voice.useOriginalAttack) {
                                    ATTACK_END_ENVELOPE
                                } else {
                                    exp(
                                        -(voice.attackSamples.toDouble() / SAMPLE_RATE) *
                                            voice.attackDecayRate
                                    )
                                }
                        }

                        else -> {
                            voice.envelopeValue *= voice.envelopeDecayStep
                        }
                    }
                    amplitude = voice.envelopeValue
                }

                if (!waitingForSamples) {
                    val midiVibratoSemitones =
                        kotlin.math.sin(voice.midiModPhase * 2.0 * kotlin.math.PI) *
                            0.5 * voice.midiModulation
                    voice.midiModPhase += 5.0 / SAMPLE_RATE
                    if (voice.midiModPhase >= 1.0) voice.midiModPhase -= 1.0

                    val midiFrequencyMultiplier = 2.0.pow(
                        (voice.midiPitchBendSemitones + midiVibratoSemitones) / 12.0
                    )

                    val useSamplePlayback =
                        hasSamplePlan && (lease1 != null || lease2 != null)

                    if (useSamplePlayback) {
                        val pcm1 = lease1?.sample
                        val pcm2 = lease2?.sample

                        val active1 = pcm1 != null &&
                            voice.samplePosition1 < pcm1.frameCount.toDouble()
                        val active2 = pcm2 != null &&
                            voice.samplePosition2 < pcm2.frameCount.toDouble()

                        var sampleMix = 0.0
                        var gain1 = 0.0
                        var gain2 = 0.0

                        if (active1 && active2) {
                            gain1 = voice.sampleGain1
                            gain2 = voice.sampleGain2
                        } else if (active1) {
                            gain1 = 1.0
                        } else if (active2) {
                            gain2 = 1.0
                        }

                        if (active1 && pcm1 != null) {
                            sampleMix += readInterpolatedSample(
                                pcm1,
                                voice.samplePosition1
                            ) * gain1
                            voice.samplePosition1 +=
                                (pcm1.sampleRate.toDouble() / SAMPLE_RATE) *
                                    midiFrequencyMultiplier
                        }

                        if (active2 && pcm2 != null) {
                            sampleMix += readInterpolatedSample(
                                pcm2,
                                voice.samplePosition2
                            ) * gain2
                            voice.samplePosition2 +=
                                (pcm2.sampleRate.toDouble() / SAMPLE_RATE) *
                                    midiFrequencyMultiplier
                        }

                        sample += sampleMix * amplitude * voice.velocity * voice.midiGain

                        val sample1Finished = pcm1 == null ||
                            voice.samplePosition1 >= pcm1.frameCount.toDouble()
                        val sample2Finished = pcm2 == null ||
                            voice.samplePosition2 >= pcm2.frameCount.toDouble()

                        if (sample1Finished && sample2Finished) {
                            clearVoiceSamples(voice)
                            voice.active = false
                            voice.note = -1
                        }
                    } else if (
                        !hasSamplePlan ||
                        (!samplesPending && lease1 == null && lease2 == null)
                    ) {
                        // Original synthesis remains the path for other models
                        // and the fallback when upright samples fail to load.
                        val bentFrequency = voice.frequency * midiFrequencyMultiplier
                        val angle = 2.0 * PI * voice.phase
                        var tone = 0.0

                        for (h in 0..5) {
                            val partialFrequency =
                                bentFrequency * voice.harmonicRatios[h]

                            if (
                                !voice.limitPartialsAtNyquist ||
                                partialFrequency < SAMPLE_RATE * 0.5
                            ) {
                                tone += fastSin(
                                    angle * voice.harmonicRatios[h]
                                ) *
                                    voice.harmonicBrightness[h] *
                                    voice.harmonicDecay[h]
                            }

                            voice.harmonicDecay[h] *=
                                voice.harmonicDecaySteps[h]
                        }

                        val hammerTransient =
                            voice.hammerDecay *
                                (
                                    fastSin(angle * voice.hammerFundamentalRatio) *
                                        voice.hammerFundamentalLevel +
                                        fastSin(angle * voice.hammerUpperRatio) *
                                        voice.hammerUpperLevel
                                ) *
                                (0.25 + voice.velocity)

                        voice.hammerDecay *= voice.hammerDecayStep

                        sample += (tone + hammerTransient) *
                            amplitude * voice.velocity * voice.midiGain

                        voice.phase += bentFrequency / SAMPLE_RATE
                        if (voice.phase >= 1.0) {
                            voice.phase -= 1.0
                        }
                    }

                    voice.age++

                    if (voice.active && voice.releasing && amplitude < 0.001) {
                        clearVoiceSamples(voice)
                        voice.active = false
                        voice.note = -1
                    }
                }
            }

            buffer[i] += (sample * outputGain)
                .coerceIn(-1.0, 1.0)
                .toFloat()
        }
    }
}

