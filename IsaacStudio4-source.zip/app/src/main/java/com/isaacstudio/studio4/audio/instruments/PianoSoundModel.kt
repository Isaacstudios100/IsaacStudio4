package com.isaacstudio.studio4.audio.instruments

enum class PianoSoundModel(val displayName: String) {
    STUDIO_GRAND("Studio Grand"),
    BRIGHT_GRAND("Bright Grand"),
    SOFT_GRAND("Soft Grand"),
    ELECTRIC_PIANO("Electric Piano"),

    CONCERT_GRAND("Concert Grand"),
    VINTAGE_GRAND("Vintage Grand"),
    MELLOW_GRAND("Mellow Grand"),

    STUDIO_UPRIGHT("Studio Upright"),
    VINTAGE_UPRIGHT("Vintage Upright"),
    FELT_UPRIGHT("Felt Upright"),

    VINTAGE_TINE("Vintage Tine"),
    SUITCASE_ELECTRIC("Suitcase Electric"),
    REED_ELECTRIC("Reed Electric"),

    CLAVINET("Clavinet"),
    MUTED_CLAVINET("Muted Clavinet"),

    STAGE_PIANO("Stage Piano"),
    FM_PIANO("FM Piano"),
    SOFT_DIGITAL_PIANO("Soft Digital Piano"),

    HARPSICHORD("Harpsichord"),
    HONKY_TONK_PIANO("Honky-Tonk Piano")
}
