package com.isaacstudio.studio4.audio.instruments

enum class PianoSoundModel(val displayName: String) {
    STUDIO_GRAND("Studio Grand"),
    BRIGHT_GRAND("Bright Grand"),
    SOFT_GRAND("Soft Grand"),
    ELECTRIC_PIANO("Electric Piano")
}
