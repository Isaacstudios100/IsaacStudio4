package com.isaacstudio.studio4.audio.instruments

internal data class PianoSoundProfile(
    val inharmonicityScale: Double,
    val attackSamples: Long,
    val attackDecayRate: Double,
    val decayRateScale: Double,
    val envelopeDecayRate: Double,
    val useOriginalAttack: Boolean,
    val harmonicAmplitudes: DoubleArray,
    val partialRatios: DoubleArray? = null,
    val hammerDecayRate: Double,
    val hammerFundamentalRatio: Double,
    val hammerUpperRatio: Double,
    val hammerFundamentalLevel: Double,
    val hammerUpperLevel: Double,
    val useOriginalHarmonicDecay: Boolean = false,
    val limitPartialsAtNyquist: Boolean = false
)

internal object PianoSoundProfiles {
    private fun profile(
        inharmonicity: Double,
        attack: Long,
        attackRate: Double,
        decayScale: Double,
        envelopeRate: Double,
        amplitudes: DoubleArray,
        hammerRate: Double,
        hammerFundamental: Double,
        hammerUpper: Double,
        hammerFundamentalLevel: Double,
        hammerUpperLevel: Double,
        partials: DoubleArray? = null,
        originalAttack: Boolean = false,
        originalHarmonicDecay: Boolean = false,
        nyquistLimit: Boolean = false
    ) = PianoSoundProfile(
        inharmonicity, attack, attackRate, decayScale, envelopeRate,
        originalAttack, amplitudes, partials, hammerRate,
        hammerFundamental, hammerUpper, hammerFundamentalLevel,
        hammerUpperLevel, originalHarmonicDecay, nyquistLimit
    )

    private val standard = doubleArrayOf(1.0, 0.42, 0.21, 0.11, 0.055, 0.025)
    private val bright = doubleArrayOf(1.0, 0.62, 0.38, 0.24, 0.15, 0.09)
    private val soft = doubleArrayOf(1.0, 0.20, 0.075, 0.025, 0.009, 0.003)
    private val electric = doubleArrayOf(1.0, 0.78, 0.62, 0.45, 0.30, 0.18)
    private val electricPartials = doubleArrayOf(1.0, 2.76, 5.40, 8.93, 13.3, 18.6)

    private val profiles = mapOf(
        PianoSoundModel.STUDIO_GRAND to profile(
            1.0, 264L, 0.55, 1.0, 0.55, standard,
            85.0, 7.3, 9.1, 0.075, 0.035,
            originalAttack = true, originalHarmonicDecay = true
        ),
        PianoSoundModel.BRIGHT_GRAND to profile(
            1.15, 176L, 0.70, 1.15, 0.70, bright,
            105.0, 7.3, 9.1, 0.090, 0.045
        ),
        PianoSoundModel.SOFT_GRAND to profile(
            0.85, 882L, 0.42, 0.78, 0.42, soft,
            65.0, 7.3, 9.1, 0.045, 0.020
        ),
        PianoSoundModel.ELECTRIC_PIANO to profile(
            2.5, 132L, 1.10, 1.35, 0.90, electric,
            145.0, 2.4, 5.2, 0.110, 0.065,
            partials = electricPartials, nyquistLimit = true
        ),

        PianoSoundModel.CONCERT_GRAND to profile(
            1.08, 220L, 0.62, 0.95, 0.52,
            doubleArrayOf(1.0, 0.48, 0.25, 0.14, 0.075, 0.038),
            90.0, 7.5, 9.4, 0.082, 0.038
        ),
        PianoSoundModel.VINTAGE_GRAND to profile(
            1.28, 300L, 0.48, 0.82, 0.46,
            doubleArrayOf(1.0, 0.52, 0.29, 0.17, 0.10, 0.055),
            78.0, 6.8, 8.7, 0.070, 0.032
        ),
        PianoSoundModel.MELLOW_GRAND to profile(
            0.92, 420L, 0.38, 0.72, 0.38,
            doubleArrayOf(1.0, 0.27, 0.12, 0.045, 0.018, 0.007),
            58.0, 6.8, 8.5, 0.038, 0.016
        ),

        PianoSoundModel.STUDIO_UPRIGHT to profile(
            1.45, 330L, 0.58, 0.92, 0.72,
            doubleArrayOf(1.0, 0.56, 0.32, 0.18, 0.095, 0.045),
            115.0, 5.8, 7.6, 0.095, 0.048
        ),
        PianoSoundModel.VINTAGE_UPRIGHT to profile(
            1.75, 390L, 0.52, 0.78, 0.82,
            doubleArrayOf(1.0, 0.61, 0.36, 0.21, 0.12, 0.065),
            125.0, 5.2, 7.1, 0.105, 0.052
        ),
        PianoSoundModel.FELT_UPRIGHT to profile(
            1.20, 620L, 0.30, 0.68, 0.58,
            doubleArrayOf(1.0, 0.16, 0.055, 0.018, 0.006, 0.002),
            48.0, 4.8, 6.2, 0.022, 0.009
        ),

        PianoSoundModel.VINTAGE_TINE to profile(
            2.8, 115L, 1.20, 1.45, 1.05,
            doubleArrayOf(1.0, 0.82, 0.65, 0.46, 0.29, 0.16),
            155.0, 2.2, 5.0, 0.115, 0.070,
            partials = doubleArrayOf(1.0, 2.72, 5.35, 8.85, 13.1, 18.2),
            nyquistLimit = true
        ),
        PianoSoundModel.SUITCASE_ELECTRIC to profile(
            2.35, 145L, 0.98, 1.20, 0.78,
            doubleArrayOf(1.0, 0.72, 0.52, 0.34, 0.21, 0.12),
            125.0, 2.5, 5.4, 0.095, 0.058,
            partials = doubleArrayOf(1.0, 2.68, 5.22, 8.62, 12.8, 17.9),
            nyquistLimit = true
        ),
        PianoSoundModel.REED_ELECTRIC to profile(
            1.65, 170L, 0.82, 1.08, 0.68,
            doubleArrayOf(1.0, 0.68, 0.43, 0.25, 0.14, 0.075),
            100.0, 3.1, 6.2, 0.085, 0.042
        ),

        PianoSoundModel.CLAVINET to profile(
            3.0, 48L, 1.65, 1.85, 1.45,
            doubleArrayOf(1.0, 0.90, 0.76, 0.58, 0.40, 0.25),
            190.0, 4.0, 7.5, 0.145, 0.085
        ),
        PianoSoundModel.MUTED_CLAVINET to profile(
            2.2, 75L, 1.35, 1.65, 1.20,
            doubleArrayOf(1.0, 0.42, 0.20, 0.085, 0.032, 0.012),
            135.0, 3.5, 6.0, 0.075, 0.035
        ),

        PianoSoundModel.STAGE_PIANO to profile(
            1.0, 190L, 0.68, 1.0, 0.62,
            doubleArrayOf(1.0, 0.50, 0.29, 0.16, 0.085, 0.045),
            95.0, 7.2, 9.0, 0.085, 0.040
        ),
        PianoSoundModel.FM_PIANO to profile(
            2.0, 90L, 1.05, 1.28, 0.95,
            doubleArrayOf(1.0, 0.86, 0.58, 0.34, 0.19, 0.095),
            165.0, 2.0, 6.5, 0.105, 0.060,
            partials = doubleArrayOf(1.0, 2.0, 3.98, 6.2, 8.8, 12.1),
            nyquistLimit = true
        ),
        PianoSoundModel.SOFT_DIGITAL_PIANO to profile(
            0.75, 260L, 0.48, 0.88, 0.48,
            doubleArrayOf(1.0, 0.30, 0.13, 0.052, 0.020, 0.007),
            62.0, 6.0, 8.0, 0.035, 0.014
        ),

        PianoSoundModel.HARPSICHORD to profile(
            0.35, 35L, 2.0, 2.8, 2.2,
            doubleArrayOf(1.0, 0.72, 0.48, 0.32, 0.21, 0.14),
            220.0, 3.0, 6.0, 0.095, 0.055
        ),
        PianoSoundModel.HONKY_TONK_PIANO to profile(
            1.15, 210L, 0.72, 1.08, 0.72,
            doubleArrayOf(1.0, 0.58, 0.35, 0.20, 0.12, 0.07),
            105.0, 7.0, 9.5, 0.095, 0.050
        )
    )

    fun forModel(model: PianoSoundModel): PianoSoundProfile =
        profiles.getValue(model)
}
