package com.isaacstudio.studio4.audio.instruments

import com.isaacstudio.studio4.audio.effects.ReverbProcessor

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.pow

class OrganEngine {

    companion object {
        private const val SAMPLE_RATE = 44100
        private const val VOICE_COUNT = 16

        private val DRAWBAR_RATIOS = doubleArrayOf(
            0.5, 1.5, 1.0, 2.0, 3.0,
            4.0, 5.0, 6.0, 8.0
        )
    }

    private data class Voice(
        var note: Int = -1,
        var phase: Double = 0.0,
        var active: Boolean = false
    )

    private val voices = Array(VOICE_COUNT) { Voice() }
    private val drawbars = IntArray(9) { 0 }
    private val reverb = ReverbProcessor()

    @Volatile
    private var running = true

    private val audioTrack: AudioTrack

    init {
        val minBuffer = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )

        val bufferSize = maxOf(minBuffer, 4096)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack.play()

        Thread {
            renderAudio()
        }.start()
    }

    fun configureReverb(enabled: Boolean, roomSize: Float, wetMix: Float) {
        reverb.enabled = enabled
        reverb.roomSize = roomSize
        reverb.wetMix = wetMix
    }

    fun setDrawbar(index: Int, level: Int) {
        if (index in 0..8) {
            drawbars[index] = level.coerceIn(0, 8)
        }
    }

    fun setDrawbars(levels: IntArray) {
        for (i in 0..8) {
            if (i < levels.size) {
                drawbars[i] = levels[i].coerceIn(0, 8)
            }
        }
    }

    fun noteOn(note: Int) {
        synchronized(voices) {
            val voice = voices.firstOrNull { !it.active }
                ?: voices.minByOrNull { it.note }

            voice?.apply {
                this.note = note.coerceIn(0, 127)
                phase = 0.0
                active = true
            }
        }
    }

    fun noteOff(note: Int) {
        synchronized(voices) {
            voices.filter { it.active && it.note == note }
                .forEach {
                    it.active = false
                    it.note = -1
                }
        }
    }

    private fun renderAudio() {
        val buffer = FloatArray(512)

        while (running) {
            synchronized(voices) {
                for (i in buffer.indices) {
                    var sample = 0.0

                    for (voice in voices) {
                        if (!voice.active) continue

                        val frequency = 440.0 *
                            2.0.pow((voice.note - 69) / 12.0)

                        for (bar in 0..8) {
                            val level = drawbars[bar]
                            if (level == 0) continue

                            val ratio = DRAWBAR_RATIOS[bar]
                            val angle = 2.0 * PI *
                                voice.phase * ratio

                            sample += sin(angle) * (level / 8.0)
                        }

                        voice.phase += frequency / SAMPLE_RATE
                        if (voice.phase >= 1.0) {
                            voice.phase -= 1.0
                        }
                    }

                    buffer[i] = (sample * 0.025)
                        .coerceIn(-1.0, 1.0)
                        .toFloat()
                }
            }

            reverb.process(buffer)

            audioTrack.write(
                buffer,
                0,
                buffer.size,
                AudioTrack.WRITE_BLOCKING
            )
        }
    }

    fun stop() {
        running = false

        try {
            audioTrack.pause()
            audioTrack.flush()
            audioTrack.stop()
            audioTrack.release()
        } catch (_: Exception) {
        }
    }
}
