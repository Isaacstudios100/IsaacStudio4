
package com.isaacstudio.studio4.audio.instruments

import com.isaacstudio.studio4.audio.AudioRenderer
import java.util.ArrayDeque
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

class OrganEngine : AudioRenderer {

    @Volatile
    override var isRenderingEnabled = true

    @Volatile
    var layerVolume = 1.0f
@Volatile
var voxFilterMix = 0.5f
@Volatile
var organModel: OrganModel = OrganModel.B3

    @Volatile
    var b3PercussionEnabled = false

    @Volatile
    var b3PercussionHarmonic = 2

    @Volatile
    var b3PercussionSoft = false

    @Volatile
    var b3PercussionFastDecay = true

    @Volatile
    var b3PercussionPolyMode = false

    companion object {
        private const val SAMPLE_RATE = 44100
        private const val VOICE_COUNT = 16

        private const val EVENT_NOTE_ON = 1
        private const val EVENT_NOTE_OFF = 2
        private const val EVENT_NOTE_OFF_VOICE = 3

        private const val SINE_TABLE_SIZE = 2048
        private const val SINE_TABLE_MASK = SINE_TABLE_SIZE - 1

        private val SINE_TABLE = DoubleArray(SINE_TABLE_SIZE) { index ->
            sin(2.0 * PI * index / SINE_TABLE_SIZE)
        }

        private val DRAWBAR_RATIOS = doubleArrayOf(
            0.5, 1.5, 1.0, 2.0, 3.0,
            4.0, 5.0, 6.0, 8.0
        )
    }

private data class Voice(
    var voiceId: Long = 0L,
    var note: Int = -1,
    var frequency: Double = 0.0,
    var phase: Double = 0.0,
    var active: Boolean = false,
    var filterState: Double = 0.0
)

    private data class NoteEvent(
        val type: Int,
        val voiceId: Long = 0L,
        val note: Int = 0
    )

    private val voices = Array(VOICE_COUNT) { Voice() }

    private data class PercussionVoice(
        var frequency: Double = 0.0,
        var phase: Double = 0.0,
        var amplitude: Double = 0.0,
        var active: Boolean = false
    )

    private val percussionVoices = Array(VOICE_COUNT) {
        PercussionVoice()
    }

    private val heldNotes = HashMap<Long, Int>()

    private val eventLock = Any()
    private val pendingEvents = ArrayDeque<NoteEvent>()
    private val eventBatch = arrayOfNulls<NoteEvent>(256)

    private var nextVoiceId = 1L

    private val drawbarLock = Any()
    private val drawbars = IntArray(9) { 0 }

    @Volatile
    private var harmonicLevels = DoubleArray(9)

    private fun calculateHarmonicLevels() {
        val newLevels = DoubleArray(9)

        synchronized(drawbarLock) {
            for (i in 0..8) {
                newLevels[i] = drawbars[i] / 8.0
            }
        }

        harmonicLevels = newLevels
    }

    fun setDrawbar(index: Int, level: Int) {
        if (index !in 0..8) return

        synchronized(drawbarLock) {
            drawbars[index] = level.coerceIn(0, 8)
        }

        calculateHarmonicLevels()
    }

    fun setDrawbars(levels: IntArray) {
        synchronized(drawbarLock) {
            for (i in 0..8) {
                if (i < levels.size) {
                    drawbars[i] = levels[i].coerceIn(0, 8)
                }
            }
        }

        calculateHarmonicLevels()
    }

    fun noteOn(note: Int): Long {
        synchronized(eventLock) {
            val voiceId = nextVoiceId++

            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_ON,
                    voiceId = voiceId,
                    note = note.coerceIn(0, 127)
                )
            )

            return voiceId
        }
    }

    fun noteOff(note: Int) {
        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF,
                    note = note
                )
            )
        }
    }

    fun noteOffVoice(voiceId: Long) {
        synchronized(eventLock) {
            pendingEvents.addLast(
                NoteEvent(
                    type = EVENT_NOTE_OFF_VOICE,
                    voiceId = voiceId
                )
            )
        }
    }

    private fun triggerB3Percussion(note: Int) {
        if (organModel != OrganModel.B3) return
        if (!b3PercussionEnabled) return

        val voice = percussionVoices.firstOrNull { !it.active }
            ?: percussionVoices.minByOrNull { it.amplitude }
            ?: return

        val fundamental = 440.0 * 2.0.pow((note - 69) / 12.0)
        val harmonic = b3PercussionHarmonic.coerceIn(2, 3)

        voice.frequency = fundamental * harmonic
        voice.phase = 0.0
        voice.amplitude = if (b3PercussionSoft) 0.5 else 1.0
        voice.active = true
    }
    
private fun processEvent(event: NoteEvent) {
        when (event.type) {
            EVENT_NOTE_ON -> {
                  val shouldTriggerPercussion =
                      b3PercussionPolyMode || heldNotes.isEmpty()

                  heldNotes[event.voiceId] = event.note

                  if (shouldTriggerPercussion) {
                      triggerB3Percussion(event.note)
                  }
                val voice = voices.firstOrNull { !it.active }
                    ?: voices.minByOrNull { it.note }

                if (voice != null) {
                    voice.voiceId = event.voiceId
                    voice.note = event.note
                    voice.frequency = 440.0 * 2.0.pow(
                        (event.note - 69) / 12.0
                    )
                    voice.phase = 0.0
voice.filterState = 0.0
                    voice.active = true
                }
            }

            EVENT_NOTE_OFF -> {
                             heldNotes.entries.removeAll { it.value == event.note }
     for (voice in voices) {
                    if (voice.active && voice.note == event.note) {
                        voice.active = false
                        voice.note = -1
                    }
                }
            }

            EVENT_NOTE_OFF_VOICE -> {
                  heldNotes.remove(event.voiceId)
                val voice = voices.firstOrNull {
                    it.active && it.voiceId == event.voiceId
                }

                if (voice != null) {
                    voice.active = false
                    voice.note = -1
                }
            }
        }
    }

    private fun processPendingEvents() {
        var eventCount = 0

        synchronized(eventLock) {
            while (eventCount < eventBatch.size) {
                val event = pendingEvents.pollFirst() ?: break
                eventBatch[eventCount] = event
                eventCount++
            }
        }

        for (i in 0 until eventCount) {
            val event = eventBatch[i] ?: continue
            processEvent(event)
            eventBatch[i] = null
        }
    }

    private fun lookupSine(phase: Double, ratio: Double): Double {
        val position = phase * ratio * SINE_TABLE_SIZE
        val baseIndex = position.toInt()

        val index = baseIndex and SINE_TABLE_MASK
        val nextIndex = (index + 1) and SINE_TABLE_MASK

        val fraction = position - baseIndex

        val first = SINE_TABLE[index]
        val second = SINE_TABLE[nextIndex]

        return first + (second - first) * fraction
    }

override fun renderInto(buffer: FloatArray) {
    if (!isRenderingEnabled) return

    processPendingEvents()

    val currentHarmonics = harmonicLevels
    val currentLayerVolume = layerVolume.coerceIn(0f, 1f)
    val currentOrganModel = organModel
    val currentVoxFilterMix = voxFilterMix.coerceIn(0f, 1f).toDouble()
    val useVoxFilter =
        currentOrganModel == OrganModel.VOX && currentVoxFilterMix > 0.0

    val outputGain = 0.025 * currentLayerVolume
      val percussionDecaySeconds =
          if (b3PercussionFastDecay) 0.12 else 0.24

      val percussionDecayCoefficient = exp(
          -1.0 / (percussionDecaySeconds * SAMPLE_RATE)
      )

    for (i in buffer.indices) {
        var sample = 0.0

        for (voice in voices) {
            if (!voice.active) continue

            val phase = voice.phase
            var voiceSample = 0.0

            for (bar in 0..8) {
                val level = currentHarmonics[bar]

                if (level == 0.0) continue

                voiceSample += lookupSine(
                    phase,
                    DRAWBAR_RATIOS[bar]
                ) * level
            }

            if (useVoxFilter) {
                voice.filterState +=
                    0.12 * (voiceSample - voice.filterState)

                val blendedVoiceSample =
                    voiceSample +
                    (voice.filterState - voiceSample) * currentVoxFilterMix

                sample += blendedVoiceSample
            } else {
                sample += voiceSample
            }

            voice.phase += voice.frequency / SAMPLE_RATE

            if (voice.phase >= 1.0) {
                voice.phase -= 1.0
            }
        }

              for (percussionVoice in percussionVoices) {
                  if (!percussionVoice.active) continue

                  sample += lookupSine(percussionVoice.phase, 1.0) *
                      percussionVoice.amplitude

                  percussionVoice.phase +=
                      percussionVoice.frequency / SAMPLE_RATE

                  if (percussionVoice.phase >= 1.0) {
                      percussionVoice.phase -= 1.0
                  }

                  percussionVoice.amplitude *=
                      percussionDecayCoefficient

                  if (percussionVoice.amplitude < 0.0005) {
                      percussionVoice.active = false
                      percussionVoice.amplitude = 0.0
                  }
              }
          }

        buffer[i] += (sample * outputGain)
            .coerceIn(-1.0, 1.0)
            .toFloat()
    }
}

    fun start() {
        isRenderingEnabled = true
    }

    fun stop() {
        isRenderingEnabled = false
    }
}

