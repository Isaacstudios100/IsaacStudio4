package com.isaacstudio.studio4.audio.effects

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Independent stereo-linked dynamics compressor.
 *
 * One persistent instance belongs to each instrument layer's effects rack.
 * Both channels share one detector and one gain-reduction envelope to
 * preserve the stereo image.
 *
 * Detector state is retained between blocks.
 * No arrays or objects are allocated during audio processing.
 */
class CompressorProcessor(
    private val sampleRate: Float = 44100f
) {
    companion object {
        private const val MIN_SAMPLE_RATE = 8000f
        private const val MIN_TIME_MS = 0.1f
        private const val MIN_RATIO = 1f
        private const val MAX_RATIO = 20f
        private const val MIN_THRESHOLD_DB = -60f
        private const val MAX_THRESHOLD_DB = 0f
        private const val MAX_KNEE_DB = 24f
        private const val MAX_MAKEUP_DB = 24f
        private const val MIN_GAIN = 0.000001f
        private const val LN_10 = 2.302585093f
    }

    private val safeSampleRate = sampleRate.coerceAtLeast(MIN_SAMPLE_RATE)

    private var detectorEnvelope = 0f
    private var rmsSquaredEnvelope = 0f
    private var gainReductionEnvelope = 1f

    private var cachedAttackMs = Float.NaN
    private var cachedReleaseMs = Float.NaN
    private var cachedFast = false

    private var attackCoefficient = 0f
    private var releaseCoefficient = 0f

    private var cachedMakeupDb = Float.NaN
    private var makeupGain = 1f

    private var cachedDetector = CompressorDetector.PEAK

    private fun updateCoefficients(settings: CompressorSettings) {
        var attackMs = settings.attackMs.coerceIn(MIN_TIME_MS, 200f)
        var releaseMs = settings.releaseMs.coerceIn(1f, 2000f)

        // Preserve the legacy FAST switch without ignoring explicit settings.
        if (settings.fast) {
            attackMs = min(attackMs, 2f)
            releaseMs = min(releaseMs, 60f)
        }

        if (
            attackMs != cachedAttackMs ||
            releaseMs != cachedReleaseMs ||
            settings.fast != cachedFast
        ) {
            attackCoefficient = exp(
                -1f / (attackMs * 0.001f * safeSampleRate)
            )
            releaseCoefficient = exp(
                -1f / (releaseMs * 0.001f * safeSampleRate)
            )

            cachedAttackMs = attackMs
            cachedReleaseMs = releaseMs
            cachedFast = settings.fast
        }

        if (settings.makeupGainDb != cachedMakeupDb) {
            val makeupDb = settings.makeupGainDb.coerceIn(
                -24f,
                MAX_MAKEUP_DB
            )

            makeupGain = 10f.pow(makeupDb / 20f)
            cachedMakeupDb = settings.makeupGainDb
        }

        cachedDetector = settings.detector
    }

    private fun calculateGain(
        levelDb: Float,
        thresholdDb: Float,
        ratio: Float,
        kneeDb: Float
    ): Float {
        val overThreshold = levelDb - thresholdDb

        val reductionDb = if (kneeDb > 0f) {
            val halfKnee = kneeDb * 0.5f

            when {
                overThreshold <= -halfKnee -> 0f

                overThreshold >= halfKnee ->
                    overThreshold * (1f - 1f / ratio)

                else -> {
                    val distance = overThreshold + halfKnee
                    (1f - 1f / ratio) *
                        distance * distance /
                        (2f * kneeDb)
                }
            }
        } else {
            max(0f, overThreshold) * (1f - 1f / ratio)
        }

        return 10f.pow(-reductionDb / 20f)
    }

    /**
     * Processes stereo audio.
     *
     * Input and output buffers may be identical.
     * Output buffers are overwritten, not accumulated.
     */
    fun processStereo(
        inputLeft: FloatArray,
        inputRight: FloatArray,
        outputLeft: FloatArray,
        outputRight: FloatArray,
        settings: CompressorSettings
    ) {
        val frameCount = min(
            min(inputLeft.size, inputRight.size),
            min(outputLeft.size, outputRight.size)
        )

        if (frameCount <= 0) return

        if (!settings.enabled) {
            for (i in 0 until frameCount) {
                outputLeft[i] = inputLeft[i]
                outputRight[i] = inputRight[i]
            }
            return
        }

        updateCoefficients(settings)

        val thresholdDb = settings.thresholdDb.coerceIn(
            MIN_THRESHOLD_DB,
            MAX_THRESHOLD_DB
        )

        val ratio = settings.ratio.coerceIn(
            MIN_RATIO,
            MAX_RATIO
        )

        val kneeDb = settings.kneeDb.coerceIn(
            0f,
            MAX_KNEE_DB
        )

        val amount = settings.amount.coerceIn(0f, 1f)

        for (i in 0 until frameCount) {
            val dryLeft = inputLeft[i]
            val dryRight = inputRight[i]

            // One linked detector controls both stereo channels.
            val peakLevel = max(abs(dryLeft), abs(dryRight))

            val detectorLevel = when (cachedDetector) {
                CompressorDetector.PEAK -> {
                    val coefficient = if (peakLevel > detectorEnvelope) {
                        attackCoefficient
                    } else {
                        releaseCoefficient
                    }

                    detectorEnvelope =
                        coefficient * detectorEnvelope +
                        (1f - coefficient) * peakLevel

                    detectorEnvelope
                }

                CompressorDetector.RMS -> {
                    val squaredLevel =
                        (dryLeft * dryLeft + dryRight * dryRight) * 0.5f

                    val coefficient = if (
                        squaredLevel > rmsSquaredEnvelope
                    ) {
                        attackCoefficient
                    } else {
                        releaseCoefficient
                    }

                    rmsSquaredEnvelope =
                        coefficient * rmsSquaredEnvelope +
                        (1f - coefficient) * squaredLevel

                    sqrt(max(0f, rmsSquaredEnvelope))
                }
            }

            val safeLevel = max(detectorLevel, MIN_GAIN)
            val levelDb = 20f * ln(safeLevel) / LN_10

            val targetGain = calculateGain(
                levelDb,
                thresholdDb,
                ratio,
                kneeDb
            )

            // Smooth gain reduction to avoid abrupt gain changes.
            val gainCoefficient = if (
                targetGain < gainReductionEnvelope
            ) {
                attackCoefficient
            } else {
                releaseCoefficient
            }

            gainReductionEnvelope =
                gainCoefficient * gainReductionEnvelope +
                (1f - gainCoefficient) * targetGain

            // Amount controls parallel compression strength.
            val compressedGain =
                1f + (gainReductionEnvelope - 1f) * amount

            val finalGain = compressedGain * makeupGain

            outputLeft[i] = dryLeft * finalGain
            outputRight[i] = dryRight * finalGain
        }
    }

    /**
     * Clears detector and gain state.
     * Call when intentionally resetting the processor.
     */
    fun reset() {
        detectorEnvelope = 0f
        rmsSquaredEnvelope = 0f
        gainReductionEnvelope = 1f
    }
}
