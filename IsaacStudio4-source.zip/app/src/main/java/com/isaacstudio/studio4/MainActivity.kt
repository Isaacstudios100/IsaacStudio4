package com.isaacstudio.studio4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.isaacstudio.studio4.audio.SynthEngine
import com.isaacstudio.studio4.audio.AudioOutputEngine
import com.isaacstudio.studio4.audio.Waveform
import com.isaacstudio.studio4.audio.SynthOscillatorSettings
import com.isaacstudio.studio4.audio.SynthFilterSettings
import com.isaacstudio.studio4.audio.SynthModulationSettings
import com.isaacstudio.studio4.audio.SynthFilterMode
import com.isaacstudio.studio4.audio.SynthAnalogCategory
import com.isaacstudio.studio4.audio.SynthDigitalWave
import com.isaacstudio.studio4.audio.SynthOscillatorType
import com.isaacstudio.studio4.audio.instruments.InstrumentType
import com.isaacstudio.studio4.audio.instruments.LayerId
import com.isaacstudio.studio4.audio.instruments.OrganEngine
import com.isaacstudio.studio4.audio.effects.RotarySpeakerProcessor
import com.isaacstudio.studio4.audio.effects.Mod1Settings
import com.isaacstudio.studio4.audio.effects.Mod1Type
import com.isaacstudio.studio4.audio.effects.Mod2Settings
import com.isaacstudio.studio4.audio.effects.Mod2Type
import com.isaacstudio.studio4.audio.effects.DelaySettings
import com.isaacstudio.studio4.audio.effects.DelaySubdivision
import com.isaacstudio.studio4.audio.effects.DelayFilterType
import com.isaacstudio.studio4.audio.effects.DelayFeedbackEffect
import com.isaacstudio.studio4.audio.effects.AmpEqSettings
import com.isaacstudio.studio4.audio.effects.TubeOverdriveSettings
import com.isaacstudio.studio4.audio.effects.AmpModel
import com.isaacstudio.studio4.audio.effects.CompressorSettings
import com.isaacstudio.studio4.audio.effects.CompressorDetector
import com.isaacstudio.studio4.audio.effects.ReverbSettings
import com.isaacstudio.studio4.audio.effects.ReverbType
import com.isaacstudio.studio4.audio.instruments.OrganModel
import com.isaacstudio.studio4.audio.instruments.PianoEngine
import com.isaacstudio.studio4.audio.instruments.PianoSampleBank
import com.isaacstudio.studio4.audio.instruments.PianoSoundModel
import com.isaacstudio.studio4.audio.PianoDecoderProbe
import com.isaacstudio.studio4.midi.MidiInput
import com.isaacstudio.studio4.audio.performance.PerformanceSnapshot
import com.isaacstudio.studio4.audio.performance.PerformanceLayer
import com.isaacstudio.studio4.audio.performance.PerformanceStorage
import com.isaacstudio.studio4.audio.performance.ProgramBankStorage

private val WHITE_KEYS = listOf(
    60, 62, 64, 65, 67, 69, 71,
    72, 74, 76, 77, 79, 81, 83, 84
)

private data class BlackKey(
    val note: Int,
    val afterWhiteIndex: Int
)

private val BLACK_KEYS = listOf(
    BlackKey(61, 0),
    BlackKey(63, 1),
    BlackKey(66, 3),
    BlackKey(68, 4),
    BlackKey(70, 5),
    BlackKey(73, 7),
    BlackKey(75, 8),
    BlackKey(78, 10),
    BlackKey(80, 11),
    BlackKey(82, 12)
)

private enum class StudioSection {
    PROGRAM_ESSENTIALS,
    PIANO,
    ORGAN,
    SYNTH,
    LAYER_EFFECTS
}
private data class ActiveVoice(
    val source: String,
    val originalNote: Int,
    val layerId: LayerId,
    val voiceId: Long,
    val pressId: Long,
    var keyDown: Boolean = true
)

private data class MidiChannelState(
    var sustainDown: Boolean = false,
    var volume: Int = 127,
    var expression: Int = 127,
    var modulation: Int = 0,
    var pitchBend14: Int = 8192
)

private data class OrganMidiMonitorState(
    val sustainDown: Boolean = false,
    val volume: Int = 127,
    val expression: Int = 127,
    val modulation: Int = 0,
    val pitchBend14: Int = 8192,
    val received: Boolean = false
)

private class LayerZone(
    enabledInitially: Boolean = false
) {
    var enabled by mutableStateOf(enabledInitially)
    var lowNote by mutableStateOf(0)
    var highNote by mutableStateOf(127)
}

private val WHITE_KEY_WIDTH = 30.dp
private val BLACK_KEY_WIDTH = 19.dp

private val DRAWBAR_NAMES = listOf(
    "16'", "5⅓'", "8'", "4'", "2⅔'",
    "2'", "1⅗'", "1⅓'", "1'"
)

class MainActivity : ComponentActivity() {

private val synth = SynthEngine()
private val synth2 = SynthEngine()
private val synth3 = SynthEngine()

private val organ = OrganEngine()
private val organ2 = OrganEngine()

private val piano = PianoEngine()
private val piano2 = PianoEngine()
private var pianoSampleBank: PianoSampleBank? = null

private val audioOutput = AudioOutputEngine()

    // Stage 6B: persistent performance library and UI state.
    private val performanceStorage by lazy {
        PerformanceStorage(applicationContext)
    }
    private var performanceLibrary by mutableStateOf<List<PerformanceSnapshot>>(emptyList())
    private var performanceName by mutableStateOf("")
    private var selectedPerformanceName by mutableStateOf("")
    private var performanceRecallRevision by mutableIntStateOf(0)
    private val programBankStorage by lazy {
        ProgramBankStorage(applicationContext)
    }
    private var programSlots by mutableStateOf<List<String?>>(List(8) { null })
    private var selectedProgramSlot by mutableIntStateOf(-1)

    private var midi: MidiInput? = null
    private var status by mutableStateOf("Starting...")

    private var selectedInstrument by mutableStateOf(InstrumentType.SYNTH)
private var selectedLayer by mutableStateOf(LayerId.SYNTH_1)
private var soloedLayer by mutableStateOf<LayerId?>(null)
    private var drawbars by mutableStateOf(
        listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
    )
private var organModel by mutableStateOf(OrganModel.B3)
private var organ1AuxEnabled by mutableStateOf(false)
private var organ2AuxEnabled by mutableStateOf(false)
private var auxMidiChannel by mutableIntStateOf(15)

private val activeVoices = mutableListOf<ActiveVoice>()
private val midiChannelStates = mutableMapOf<Pair<Int, Int>, MidiChannelState>()
private val organMidiMonitor = mutableStateMapOf(
    LayerId.ORGAN_1 to OrganMidiMonitorState(),
    LayerId.ORGAN_2 to OrganMidiMonitorState()
)

private val layerZones = LayerId.values()
    .associateWith { LayerZone() }
    .toMutableMap()
    .apply {
        getValue(LayerId.SYNTH_1).enabled = true
    }
private val layerVolumes = LayerId.values()
    .associateWith { mutableFloatStateOf(1.0f) }

private val organDrawbarSettings = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith {
        mutableStateMapOf(
            OrganModel.B3 to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0),
OrganModel.B3_BASS to listOf(8, 0, 0, 0, 0, 0, 0, 0, 0),
            OrganModel.VOX to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0),
            OrganModel.FARFISA to listOf(1, 0, 1, 0, 0, 0, 0, 0, 0),
            OrganModel.PIPE_1 to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0),
            OrganModel.PIPE_2 to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
        )
    }

private val organModelSettings = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(OrganModel.B3) }
private val organVoxFilterMix = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableFloatStateOf(0.5f) }
private val organB3PercussionEnabled = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(false) }

private val organB3PercussionHarmonic = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(2) }

private val organB3PercussionSoft = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(false) }

private val organB3PercussionFastDecay = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(true) }

private val organB3PercussionPolyMode = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(false) }

private val organVibratoChorusMode = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableIntStateOf(0) }

private var rotaryMode by mutableIntStateOf(RotarySpeakerProcessor.STOP)
private var rotaryDrive by mutableFloatStateOf(0f)
private var rotaryEnabled by mutableStateOf(true)
private var rotaryCloseMic by mutableStateOf(false)
private var rotaryStopMode by mutableStateOf(false)
private var rotaryAngle by mutableIntStateOf(0)

private var nextPressId = 1L

    private var waveform by mutableStateOf(Waveform.SAWTOOTH)
private var volume by mutableStateOf(1.0f)
private var synthLayerVolume by mutableStateOf(1.0f)
private var organLayerVolume by mutableStateOf(1.0f)
private var pianoLayerVolume by mutableStateOf(1.0f)
private var pianoSoundModel by mutableStateOf(PianoSoundModel.STUDIO_GRAND)

private val pianoSoundModels = mapOf(
    LayerId.PIANO_1 to mutableStateOf(PianoSoundModel.STUDIO_GRAND),
    LayerId.PIANO_2 to mutableStateOf(PianoSoundModel.STUDIO_GRAND)
)
private var octave by mutableIntStateOf(0)
private val layerOctaves = LayerId.values()
    .associateWith { mutableIntStateOf(0) }

private val synthOscillatorSettings = mapOf(
    LayerId.SYNTH_1 to mutableStateOf(synth.oscillatorSettings),
    LayerId.SYNTH_2 to mutableStateOf(synth2.oscillatorSettings),
    LayerId.SYNTH_3 to mutableStateOf(synth3.oscillatorSettings)
)

private val synthFilterSettings = mapOf(
    LayerId.SYNTH_1 to mutableStateOf(synth.filterSettings),
    LayerId.SYNTH_2 to mutableStateOf(synth2.filterSettings),
    LayerId.SYNTH_3 to mutableStateOf(synth3.filterSettings)
)

private val synthModulationSettings = mapOf(
    LayerId.SYNTH_1 to mutableStateOf(synth.modulationSettings),
    LayerId.SYNTH_2 to mutableStateOf(synth2.modulationSettings),
    LayerId.SYNTH_3 to mutableStateOf(synth3.modulationSettings)
)
    private var attack by mutableStateOf(0.005f)
    private var decay by mutableStateOf(0.12f)
    private var sustain by mutableStateOf(0.7f)
    private var release by mutableStateOf(0.3f)

    private val layerReverbSettings = LayerId.values().associateWith { layerId ->
        mutableStateOf(audioOutput.layerEffectsRackManager.settingsFor(layerId).reverb)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auxMidiChannel = getSharedPreferences("isaac_studio_midi", MODE_PRIVATE).getInt("aux_receive_channel", 15).coerceIn(7, 15)
        refreshPerformanceLibrary()
        refreshProgramBank()

synth.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_1).enabled
synth2.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_2).enabled
synth3.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_3).enabled

organ.isRenderingEnabled = layerZones.getValue(LayerId.ORGAN_1).enabled
organ2.isRenderingEnabled = layerZones.getValue(LayerId.ORGAN_2).enabled

piano.isRenderingEnabled = layerZones.getValue(LayerId.PIANO_1).enabled
piano2.isRenderingEnabled = layerZones.getValue(LayerId.PIANO_2).enabled

audioOutput.addRenderer(LayerId.SYNTH_1, "Synth 1", synth)
audioOutput.addRenderer(LayerId.SYNTH_2, "Synth 2", synth2)
audioOutput.addRenderer(LayerId.SYNTH_3, "Synth 3", synth3)
audioOutput.addStereoRenderer(LayerId.ORGAN_1, "Organ 1", organ)
audioOutput.addStereoRenderer(LayerId.ORGAN_2, "Organ 2", organ2)
audioOutput.addRenderer(LayerId.PIANO_1, "Piano 1", piano)
audioOutput.addRenderer(LayerId.PIANO_2, "Piano 2", piano2)

pianoSampleBank = try {
    PianoSampleBank(applicationContext.assets).also { bank ->
        piano.attachSampleBank(bank)
        piano2.attachSampleBank(bank)
    }
} catch (_: Exception) {
    null
}

audioOutput.start()

PianoDecoderProbe.run(this) { report ->
    status = report
}

organ.setDrawbars(
    organDrawbarSettings
        .getValue(LayerId.ORGAN_1)
        .getValue(OrganModel.B3)
        .toIntArray()
)

organ2.setDrawbars(
    organDrawbarSettings
        .getValue(LayerId.ORGAN_2)
        .getValue(OrganModel.B3)
        .toIntArray()
)

organ.organModel =
    organModelSettings.getValue(LayerId.ORGAN_1).value

organ2.organModel =
    organModelSettings.getValue(LayerId.ORGAN_2).value

organ.voxFilterMix =
    organVoxFilterMix.getValue(LayerId.ORGAN_1).floatValue

organ2.voxFilterMix =
    organVoxFilterMix.getValue(LayerId.ORGAN_2).floatValue

organ.b3PercussionEnabled =
    organB3PercussionEnabled.getValue(LayerId.ORGAN_1).value
organ.b3PercussionHarmonic =
    organB3PercussionHarmonic.getValue(LayerId.ORGAN_1).value
organ.b3PercussionSoft =
    organB3PercussionSoft.getValue(LayerId.ORGAN_1).value
organ.b3PercussionFastDecay =
    organB3PercussionFastDecay.getValue(LayerId.ORGAN_1).value
organ.b3PercussionPolyMode =
    organB3PercussionPolyMode.getValue(LayerId.ORGAN_1).value

organ2.b3PercussionEnabled =
    organB3PercussionEnabled.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionHarmonic =
    organB3PercussionHarmonic.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionSoft =
    organB3PercussionSoft.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionFastDecay =
    organB3PercussionFastDecay.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionPolyMode =
    organB3PercussionPolyMode.getValue(LayerId.ORGAN_2).value
organ.vibratoChorusMode =
    organVibratoChorusMode.getValue(LayerId.ORGAN_1).intValue

organ2.vibratoChorusMode =
    organVibratoChorusMode.getValue(LayerId.ORGAN_2).intValue

audioOutput.rotarySpeakerProcessor.mode = rotaryMode
audioOutput.rotarySpeakerProcessor.drive = rotaryDrive
audioOutput.rotarySpeakerProcessor.enabled = rotaryEnabled
audioOutput.rotarySpeakerProcessor.closeMic = rotaryCloseMic
audioOutput.rotarySpeakerProcessor.stopMode = rotaryStopMode
audioOutput.rotarySpeakerProcessor.anglePosition = rotaryAngle

midi = MidiInput(
    context = this,
    onNoteOn = { note, velocity, deviceId, channel ->
        playMidiNote(note, velocity, deviceId, channel)
    },
    onNoteOff = { note, deviceId, channel ->
        releaseMidiNote(note, deviceId, channel)
    },
    onSourceDisconnected = { deviceId ->
        releaseNotesFromDevice(deviceId)
    },
    onStatus = { text ->
        status = text
    },
    onControlChange = { controller, value, deviceId, channel ->
        handleMidiControlChange(controller, value, deviceId, channel)
    },
    onPitchBend = { value14, deviceId, channel ->
        handleMidiPitchBend(value14, deviceId, channel)
    },
    onProgramChange = { program, deviceId, channel ->
        handleMidiProgramChange(program, deviceId, channel)
    }
).also { it.start() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF101116)
                ) {
StudioScreen(
    status = status,
    performanceLibrary = performanceLibrary,
    performanceName = performanceName,
    selectedPerformanceName = selectedPerformanceName,
    performanceRecallRevision = performanceRecallRevision,
    programSlots = programSlots,
    selectedProgramSlot = selectedProgramSlot,
    onProgramSlotRecall = { recallProgramSlot(it) },
    onProgramSlotAssign = { slot, name -> assignProgramSlot(slot, name) },
    onPerformanceNameChange = { performanceName = it },
    onPerformanceSelect = {
        selectedPerformanceName = it
        performanceName = it
    },
    onPerformanceSave = { savePerformance() },
    onPerformanceRecall = { recallPerformance(it) },
    onPerformanceRename = { oldName, newName ->
        renamePerformance(oldName, newName)
    },
    onPerformanceDelete = { deletePerformance(it) },
    audioOutput = audioOutput,
    soloedLayer = soloedLayer,
    onSoloedLayerChange = { nextSolo ->
        soloedLayer = nextSolo
        audioOutput.soloLayerId = nextSolo
    },
    organMidiSustainDown = organMidiMonitor.getValue(if (selectedLayer == LayerId.ORGAN_2) LayerId.ORGAN_2 else LayerId.ORGAN_1).sustainDown,
    organMidiVolume = organMidiMonitor.getValue(if (selectedLayer == LayerId.ORGAN_2) LayerId.ORGAN_2 else LayerId.ORGAN_1).volume,
    organMidiExpression = organMidiMonitor.getValue(if (selectedLayer == LayerId.ORGAN_2) LayerId.ORGAN_2 else LayerId.ORGAN_1).expression,
    organMidiModulation = organMidiMonitor.getValue(if (selectedLayer == LayerId.ORGAN_2) LayerId.ORGAN_2 else LayerId.ORGAN_1).modulation,
    organMidiPitchBend14 = organMidiMonitor.getValue(if (selectedLayer == LayerId.ORGAN_2) LayerId.ORGAN_2 else LayerId.ORGAN_1).pitchBend14,
    organMidiReceived = organMidiMonitor.getValue(if (selectedLayer == LayerId.ORGAN_2) LayerId.ORGAN_2 else LayerId.ORGAN_1).received,
organ1AuxEnabled = organ1AuxEnabled,
    organ2AuxEnabled = organ2AuxEnabled,
    organ1MidiMonitor = organMidiMonitor.getValue(LayerId.ORGAN_1),
    organ2MidiMonitor = organMidiMonitor.getValue(LayerId.ORGAN_2),
    onOrgan1AuxEnabledChange = { enabled ->
        if (organ1AuxEnabled && !enabled) releaseAuxVoicesForLayer(LayerId.ORGAN_1)
        organ1AuxEnabled = enabled
    },
    onOrgan2AuxEnabledChange = { enabled ->
        if (organ2AuxEnabled && !enabled) releaseAuxVoicesForLayer(LayerId.ORGAN_2)
        organ2AuxEnabled = enabled
    },
                        instrument = selectedInstrument,
selectedLayer = selectedLayer,
layerEnabled = layerZones.getValue(selectedLayer).enabled,
layerVolume = layerVolumes.getValue(selectedLayer).floatValue,
organ1LayerVolume = layerVolumes.getValue(LayerId.ORGAN_1).floatValue,
organ2LayerVolume = layerVolumes.getValue(LayerId.ORGAN_2).floatValue,
    layerEnabledStates = LayerId.values().associateWith { layerZones.getValue(it).enabled },
    layerVolumeValues = LayerId.values().associateWith { layerVolumes.getValue(it).floatValue },
    onLayerEnabledChangeFor = { id, enabled -> setLayerEnabled(id, enabled) },
    onLayerVolumeChangeFor = { id, value -> setLayerVolume(id, value) },
lowNote = layerZones.getValue(selectedLayer).lowNote,
highNote = layerZones.getValue(selectedLayer).highNote,

onLayerSelect = { selectLayer(it) },

onLayerEnabledChange = {
    setLayerEnabled(selectedLayer, it)
},

onLayerVolumeChange = {
    setLayerVolume(selectedLayer, it)
},
onOrgan1LayerVolumeChange = {
    setLayerVolume(LayerId.ORGAN_1, it)
},
onOrgan2LayerVolumeChange = {
    setLayerVolume(LayerId.ORGAN_2, it)
},

onLayerLowNoteChange = { value ->
    val zone = layerZones.getValue(selectedLayer)
    zone.lowNote = value.coerceIn(0, zone.highNote)
},

onLayerHighNoteChange = { value ->
    val zone = layerZones.getValue(selectedLayer)
    zone.highNote = value.coerceIn(zone.lowNote, 127)
},
drawbars = drawbars,
organModel = organModel,
voxFilterMix = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organVoxFilterMix.getValue(selectedLayer).floatValue
} else {
    0.5f
},
b3PercussionEnabled = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionEnabled.getValue(selectedLayer).value
} else {
    false
},
b3PercussionHarmonic = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionHarmonic.getValue(selectedLayer).value
} else {
    2
},
b3PercussionSoft = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionSoft.getValue(selectedLayer).value
} else {
    false
},
b3PercussionFastDecay = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionFastDecay.getValue(selectedLayer).value
} else {
    true
},
b3PercussionPolyMode = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionPolyMode.getValue(selectedLayer).value
} else {
    false
},
vibratoChorusMode = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organVibratoChorusMode.getValue(selectedLayer).intValue
} else {
    0
},
rotaryMode = this@MainActivity.rotaryMode,
rotaryDrive = rotaryDrive,
rotaryEnabled = rotaryEnabled,
rotaryCloseMic = rotaryCloseMic,
rotaryStopMode = rotaryStopMode,
rotaryAngle = rotaryAngle,
onOrganModelChange = { model ->
    organModel = model
    organModelSettings.getValue(selectedLayer).value = model

    val registration = organDrawbarSettings
        .getValue(selectedLayer)
        .getValue(model)

    drawbars = registration

    when (selectedLayer) {
        LayerId.ORGAN_1 -> {
            organ.organModel = model
            organ.setDrawbars(registration.toIntArray())
        }

        LayerId.ORGAN_2 -> {
            organ2.organModel = model
            organ2.setDrawbars(registration.toIntArray())
        }

    else -> Unit
}
},
onVoxFilterMixChange = { value ->
    val mix = value.coerceIn(0.0f, 1.0f)

    organVoxFilterMix.getValue(selectedLayer).floatValue = mix

    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.voxFilterMix = mix
        LayerId.ORGAN_2 -> organ2.voxFilterMix = mix
        else -> Unit
    }
},
onB3PercussionEnabledChange = { value ->
    organB3PercussionEnabled.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionEnabled = value
        LayerId.ORGAN_2 -> organ2.b3PercussionEnabled = value
        else -> Unit
    }
},
onB3PercussionHarmonicChange = { value ->
    organB3PercussionHarmonic.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionHarmonic = value
        LayerId.ORGAN_2 -> organ2.b3PercussionHarmonic = value
        else -> Unit
    }
},
onB3PercussionSoftChange = { value ->
    organB3PercussionSoft.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionSoft = value
        LayerId.ORGAN_2 -> organ2.b3PercussionSoft = value
        else -> Unit
    }
},
onB3PercussionFastDecayChange = { value ->
    organB3PercussionFastDecay.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionFastDecay = value
        LayerId.ORGAN_2 -> organ2.b3PercussionFastDecay = value
        else -> Unit
    }
},
onB3PercussionPolyModeChange = { value ->
    organB3PercussionPolyMode.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionPolyMode = value
        LayerId.ORGAN_2 -> organ2.b3PercussionPolyMode = value
        else -> Unit
    }
},

onVibratoChorusModeChange = { mode ->
    val safeMode = mode.coerceIn(0, 6)
    organVibratoChorusMode.getValue(selectedLayer).intValue = safeMode

    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.vibratoChorusMode = safeMode
        LayerId.ORGAN_2 -> organ2.vibratoChorusMode = safeMode
        else -> Unit
    }
},

onRotaryModeChange = { mode ->
    rotaryMode = mode.coerceIn(
        RotarySpeakerProcessor.STOP,
        RotarySpeakerProcessor.FAST
    )
    audioOutput.rotarySpeakerProcessor.mode = rotaryMode
},
onRotaryDriveChange = { value ->
    rotaryDrive = value.coerceIn(0.0f, 1.0f)
    audioOutput.rotarySpeakerProcessor.drive = rotaryDrive
},
onRotaryEnabledChange = { value ->
    rotaryEnabled = value
    audioOutput.rotarySpeakerProcessor.enabled = value
},
onRotaryCloseMicChange = { value ->
    rotaryCloseMic = value
    audioOutput.rotarySpeakerProcessor.closeMic = value
},
onRotaryStopModeChange = { value ->
    rotaryStopMode = value
    audioOutput.rotarySpeakerProcessor.stopMode = value
},
onRotaryAngleChange = { value ->
    rotaryAngle = value.coerceIn(0, 6)
    audioOutput.rotarySpeakerProcessor.anglePosition = rotaryAngle
},

waveform = waveform,
oscillatorSettings = if (selectedInstrument == InstrumentType.SYNTH) {
    synthOscillatorSettings.getValue(selectedLayer).value
} else {
    SynthOscillatorSettings()
},
filterSettings = if (selectedInstrument == InstrumentType.SYNTH) {
    synthFilterSettings.getValue(selectedLayer).value
} else {
    SynthFilterSettings()
},
modulationSettings = if (selectedInstrument == InstrumentType.SYNTH) {
    synthModulationSettings.getValue(selectedLayer).value
} else {
    SynthModulationSettings()
},
pianoSoundModel = pianoSoundModel,
                        volume = volume,
synthLayerVolume = synthLayerVolume,
organLayerVolume = organLayerVolume,
pianoLayerVolume = pianoLayerVolume,
                        octave = octave,
                        attack = attack,
                        decay = decay,
                        sustain = sustain,
                        release = release,
                        reverbSettings = layerReverbSettings.getValue(selectedLayer).value,

                        onInstrumentChange = { type ->
                            switchInstrument(type)
                        },

                        onDrawbarChange = { index, level ->
                            val updated = drawbars.toMutableList()
                            updated[index] = level
                            drawbars = updated

organDrawbarSettings
    .getValue(selectedLayer)[organModel] = updated

                            when (selectedLayer) {
                                LayerId.ORGAN_1 ->
                                    organ.setDrawbar(index, level)

                                LayerId.ORGAN_2 ->
                                    organ2.setDrawbar(index, level)

                                else -> Unit
                            }
                        },

                        onWaveformChange = {
                            waveform = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.waveform = it
                                LayerId.SYNTH_2 -> synth2.waveform = it
                                LayerId.SYNTH_3 -> synth3.waveform = it
                                else -> Unit
                            }
                        },

                        onOscillatorSettingsChange = { updated ->
                            val engine = when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth
                                LayerId.SYNTH_2 -> synth2
                                LayerId.SYNTH_3 -> synth3
                                else -> null
                            }

                            if (engine != null) {
                                engine.oscillatorSettings = updated
                                synthOscillatorSettings.getValue(selectedLayer).value = updated
                            }
                        },
                        onFilterSettingsChange = { updated ->
                            val engine = when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth
                                LayerId.SYNTH_2 -> synth2
                                LayerId.SYNTH_3 -> synth3
                                else -> null
                            }

                            if (engine != null) {
                                engine.filterSettings = updated
                                synthFilterSettings.getValue(selectedLayer).value = updated
                            }
                        },
                        onModulationSettingsChange = { updated ->
                            val engine = when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth
                                LayerId.SYNTH_2 -> synth2
                                LayerId.SYNTH_3 -> synth3
                                else -> null
                            }

                            if (engine != null) {
                                engine.modulationSettings = updated
                                synthModulationSettings.getValue(selectedLayer).value = updated
                            }
                        },


                        onVolumeChange = {
                            volume = it
                            audioOutput.masterVolume = it
                        },

                        onSynthLayerVolumeChange = {
                            synthLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onOrganLayerVolumeChange = {
                            organLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onPianoLayerVolumeChange = {
                            pianoLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onPianoSoundModelChange = { model ->
                            pianoSoundModel = model
                            pianoSoundModels.getValue(selectedLayer).value = model

                            when (selectedLayer) {
                                LayerId.PIANO_1 -> piano.soundModel = model
                                LayerId.PIANO_2 -> piano2.soundModel = model
                                else -> Unit
                            }
                        },

onOctaveChange = {
    octave = it
    layerOctaves.getValue(selectedLayer).intValue = it

    when (selectedLayer) {
        LayerId.SYNTH_1 -> synth.transposeSemitones = it * 12
        LayerId.SYNTH_2 -> synth2.transposeSemitones = it * 12
        LayerId.SYNTH_3 -> synth3.transposeSemitones = it * 12
        else -> Unit
    }
},
	
                        onAttackChange = {
                            attack = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.attack = it
                                LayerId.SYNTH_2 -> synth2.attack = it
                                LayerId.SYNTH_3 -> synth3.attack = it
                                else -> Unit
                            }
                        },

                        onDecayChange = {
                            decay = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.decay = it
                                LayerId.SYNTH_2 -> synth2.decay = it
                                LayerId.SYNTH_3 -> synth3.decay = it
                                else -> Unit
                            }
                        },

                        onSustainChange = {
                            sustain = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.sustain = it
                                LayerId.SYNTH_2 -> synth2.sustain = it
                                LayerId.SYNTH_3 -> synth3.sustain = it
                                else -> Unit
                            }
                        },

                        onReleaseChange = {
                            release = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.release = it
                                LayerId.SYNTH_2 -> synth2.release = it
                                LayerId.SYNTH_3 -> synth3.release = it
                                else -> Unit
                            }
                        },

onReverbSettingsChange = { updated ->
    layerReverbSettings.getValue(selectedLayer).value = updated
    val manager = audioOutput.layerEffectsRackManager
    val latest = manager.settingsFor(selectedLayer)
    manager.update(selectedLayer, latest.copy(reverb = updated))
},
onNoteOn = { note, velocity ->
    playNote(note, velocity, "onscreen")
},

onNoteOff = { note ->
    releaseNote(note, "onscreen")
}
                    )
                }
            }
        }
    }

private fun playNote(note: Int, velocity: Float, source: String) {
    val safeNote = note.coerceIn(0, 127)
    val pressId = nextPressId++

    for ((layerId, zone) in layerZones) {
        if (!zone.enabled) continue

        if (safeNote !in zone.lowNote..zone.highNote) continue

val layerOctave = layerOctaves.getValue(layerId).intValue

val playedNote = if (layerId.instrument == InstrumentType.SYNTH) {
    safeNote
} else {
    (safeNote + layerOctave * 12).coerceIn(0, 127)
}

        val voiceId = when (layerId) {
            LayerId.SYNTH_1 -> synth.noteOn(playedNote, velocity)
            LayerId.SYNTH_2 -> synth2.noteOn(playedNote, velocity)
            LayerId.SYNTH_3 -> synth3.noteOn(playedNote, velocity)

            LayerId.ORGAN_1 -> organ.noteOn(playedNote)
            LayerId.ORGAN_2 -> organ2.noteOn(playedNote)

            LayerId.PIANO_1 -> piano.noteOn(playedNote, velocity)
            LayerId.PIANO_2 -> piano2.noteOn(playedNote, velocity)
        }

        if (voiceId != 0L) {
            activeVoices.add(
                ActiveVoice(
                    source,
                    safeNote,
                    layerId,
                    voiceId,
                    pressId
                )
            )
        }
    }
}

private fun releaseNote(note: Int, source: String) {
    val safeNote = note.coerceIn(0, 127)

    val matchingPress = activeVoices.lastOrNull {
        it.source == source && it.originalNote == safeNote
    } ?: return

    val voicesToRelease = activeVoices.filter {
        it.source == source &&
        it.originalNote == safeNote &&
        it.pressId == matchingPress.pressId
    }

    voicesToRelease.forEach {
        releaseVoice(it)
    }

    activeVoices.removeAll(voicesToRelease.toSet())
}

private fun releaseAuxVoicesForLayer(layerId: LayerId) {
    val suffix = ":$auxMidiChannel"
    val voices = activeVoices.filter {
        it.layerId == layerId && it.source.startsWith("midi:") && it.source.endsWith(suffix)
    }
    voices.forEach { releaseVoice(it) }
    activeVoices.removeAll(voices.toSet())
}

private fun midiLayerForChannel(channel: Int): LayerId? =
    when (channel) {
        0 -> LayerId.SYNTH_1
        1 -> LayerId.SYNTH_2
        2 -> LayerId.SYNTH_3
        3 -> LayerId.ORGAN_1
        4 -> LayerId.ORGAN_2
        5 -> LayerId.PIANO_1
        6 -> LayerId.PIANO_2
        else -> null
    }

private fun playAuxMidiNote(
    note: Int,
    velocity: Float,
    deviceId: Int,
    channel: Int
) {
    val source = "midi:$deviceId:$channel"
    val state = midiChannelStates.getOrPut(deviceId to channel) {
        MidiChannelState()
    }
    val safeNote = note.coerceIn(0, 127)
    val safeVelocity = velocity.coerceIn(0f, 1f)
    val targets = listOfNotNull(
        LayerId.ORGAN_1.takeIf { organ1AuxEnabled },
        LayerId.ORGAN_2.takeIf { organ2AuxEnabled }
    )
    if (targets.isEmpty()) return

    val pressId = nextPressId++
    targets.forEach { layerId ->
        val zone = layerZones.getValue(layerId)
        if (safeNote !in zone.lowNote..zone.highNote) return@forEach
        val playedNote = (safeNote +
            layerOctaves.getValue(layerId).intValue * 12).coerceIn(0, 127)
        val voiceId = when (layerId) {
            LayerId.ORGAN_1 -> organ.noteOn(playedNote)
            LayerId.ORGAN_2 -> organ2.noteOn(playedNote)
            else -> 0L
        }
        if (voiceId == 0L) return@forEach
        val voice = ActiveVoice(source, safeNote, layerId, voiceId, pressId)
        activeVoices.add(voice)
        applyMidiControls(voice, state)
    }
}

private fun playMidiNote(
    note: Int,
    velocity: Float,
    deviceId: Int,
    channel: Int
) {
    if (channel == auxMidiChannel) {
        playAuxMidiNote(note, velocity, deviceId, channel)
        return
    }
    val layerId = midiLayerForChannel(channel) ?: return
    val zone = layerZones.getValue(layerId)
    val safeNote = note.coerceIn(0, 127)

    if (!zone.enabled || safeNote !in zone.lowNote..zone.highNote) return

    val source = "midi:$deviceId:$channel"
    val state = midiChannelStates.getOrPut(deviceId to channel) {
        MidiChannelState()
    }

    val layerOctave = layerOctaves.getValue(layerId).intValue
    val playedNote = if (layerId.instrument == InstrumentType.SYNTH) {
        safeNote
    } else {
        (safeNote + layerOctave * 12).coerceIn(0, 127)
    }

    val safeVelocity = velocity.coerceIn(0f, 1f)
    val voiceId = when (layerId) {
        LayerId.SYNTH_1 -> synth.noteOn(playedNote, safeVelocity)
        LayerId.SYNTH_2 -> synth2.noteOn(playedNote, safeVelocity)
        LayerId.SYNTH_3 -> synth3.noteOn(playedNote, safeVelocity)
        LayerId.ORGAN_1 -> organ.noteOn(playedNote)
        LayerId.ORGAN_2 -> organ2.noteOn(playedNote)
        LayerId.PIANO_1 -> piano.noteOn(playedNote, safeVelocity)
        LayerId.PIANO_2 -> piano2.noteOn(playedNote, safeVelocity)
    }

    if (voiceId == 0L) return

    val voice = ActiveVoice(
        source,
        safeNote,
        layerId,
        voiceId,
        nextPressId++
    )
    activeVoices.add(voice)
    applyMidiControls(voice, state)
}

private fun releaseMidiNote(note: Int, deviceId: Int, channel: Int) {
    if (channel == auxMidiChannel) {
        val source = "midi:$deviceId:$channel"
        val safeNote = note.coerceIn(0, 127)
        val matchingPress = activeVoices.lastOrNull {
            it.source == source && it.originalNote == safeNote && it.keyDown
        } ?: return
        val pairedVoices = activeVoices.filter {
            it.source == source &&
            it.originalNote == safeNote &&
            it.pressId == matchingPress.pressId &&
            it.keyDown
        }
        pairedVoices.forEach { it.keyDown = false }
        if (midiChannelStates[deviceId to channel]?.sustainDown == true) return
        pairedVoices.forEach { releaseVoice(it) }
        activeVoices.removeAll(pairedVoices.toSet())
        return
    }
    if (midiLayerForChannel(channel) == null) return

    val source = "midi:$deviceId:$channel"
    val safeNote = note.coerceIn(0, 127)

    val voice = activeVoices.lastOrNull {
        it.source == source &&
        it.originalNote == safeNote &&
        it.keyDown
    } ?: return

    voice.keyDown = false

    val state = midiChannelStates[deviceId to channel]
    if (state?.sustainDown == true) return

    releaseVoice(voice)
    activeVoices.remove(voice)
}

private fun applyMidiControls(
    voice: ActiveVoice,
    state: MidiChannelState
) {
    val normalizedBend =
        ((state.pitchBend14 - 8192) / 8192.0).coerceIn(-1.0, 1.0)
    val bendSemitones = normalizedBend * 2.0
    val gain = (state.volume / 127.0) * (state.expression / 127.0)
    val modulation = state.modulation / 127.0

    when (voice.layerId) {
        LayerId.SYNTH_1 -> synth.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.SYNTH_2 -> synth2.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.SYNTH_3 -> synth3.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.ORGAN_1 -> organ.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.ORGAN_2 -> organ2.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.PIANO_1 -> piano.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.PIANO_2 -> piano2.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
    }
}

private fun refreshMidiChannelVoices(
    deviceId: Int,
    channel: Int,
    state: MidiChannelState
) {
    val source = "midi:$deviceId:$channel"
    activeVoices
        .filter { it.source == source }
        .forEach { applyMidiControls(it, state) }
}

private fun updateOrganMidiMonitor(
    deviceId: Int,
    channel: Int,
    update: (OrganMidiMonitorState) -> OrganMidiMonitorState
) {
    val direct = midiLayerForChannel(channel)
    val targets = when (direct) {
        LayerId.ORGAN_1, LayerId.ORGAN_2 -> listOf(direct)
        else -> if (channel == auxMidiChannel) listOfNotNull(
            LayerId.ORGAN_1.takeIf { organ1AuxEnabled },
            LayerId.ORGAN_2.takeIf { organ2AuxEnabled }
        ) else emptyList()
    }
    targets.forEach { layer ->
        organMidiMonitor[layer] = update(organMidiMonitor.getValue(layer))
            .copy(received = true)
    }
}

private fun handleMidiControlChange(
    controller: Int,
    value: Int,
    deviceId: Int,
    channel: Int
) {
    if (midiLayerForChannel(channel) == null && channel != auxMidiChannel) return

    val state = midiChannelStates.getOrPut(deviceId to channel) {
        MidiChannelState()
    }
    val safeValue = value.coerceIn(0, 127)

    when (controller) {
        64 -> {
            val pedalWasDown = state.sustainDown
            state.sustainDown = safeValue >= 64
            updateOrganMidiMonitor(deviceId, channel) {
                it.copy(sustainDown = state.sustainDown)
            }

            if (pedalWasDown && !state.sustainDown) {
                val source = "midi:$deviceId:$channel"
                val deferred = activeVoices.filter {
                    it.source == source && !it.keyDown
                }
                deferred.forEach { releaseVoice(it) }
                activeVoices.removeAll(deferred.toSet())
            }
            return
        }
        7 -> state.volume = safeValue
        11 -> state.expression = safeValue
        1 -> state.modulation = safeValue
        else -> return
    }

    updateOrganMidiMonitor(deviceId, channel) {
        it.copy(
            volume = state.volume,
            expression = state.expression,
            modulation = state.modulation
        )
    }
    refreshMidiChannelVoices(deviceId, channel, state)
}

private fun handleMidiPitchBend(
    value14: Int,
    deviceId: Int,
    channel: Int
) {
    if (midiLayerForChannel(channel) == null && channel != auxMidiChannel) return

    val state = midiChannelStates.getOrPut(deviceId to channel) {
        MidiChannelState()
    }
    state.pitchBend14 = value14.coerceIn(0, 16383)
    updateOrganMidiMonitor(deviceId, channel) {
        it.copy(pitchBend14 = state.pitchBend14)
    }
    refreshMidiChannelVoices(deviceId, channel, state)
}

private fun handleMidiProgramChange(
    program: Int,
    deviceId: Int,
    channel: Int
) {
    val layerId = midiLayerForChannel(channel) ?: return

    when (layerId) {
        LayerId.SYNTH_1,
        LayerId.SYNTH_2,
        LayerId.SYNTH_3 -> {
            val waveformValue = when (program) {
                0 -> Waveform.SINE
                1 -> Waveform.TRIANGLE
                2 -> Waveform.SAWTOOTH
                3 -> Waveform.SQUARE
                else -> return
            }
            when (layerId) {
                LayerId.SYNTH_1 -> synth.waveform = waveformValue
                LayerId.SYNTH_2 -> synth2.waveform = waveformValue
                LayerId.SYNTH_3 -> synth3.waveform = waveformValue
                else -> Unit
            }
            if (selectedLayer == layerId) waveform = waveformValue
        }

        LayerId.ORGAN_1,
        LayerId.ORGAN_2 -> {
            val model = when (program) {
                0 -> OrganModel.B3
                1 -> OrganModel.B3_BASS
                2 -> OrganModel.VOX
                3 -> OrganModel.FARFISA
                4 -> OrganModel.PIPE_1
                5 -> OrganModel.PIPE_2
                else -> return
            }

            organModelSettings.getValue(layerId).value = model
            val engine = if (layerId == LayerId.ORGAN_1) organ else organ2
            engine.organModel = model

            if (selectedLayer == layerId) {
                organModel = model
                drawbars = organDrawbarSettings
                    .getValue(layerId)
                    .getValue(model)
            }
        }

        LayerId.PIANO_1,
        LayerId.PIANO_2 -> {
            val model = PianoSoundModel.values().getOrNull(program) ?: return

            pianoSoundModels.getValue(layerId).value = model
            when (layerId) {
                LayerId.PIANO_1 -> piano.soundModel = model
                LayerId.PIANO_2 -> piano2.soundModel = model
                else -> Unit
            }
            if (selectedLayer == layerId) pianoSoundModel = model
        }
    }
}

private fun clearMidiChannelStateForLayer(layerId: LayerId) {
    val channel = when (layerId) {
        LayerId.SYNTH_1 -> 0
        LayerId.SYNTH_2 -> 1
        LayerId.SYNTH_3 -> 2
        LayerId.ORGAN_1 -> 3
        LayerId.ORGAN_2 -> 4
        LayerId.PIANO_1 -> 5
        LayerId.PIANO_2 -> 6
    }
    midiChannelStates.keys.removeAll { it.second == channel }
}

private fun releaseVoice(voice: ActiveVoice) {
    when (voice.layerId) {
        LayerId.SYNTH_1 -> synth.noteOffVoice(voice.voiceId)
        LayerId.SYNTH_2 -> synth2.noteOffVoice(voice.voiceId)
        LayerId.SYNTH_3 -> synth3.noteOffVoice(voice.voiceId)

        LayerId.ORGAN_1 -> organ.noteOffVoice(voice.voiceId)
        LayerId.ORGAN_2 -> organ2.noteOffVoice(voice.voiceId)

        LayerId.PIANO_1 -> piano.noteOffVoice(voice.voiceId)
        LayerId.PIANO_2 -> piano2.noteOffVoice(voice.voiceId)
    }
}
private fun setLayerRenderingEnabled(
    layerId: LayerId,
    enabled: Boolean
) {
    when (layerId) {
        LayerId.SYNTH_1 -> synth.isRenderingEnabled = enabled
        LayerId.SYNTH_2 -> synth2.isRenderingEnabled = enabled
        LayerId.SYNTH_3 -> synth3.isRenderingEnabled = enabled

        LayerId.ORGAN_1 -> organ.isRenderingEnabled = enabled
        LayerId.ORGAN_2 -> organ2.isRenderingEnabled = enabled

        LayerId.PIANO_1 -> piano.isRenderingEnabled = enabled
        LayerId.PIANO_2 -> piano2.isRenderingEnabled = enabled
    }
}

private fun setLayerEnabled(
    layerId: LayerId,
    enabled: Boolean
) {
    layerZones.getValue(layerId).enabled = enabled
    setLayerRenderingEnabled(layerId, enabled)

    if (!enabled) {
        val matchingVoices = activeVoices.filter {
            it.layerId == layerId
        }

        matchingVoices.forEach {
            releaseVoice(it)
        }

        activeVoices.removeAll(matchingVoices.toSet())
        clearMidiChannelStateForLayer(layerId)
    }
}

private fun setLayerVolume(
    layerId: LayerId,
    newVolume: Float
) {
    val safeVolume = newVolume.coerceIn(0f, 1f)

    layerVolumes.getValue(layerId).floatValue = safeVolume

    when (layerId) {
        LayerId.SYNTH_1 -> synth.layerVolume = safeVolume
        LayerId.SYNTH_2 -> synth2.layerVolume = safeVolume
        LayerId.SYNTH_3 -> synth3.layerVolume = safeVolume

        LayerId.ORGAN_1 -> organ.layerVolume = safeVolume
        LayerId.ORGAN_2 -> organ2.layerVolume = safeVolume

        LayerId.PIANO_1 -> piano.layerVolume = safeVolume
        LayerId.PIANO_2 -> piano2.layerVolume = safeVolume
    }
}



private fun refreshPerformanceLibrary() {
    try {
        performanceLibrary = performanceStorage.loadAll()
    } catch (error: Exception) {
        status = "Performance library error: ${error.message ?: "Unable to read"}"
    }
}

private fun refreshProgramBank() {
    try {
        programSlots = programBankStorage.loadSlots()
    } catch (error: Exception) {
        status = "Program bank error: ${error.message ?: "Unable to read"}"
    }
}

private fun assignProgramSlot(slot: Int, name: String): Boolean {
    val performance = performanceLibrary.firstOrNull {
        it.name.equals(name.trim(), ignoreCase = true)
    }
    if (performance == null) {
        status = "Cannot assign: performance not found"
        return false
    }
    return try {
        programBankStorage.assign(slot, performance.name)
        programSlots = programBankStorage.loadSlots()
        selectedProgramSlot = slot
        status = "Program ${slot + 1} assigned: ${performance.name}"
        true
    } catch (error: Exception) {
        status = "Program assignment failed: ${error.message ?: "Storage error"}"
        false
    }
}

private fun recallProgramSlot(slot: Int) {
    if (slot !in programSlots.indices) return
    val name = programSlots[slot]
    if (name.isNullOrBlank()) {
        status = "Program ${slot + 1} is empty. Use ASSIGN to fill it."
        return
    }
    val snapshot = performanceLibrary.firstOrNull {
        it.name.equals(name, ignoreCase = true)
    }
    if (snapshot == null) {
        status = "Program ${slot + 1}: assigned performance not found: $name"
        return
    }
    try {
        restorePerformance(snapshot)
        selectedPerformanceName = snapshot.name
        performanceName = snapshot.name
        selectedProgramSlot = slot
        status = "Program ${slot + 1} loaded: ${snapshot.name}"
    } catch (error: Exception) {
        status = "Program recall failed: ${error.message ?: "Invalid performance"}"
    }
}

private fun savePerformance() {
    val name = performanceName.trim()
    if (name.isEmpty()) {
        status = "Enter a performance name first"
        return
    }
    try {
        performanceStorage.save(capturePerformance(name))
        refreshPerformanceLibrary()
        selectedPerformanceName = name
        performanceName = name
        status = "Saved performance: $name"
    } catch (error: Exception) {
        status = "Save failed: ${error.message ?: "Storage error"}"
    }
}

private fun recallPerformance(name: String) {
    val snapshot = performanceLibrary.firstOrNull {
        it.name.equals(name.trim(), ignoreCase = true)
    }
    if (snapshot == null) {
        status = "Performance not found: $name"
        return
    }
    try {
        restorePerformance(snapshot)
        selectedPerformanceName = snapshot.name
        performanceName = snapshot.name
        status = "Loaded performance: ${snapshot.name}"
    } catch (error: Exception) {
        status = "Load failed: ${error.message ?: "Invalid performance"}"
    }
}

private fun renamePerformance(oldName: String, newName: String) {
    if (newName.trim().isEmpty()) {
        status = "Enter a new performance name"
        return
    }
    try {
        performanceStorage.rename(oldName, newName)
        programBankStorage.renamePerformance(oldName, newName.trim())
        refreshProgramBank()
        refreshPerformanceLibrary()
        selectedPerformanceName = newName.trim()
        performanceName = newName.trim()
        status = "Renamed performance to: ${newName.trim()}"
    } catch (error: Exception) {
        status = "Rename failed: ${error.message ?: "Storage error"}"
    }
}

private fun deletePerformance(name: String) {
    if (name.isBlank()) {
        status = "Select a performance to delete"
        return
    }
    try {
        performanceStorage.delete(name)
        programBankStorage.clearPerformance(name)
        refreshProgramBank()
        if (programSlots.none { it != null }) selectedProgramSlot = -1
        refreshPerformanceLibrary()
        selectedPerformanceName = ""
        performanceName = ""
        status = "Deleted performance: $name"
    } catch (error: Exception) {
        status = "Delete failed: ${error.message ?: "Storage error"}"
    }
}

private fun capturePerformance(name: String): PerformanceSnapshot {
    val capturedLayers = LayerId.values().associateWith { layerId ->
        val zone = layerZones.getValue(layerId)
        val common = PerformanceLayer(
            enabled = zone.enabled,
            lowKey = zone.lowNote,
            highKey = zone.highNote,
            volume = layerVolumes.getValue(layerId).floatValue,
            octave = layerOctaves.getValue(layerId).intValue,
            effects = audioOutput.layerEffectsRackManager.settingsFor(layerId)
        )

        when (layerId) {
            LayerId.SYNTH_1,
            LayerId.SYNTH_2,
            LayerId.SYNTH_3 -> {
                val engine = when (layerId) {
                    LayerId.SYNTH_1 -> synth
                    LayerId.SYNTH_2 -> synth2
                    LayerId.SYNTH_3 -> synth3
                    else -> error("Unexpected synth layer")
                }
                common.copy(
                    waveform = engine.waveform,
                    attack = engine.attack,
                    decay = engine.decay,
                    sustain = engine.sustain,
                    release = engine.release,
                    oscillatorSettings = engine.oscillatorSettings,
                    filterSettings = engine.filterSettings,
                    modulationSettings = engine.modulationSettings
                )
            }

            LayerId.ORGAN_1,
            LayerId.ORGAN_2 -> common.copy(
                organModel = organModelSettings.getValue(layerId).value,
                organDrawbars = organDrawbarSettings.getValue(layerId).toMap(),
                organVoxFilterMix = organVoxFilterMix.getValue(layerId).floatValue,
                b3PercussionEnabled = organB3PercussionEnabled.getValue(layerId).value,
                b3PercussionHarmonic = organB3PercussionHarmonic.getValue(layerId).value,
                b3PercussionSoft = organB3PercussionSoft.getValue(layerId).value,
                b3PercussionFastDecay = organB3PercussionFastDecay.getValue(layerId).value,
                b3PercussionPolyMode = organB3PercussionPolyMode.getValue(layerId).value,
                vibratoChorusMode = organVibratoChorusMode.getValue(layerId).intValue,
                rotaryMode = rotaryMode,
                rotaryDrive = rotaryDrive,
                rotaryEnabled = rotaryEnabled,
                rotaryCloseMic = rotaryCloseMic,
                rotaryStopMode = rotaryStopMode,
                rotaryAngle = rotaryAngle
            )

            LayerId.PIANO_1,
            LayerId.PIANO_2 -> common.copy(
                pianoSoundModel = pianoSoundModels.getValue(layerId).value
            )
        }
    }

    return PerformanceSnapshot(
        name = name,
        selectedLayer = selectedLayer,
        masterVolume = audioOutput.masterVolume,
    organ1AuxEnabled = organ1AuxEnabled,
        organ2AuxEnabled = organ2AuxEnabled,
        rotaryMode = rotaryMode,
        rotaryDrive = rotaryDrive,
        rotaryEnabled = rotaryEnabled,
        rotaryCloseMic = rotaryCloseMic,
        rotaryStopMode = rotaryStopMode,
        rotaryAngle = rotaryAngle,
        layers = capturedLayers
    )
}


private fun restorePerformance(snapshot: PerformanceSnapshot) {
    organ1AuxEnabled = snapshot.organ1AuxEnabled
    organ2AuxEnabled = snapshot.organ2AuxEnabled
    rotaryMode = snapshot.rotaryMode.coerceIn(
        RotarySpeakerProcessor.STOP,
        RotarySpeakerProcessor.FAST
    )
    rotaryDrive = snapshot.rotaryDrive.coerceIn(0.0f, 1.0f)
    rotaryEnabled = snapshot.rotaryEnabled
    rotaryCloseMic = snapshot.rotaryCloseMic
    rotaryStopMode = snapshot.rotaryStopMode
    rotaryAngle = snapshot.rotaryAngle.coerceIn(0, 6)

    audioOutput.rotarySpeakerProcessor.mode = rotaryMode
    audioOutput.rotarySpeakerProcessor.drive = rotaryDrive
    audioOutput.rotarySpeakerProcessor.enabled = rotaryEnabled
    audioOutput.rotarySpeakerProcessor.closeMic = rotaryCloseMic
    audioOutput.rotarySpeakerProcessor.stopMode = rotaryStopMode
    audioOutput.rotarySpeakerProcessor.anglePosition = rotaryAngle
    val previousEnabled = LayerId.values().associateWith { layerId ->
        layerZones.getValue(layerId).enabled
    }

    for (layerId in LayerId.values()) {
        val saved = snapshot.layers[layerId] ?: PerformanceLayer()
        val zone = layerZones.getValue(layerId)

        zone.lowNote = saved.lowKey.coerceIn(0, 127)
        zone.highNote = saved.highKey.coerceIn(zone.lowNote, 127)
        layerOctaves.getValue(layerId).intValue = saved.octave.coerceIn(-4, 4)
        setLayerVolume(layerId, saved.volume)

        when (layerId) {
            LayerId.SYNTH_1,
            LayerId.SYNTH_2,
            LayerId.SYNTH_3 -> {
                val engine = when (layerId) {
                    LayerId.SYNTH_1 -> synth
                    LayerId.SYNTH_2 -> synth2
                    LayerId.SYNTH_3 -> synth3
                    else -> error("Unexpected synth layer")
                }

                engine.waveform = saved.waveform
                engine.attack = saved.attack
                engine.decay = saved.decay
                engine.sustain = saved.sustain
                engine.release = saved.release
                engine.oscillatorSettings = saved.oscillatorSettings
                engine.filterSettings = saved.filterSettings
                engine.modulationSettings = saved.modulationSettings

                synthOscillatorSettings.getValue(layerId).value =
                    saved.oscillatorSettings
                synthFilterSettings.getValue(layerId).value =
                    saved.filterSettings
                synthModulationSettings.getValue(layerId).value =
                    saved.modulationSettings
                engine.transposeSemitones = layerOctaves.getValue(layerId).intValue * 12
            }

            LayerId.ORGAN_1,
            LayerId.ORGAN_2 -> {
                val engine = if (layerId == LayerId.ORGAN_1) organ else organ2
                val registrations = organDrawbarSettings.getValue(layerId)

                for (model in OrganModel.values()) {
                    val fallback = registrations[model] ?: List(9) { 0 }
                    val source = saved.organDrawbars[model] ?: fallback
                    registrations[model] = List(9) { index ->
                        (source.getOrNull(index) ?: fallback.getOrElse(index) { 0 })
                            .coerceIn(0, 8)
                    }
                }

                organModelSettings.getValue(layerId).value = saved.organModel
                organVoxFilterMix.getValue(layerId).floatValue =
                    saved.organVoxFilterMix.coerceIn(0.0f, 1.0f)
                organB3PercussionEnabled.getValue(layerId).value =
                    saved.b3PercussionEnabled
                organB3PercussionHarmonic.getValue(layerId).value =
                    saved.b3PercussionHarmonic.coerceIn(2, 3)
                organB3PercussionSoft.getValue(layerId).value =
                    saved.b3PercussionSoft
                organB3PercussionFastDecay.getValue(layerId).value =
                    saved.b3PercussionFastDecay
                organB3PercussionPolyMode.getValue(layerId).value =
                    saved.b3PercussionPolyMode
                organVibratoChorusMode.getValue(layerId).intValue =
                    saved.vibratoChorusMode.coerceIn(0, 6)

                engine.organModel = saved.organModel
                engine.setDrawbars(
                    registrations.getValue(saved.organModel).toIntArray()
                )
                engine.voxFilterMix =
                    organVoxFilterMix.getValue(layerId).floatValue
                engine.b3PercussionEnabled = saved.b3PercussionEnabled
                engine.b3PercussionHarmonic = saved.b3PercussionHarmonic.coerceIn(2, 3)
                engine.b3PercussionSoft = saved.b3PercussionSoft
                engine.b3PercussionFastDecay = saved.b3PercussionFastDecay
                engine.b3PercussionPolyMode = saved.b3PercussionPolyMode
                engine.vibratoChorusMode =
                    organVibratoChorusMode.getValue(layerId).intValue
            }

            LayerId.PIANO_1,
            LayerId.PIANO_2 -> {
                pianoSoundModels.getValue(layerId).value =
                    saved.pianoSoundModel

                if (layerId == LayerId.PIANO_1) {
                    piano.soundModel = saved.pianoSoundModel
                } else {
                    piano2.soundModel = saved.pianoSoundModel
                }
            }
        }

        audioOutput.layerEffectsRackManager.update(
            layerId,
            saved.effects
        )
        layerReverbSettings.getValue(layerId).value =
            saved.effects.reverb
    }

    volume = snapshot.masterVolume.coerceIn(0.0f, 1.0f)
    audioOutput.masterVolume = volume

    for (layerId in LayerId.values()) {
        val shouldEnable = snapshot.layers[layerId]?.enabled ?: false
        if (previousEnabled.getValue(layerId) != shouldEnable) {
            setLayerEnabled(layerId, shouldEnable)
        }
    }

    selectLayer(snapshot.selectedLayer)
    performanceRecallRevision++
}


private fun selectLayer(layerId: LayerId) {
    selectedLayer = layerId
octave = layerOctaves.getValue(layerId).intValue
    selectedInstrument = layerId.instrument

    when (layerId) {
        LayerId.SYNTH_1,
        LayerId.SYNTH_2,
        LayerId.SYNTH_3 -> {
            val engine = when (layerId) {
                LayerId.SYNTH_1 -> synth
                LayerId.SYNTH_2 -> synth2
                LayerId.SYNTH_3 -> synth3
                else -> return
            }

engine.transposeSemitones = octave * 12
            waveform = engine.waveform
            synthOscillatorSettings.getValue(layerId).value =
                engine.oscillatorSettings
            synthFilterSettings.getValue(layerId).value =
                engine.filterSettings
            synthModulationSettings.getValue(layerId).value =
                engine.modulationSettings
            attack = engine.attack
            decay = engine.decay
            sustain = engine.sustain
            release = engine.release

            synthLayerVolume =
                layerVolumes.getValue(layerId).floatValue
        }

LayerId.ORGAN_1,
LayerId.ORGAN_2 -> {
    organModel =
        organModelSettings.getValue(layerId).value

    drawbars =
        organDrawbarSettings.getValue(layerId)
            .getValue(organModel)

val selectedVoxFilterMix =
    organVoxFilterMix.getValue(layerId).floatValue

val selectedPercussionEnabled =
    organB3PercussionEnabled.getValue(layerId).value
val selectedPercussionHarmonic =
    organB3PercussionHarmonic.getValue(layerId).value
val selectedPercussionSoft =
    organB3PercussionSoft.getValue(layerId).value
val selectedPercussionFastDecay =
    organB3PercussionFastDecay.getValue(layerId).value
val selectedPercussionPolyMode =
    organB3PercussionPolyMode.getValue(layerId).value
val selectedVibratoChorusMode =
    organVibratoChorusMode.getValue(layerId).intValue
val engine = if (layerId == LayerId.ORGAN_1) organ else organ2

engine.organModel = organModel
engine.voxFilterMix = selectedVoxFilterMix
engine.b3PercussionEnabled = selectedPercussionEnabled
engine.b3PercussionHarmonic = selectedPercussionHarmonic
engine.b3PercussionSoft = selectedPercussionSoft
engine.b3PercussionFastDecay = selectedPercussionFastDecay
engine.b3PercussionPolyMode = selectedPercussionPolyMode
engine.vibratoChorusMode = selectedVibratoChorusMode
            organLayerVolume =
                layerVolumes.getValue(layerId).floatValue
        }

        LayerId.PIANO_1,
        LayerId.PIANO_2 -> {
            pianoLayerVolume =
                layerVolumes.getValue(layerId).floatValue

            pianoSoundModel = pianoSoundModels.getValue(layerId).value

            when (layerId) {
                LayerId.PIANO_1 -> piano.soundModel = pianoSoundModel
                LayerId.PIANO_2 -> piano2.soundModel = pianoSoundModel
                else -> Unit
            }
        }
    }
}
private fun releaseAllNotes() {
    activeVoices.toList().forEach {
        releaseVoice(it)
    }

    activeVoices.clear()
    midiChannelStates.clear()
}

private fun releaseNotesFromDevice(deviceId: Int) {
    val sourcePrefix = "midi:$deviceId:"

    val matchingVoices = activeVoices.filter {
        it.source.startsWith(sourcePrefix)
    }

    matchingVoices.forEach {
        releaseVoice(it)
    }

    activeVoices.removeAll(matchingVoices.toSet())
    midiChannelStates.keys.removeAll { it.first == deviceId }
}

private fun switchInstrument(type: InstrumentType) {
    val firstLayer = when (type) {
        InstrumentType.SYNTH -> LayerId.SYNTH_1
        InstrumentType.ORGAN -> LayerId.ORGAN_1
        InstrumentType.PIANO -> LayerId.PIANO_1
    }

    selectLayer(firstLayer)
}

override fun onDestroy() {
    releaseAllNotes()
    midi?.stop()
    audioOutput.stop()
    piano.shutdown()
    piano2.shutdown()
    pianoSampleBank?.close()
    pianoSampleBank = null
    super.onDestroy()
}
}

@Composable
private fun StudioScreen(
    status: String,
    performanceLibrary: List<PerformanceSnapshot>,
    performanceName: String,
    selectedPerformanceName: String,
    performanceRecallRevision: Int,
    programSlots: List<String?>,
    selectedProgramSlot: Int,
    onProgramSlotRecall: (Int) -> Unit,
    onProgramSlotAssign: (Int, String) -> Boolean,
    onPerformanceNameChange: (String) -> Unit,
    onPerformanceSelect: (String) -> Unit,
    onPerformanceSave: () -> Unit,
    onPerformanceRecall: (String) -> Unit,
    onPerformanceRename: (String, String) -> Unit,
    onPerformanceDelete: (String) -> Unit,
    audioOutput: AudioOutputEngine,
    soloedLayer: LayerId?,
    onSoloedLayerChange: (LayerId?) -> Unit,
    organ1AuxEnabled: Boolean,
    organMidiSustainDown: Boolean,
    organMidiVolume: Int,
    organMidiExpression: Int,
    organMidiModulation: Int,
    organMidiPitchBend14: Int,
    organMidiReceived: Boolean,
    organ2AuxEnabled: Boolean,
    organ1MidiMonitor: OrganMidiMonitorState,
    organ2MidiMonitor: OrganMidiMonitorState,
    onOrgan1AuxEnabledChange: (Boolean) -> Unit,
    onOrgan2AuxEnabledChange: (Boolean) -> Unit,
    instrument: InstrumentType,
selectedLayer: LayerId,
    layerEnabledStates: Map<LayerId, Boolean>,
    layerVolumeValues: Map<LayerId, Float>,
    onLayerEnabledChangeFor: (LayerId, Boolean) -> Unit,
    onLayerVolumeChangeFor: (LayerId, Float) -> Unit,
layerEnabled: Boolean,
layerVolume: Float,
organ1LayerVolume: Float,
organ2LayerVolume: Float,
lowNote: Int,
highNote: Int,
onLayerSelect: (LayerId) -> Unit,
onLayerEnabledChange: (Boolean) -> Unit,
onLayerVolumeChange: (Float) -> Unit,
onOrgan1LayerVolumeChange: (Float) -> Unit,
onOrgan2LayerVolumeChange: (Float) -> Unit,
onLayerLowNoteChange: (Int) -> Unit,
onLayerHighNoteChange: (Int) -> Unit,
    drawbars: List<Int>,
    organModel: OrganModel,
    voxFilterMix: Float,
    onOrganModelChange: (OrganModel) -> Unit,
    onVoxFilterMixChange: (Float) -> Unit,
    b3PercussionEnabled: Boolean,
    b3PercussionHarmonic: Int,
    b3PercussionSoft: Boolean,
    b3PercussionFastDecay: Boolean,
    b3PercussionPolyMode: Boolean,
vibratoChorusMode: Int,
    rotaryMode: Int,
    rotaryDrive: Float,
    rotaryEnabled: Boolean,
    rotaryCloseMic: Boolean,
    rotaryStopMode: Boolean,
    rotaryAngle: Int,
    onB3PercussionEnabledChange: (Boolean) -> Unit,
    onB3PercussionHarmonicChange: (Int) -> Unit,
    onB3PercussionSoftChange: (Boolean) -> Unit,
    onB3PercussionFastDecayChange: (Boolean) -> Unit,
    onB3PercussionPolyModeChange: (Boolean) -> Unit,
onVibratoChorusModeChange: (Int) -> Unit,
    onRotaryModeChange: (Int) -> Unit,
    onRotaryDriveChange: (Float) -> Unit,
    onRotaryEnabledChange: (Boolean) -> Unit,
    onRotaryCloseMicChange: (Boolean) -> Unit,
    onRotaryStopModeChange: (Boolean) -> Unit,
    onRotaryAngleChange: (Int) -> Unit,
    waveform: Waveform,
    oscillatorSettings: SynthOscillatorSettings,
    filterSettings: SynthFilterSettings,
    modulationSettings: SynthModulationSettings,
    pianoSoundModel: PianoSoundModel,
    onPianoSoundModelChange: (PianoSoundModel) -> Unit,
    volume: Float,
synthLayerVolume: Float,
organLayerVolume: Float,
pianoLayerVolume: Float,
    octave: Int,
    attack: Float,
    decay: Float,
    sustain: Float,
    release: Float,
    onInstrumentChange: (InstrumentType) -> Unit,
    onDrawbarChange: (Int, Int) -> Unit,
    onWaveformChange: (Waveform) -> Unit,
    onOscillatorSettingsChange: (SynthOscillatorSettings) -> Unit,
    onFilterSettingsChange: (SynthFilterSettings) -> Unit,
    onModulationSettingsChange: (SynthModulationSettings) -> Unit,
    onVolumeChange: (Float) -> Unit,
onSynthLayerVolumeChange: (Float) -> Unit,
onOrganLayerVolumeChange: (Float) -> Unit,
onPianoLayerVolumeChange: (Float) -> Unit,
    onOctaveChange: (Int) -> Unit,
    onAttackChange: (Float) -> Unit,
    onDecayChange: (Float) -> Unit,
    onSustainChange: (Float) -> Unit,
    onReleaseChange: (Float) -> Unit,
    reverbSettings: ReverbSettings,
    onReverbSettingsChange: (ReverbSettings) -> Unit,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit
) {
    var diagnostics by remember {
        mutableStateOf(audioOutput.getDiagnostics())
    }

    var activeSection by remember {
        mutableStateOf(StudioSection.PROGRAM_ESSENTIALS)
    }
    val sectionScrollState = rememberScrollState()
    LaunchedEffect(activeSection) { sectionScrollState.scrollTo(0) }
    var shiftActive by remember { mutableStateOf(false) }
    var layerShiftActive by remember { mutableStateOf(false) }
    var heldLayerId by remember { mutableStateOf<LayerId?>(null) }
    fun handleLayerButtonPress(id: LayerId) {
        onLayerSelect(id)
        val group = LayerId.values().filter { it.instrument == id.instrument }
        if (layerShiftActive || (heldLayerId != null && heldLayerId != id)) {
            onLayerEnabledChangeFor(id, true)
        } else {
            group.forEach { onLayerEnabledChangeFor(it, it == id) }
        }
    }
    fun startLayerButtonHold(id: LayerId) {
        if (heldLayerId == null) heldLayerId = id
    }
    fun endLayerButtonHold(id: LayerId) {
        if (heldLayerId == id) heldLayerId = null
    }
    fun toggleInstrumentLayers(type: InstrumentType) {
        val group = LayerId.values().filter { it.instrument == type }
        val enable = group.any { layerEnabledStates[it] != true }
        group.forEach { onLayerEnabledChangeFor(it, enable) }
    }
    var programAssignMode by remember { mutableStateOf(false) }
    var pendingProgramOverwrite by remember { mutableIntStateOf(-1) }
    var programBankMessage by remember { mutableStateOf("") }

    LaunchedEffect(audioOutput) {
        while (true) {
            diagnostics = audioOutput.getDiagnostics()
            kotlinx.coroutines.delay(500)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101419))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF182431), RoundedCornerShape(9.dp))
                .border(1.dp, Color(0xFF344657), RoundedCornerShape(9.dp))
                .padding(5.dp)
                .border(1.dp, Color(0xFF71303A).copy(alpha = 0.55f), RoundedCornerShape(8.dp)),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            StudioSection.values().forEach { section ->
                val sectionLabel = when (section) {
                    StudioSection.PROGRAM_ESSENTIALS -> "PROGRAM"
                    StudioSection.PIANO -> "PIANO"
                    StudioSection.ORGAN -> "ORGAN"
                    StudioSection.SYNTH -> "SYNTH"
                    StudioSection.LAYER_EFFECTS -> "LAYER FX"
                }

                StageHardwareButton(
                    label = sectionLabel,
                    selected = activeSection == section,
                    modifier = Modifier.weight(1f),
                    compact = true,
                    onClick = {
                        activeSection = section
                        shiftActive = false
                        when (section) {
                            StudioSection.PIANO ->
                                onInstrumentChange(InstrumentType.PIANO)
                            StudioSection.ORGAN ->
                                onInstrumentChange(InstrumentType.ORGAN)
                            StudioSection.SYNTH ->
                                onInstrumentChange(InstrumentType.SYNTH)
                            else -> Unit
                        }
                    }
                )
            }
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .then(
                    if (activeSection == StudioSection.ORGAN) Modifier
                    else Modifier.verticalScroll(sectionScrollState)
                ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
        if (activeSection == StudioSection.PIANO || activeSection == StudioSection.SYNTH) {
            val pageInstrument = when (activeSection) {
                StudioSection.PIANO -> InstrumentType.PIANO
                StudioSection.ORGAN -> InstrumentType.ORGAN
                else -> InstrumentType.SYNTH
            }
            val pageLayers = LayerId.values().filter { it.instrument == pageInstrument }
            val sectionIsOn = pageLayers.any { layerEnabledStates[it] == true }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StageHardwareButton(label = "PROGRAM / HOME", selected = false, onClick = { activeSection = StudioSection.PROGRAM_ESSENTIALS }, modifier = Modifier.weight(1f), compact = true)
                StageHardwareButton(label = if (layerShiftActive) "LAYER SHIFT: ON" else "LAYER SHIFT", selected = layerShiftActive, onClick = { layerShiftActive = layerShiftActive.not() }, compact = true)
                StageHardwareButton(label = if (sectionIsOn) "SECTION ON" else "SECTION OFF", selected = sectionIsOn, onClick = { toggleInstrumentLayers(pageInstrument) }, compact = true)
            }
        }
        if (activeSection == StudioSection.PROGRAM_ESSENTIALS) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF6E1720),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.dp, Color(0xFFB45A5F).copy(alpha = 0.65f)
            )
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    "ISAAC STUDIO 4",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontSize = 22.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                        letterSpacing = 2.sp
                    )
                )
                Text(
                    "STAGE 4D  |  THREE-INSTRUMENT WORKSTATION",
                    color = Color(0xFFFFD6D6),
                    style = MaterialTheme.typography.labelMedium.copy(
                        letterSpacing = 1.2.sp
                    )
                )
                Text(
                    "PROGRAM ESSENTIALS",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium.copy(
                        letterSpacing = 1.8.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                    )
                )
                Text(
                    "LIVE PERFORMANCE  •  STAGE 4D",
                    color = Color(0xFFFFD6D6),
                    style = MaterialTheme.typography.labelSmall
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color(0xFF171B20),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            selectedPerformanceName.ifBlank { "UNSAVED PERFORMANCE" },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            color = Color(0xFFF4F6F8),
                            style = MaterialTheme.typography.titleMedium.copy(
                                letterSpacing = 0.8.sp,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                            )
                        )
                    }
                    Text(
                        instrument.name,
                        color = Color(0xFFFFD6D6),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }


        // ISAAC PROGRAM TWO-COLUMN WORKSPACE
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(
                modifier = Modifier.weight(1.2f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "PROGRAM BANK",
                color = Color(0xFFE0B66B),
                style = MaterialTheme.typography.labelMedium
            )
            Spacer(Modifier.weight(1f))
            StageHardwareButton(
                label = if (programAssignMode) "ASSIGN: ON" else "ASSIGN",
                selected = programAssignMode,
                onClick = {
                    programAssignMode = !programAssignMode
                    pendingProgramOverwrite = -1
                    programBankMessage = if (programAssignMode) {
                        "Choose a slot for the selected saved performance."
                    } else ""
                },
                enabled = selectedPerformanceName.isNotBlank()
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Top
        ) {
            (0 until 8).forEach { slot ->
                val assignedName = programSlots.getOrNull(slot)
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    StageHardwareButton(
                        label = "P${slot + 1}",
                        selected = selectedProgramSlot == slot,
                        onClick = {
                            if (programAssignMode) {
                                if (selectedPerformanceName.isBlank()) {
                                    programBankMessage = "Select a saved performance first."
                                } else if (assignedName.isNullOrBlank()) {
                                    programBankMessage = if (
                                        onProgramSlotAssign(slot, selectedPerformanceName)
                                    ) "Program ${slot + 1} assigned."
                                    else "Assignment failed. Check performance status."
                                } else if (
                                    assignedName.equals(selectedPerformanceName, ignoreCase = true)
                                ) {
                                    programBankMessage = "Already assigned to this program."
                                } else {
                                    pendingProgramOverwrite = slot
                                    programBankMessage = "Confirm replacement of Program ${slot + 1}."
                                }
                            } else {
                                onProgramSlotRecall(slot)
                                programBankMessage = if (assignedName.isNullOrBlank()) {
                                    "Program ${slot + 1} is empty."
                                } else {
                                    "Program ${slot + 1} recall requested."
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = assignedName?.takeIf { it.isNotBlank() } ?: "EMPTY",
                        color = if (assignedName.isNullOrBlank()) {
                            Color(0xFF737D89)
                        } else Color(0xFFB9C7D8),
                        fontSize = 8.sp,
                        maxLines = 1,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (pendingProgramOverwrite in 0..7) {
            val overwriteSlot = pendingProgramOverwrite
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF30251F),
                shape = RoundedCornerShape(6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "Replace Program ${overwriteSlot + 1} (${programSlots[overwriteSlot]}) with $selectedPerformanceName?",
                        color = Color(0xFFFFD6A0),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StageHardwareButton(
                            label = "CONFIRM REPLACE",
                            selected = true,
                            onClick = {
                                programBankMessage = if (
                                    onProgramSlotAssign(overwriteSlot, selectedPerformanceName)
                                ) "Program ${overwriteSlot + 1} replaced."
                                else "Replacement failed. Check performance status."
                                pendingProgramOverwrite = -1
                            },
                            modifier = Modifier.weight(1f)
                        )
                        StageHardwareButton(
                            label = "CANCEL",
                            selected = false,
                            onClick = {
                                pendingProgramOverwrite = -1
                                programBankMessage = "Replacement cancelled."
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (programBankMessage.isNotBlank()) {
            Text(
                programBankMessage,
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.labelSmall
            )
        }

        var performanceMenuExpanded by remember { mutableStateOf(false) }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF1B202B),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "PERFORMANCE MANAGER",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFFE0B66B)
                    )
                    Spacer(Modifier.weight(1f))
                    Button(onClick = { shiftActive = !shiftActive }) {
                        Text(if (shiftActive) "SHIFT: ON" else "SHIFT")
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = performanceName,
                        onValueChange = onPerformanceNameChange,
                        modifier = Modifier.weight(1f),
                        label = { Text("Performance name") },
                        singleLine = true
                    )

                    Box {
                        Button(onClick = {
                            performanceMenuExpanded = true
                        }) {
                            Text("SAVED")
                        }

                        DropdownMenu(
                            expanded = performanceMenuExpanded,
                            onDismissRequest = {
                                performanceMenuExpanded = false
                            }
                        ) {
                            if (performanceLibrary.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No saved performances") },
                                    onClick = {
                                        performanceMenuExpanded = false
                                    }
                                )
                            } else {
                                performanceLibrary.forEach { performance ->
                                    DropdownMenuItem(
                                        text = { Text(performance.name) },
                                        onClick = {
                                            onPerformanceSelect(performance.name)
                                            performanceMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                if (selectedPerformanceName.isNotBlank()) {
                    Text(
                        "Selected: $selectedPerformanceName",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF91A9FF)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!shiftActive) {
                        Button(
                            onClick = onPerformanceSave,
                            enabled = performanceName.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Text("SAVE") }
                        Button(
                            onClick = { onPerformanceRecall(selectedPerformanceName) },
                            enabled = selectedPerformanceName.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Text("LOAD") }
                    } else {
                        Button(
                            onClick = { onPerformanceRename(selectedPerformanceName, performanceName) },
                            enabled = selectedPerformanceName.isNotBlank() && performanceName.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Text("RENAME") }
                        Button(
                            onClick = { onPerformanceDelete(selectedPerformanceName) },
                            enabled = selectedPerformanceName.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Text("DELETE") }
                    }
                }
            }
        }

            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF1B202B),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    "PERFORMANCE STATUS",
                    color = Color(0xFFE0B66B),
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    status,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFB8C4D9)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "INSTRUMENT: ${instrument.name}",
                        color = Color(0xFF91A9FF),
                        style = MaterialTheme.typography.labelSmall
                    )
                    Text(
                        selectedPerformanceName.ifBlank { "UNSAVED" },
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
Surface(
    modifier = Modifier.fillMaxWidth(),
    color = Color(0xFF252D3B),
    shape = RoundedCornerShape(10.dp)
) {
    Column(
        modifier = Modifier.padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "INSTRUMENT SELECT",
                color = Color(0xFFE0B66B),
                style = MaterialTheme.typography.labelMedium
            )
            Spacer(Modifier.weight(1f))
            Text(
                "ACTIVE: ${instrument.name}",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.labelSmall
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onInstrumentChange(InstrumentType.SYNTH) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.SYNTH) "✓ SYNTH" else "SYNTH")
            }
            Button(
                onClick = { onInstrumentChange(InstrumentType.ORGAN) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.ORGAN) "✓ ORGAN" else "ORGAN")
            }
            Button(
                onClick = { onInstrumentChange(InstrumentType.PIANO) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.PIANO) "✓ PIANO" else "PIANO")
            }
        }
    }
}


        Surface(
    modifier = Modifier.fillMaxWidth(),
    color = Color(0xFF1B202B),
    shape = RoundedCornerShape(10.dp)
) {
    Column(
        modifier = Modifier.padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "AUDIO DIAGNOSTICS",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleSmall.copy(
                    letterSpacing = 1.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                )
            )
            val audioHealthy =
                diagnostics.underrunCount == 0 &&
                diagnostics.maximumBlockTimeUs < 11610
            StageStatusLed(
                label = if (audioHealthy) "AUDIO HEALTHY" else "AUDIO WARNING",
                active = audioHealthy,
                warning = !audioHealthy
            )
        }

        diagnostics.renderers.forEach { renderer ->
            Text(
                "${renderer.name}: AVG ${renderer.averageTimeUs} µs | MAX ${renderer.maximumTimeUs} µs",
                color = Color.White,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Text(
            "TOTAL RENDER: ${diagnostics.totalRenderTimeUs} µs",
            color = Color.White
        )

        Text(
            "MAX BLOCK: ${diagnostics.maximumBlockTimeUs} µs / 11,610 µs",
            color = Color.White
        )

        Text(
            "AUDIOTRACK UNDERRUNS: ${diagnostics.underrunCount}",
            color = Color.White
        )
    }
}

            }
        }
        Spacer(Modifier.height(6.dp))

        }
        if (activeSection == StudioSection.LAYER_EFFECTS) {
            StageHardwarePanel(accent = Color(0xFF91A9FF)) {
        Text("INSTRUMENT SELECTOR", color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { onInstrumentChange(InstrumentType.SYNTH) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.SYNTH) "✓ SYNTH" else "SYNTH")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.ORGAN) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.ORGAN) "✓ ORGAN" else "ORGAN")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.PIANO) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.PIANO) "✓ PIANO" else "PIANO")
            }
        }
        // SEVEN-LAYER CONTROL PANEL

        Text(
            "LAYER CONTROL",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LayerId.values()
                .filter { it.instrument == instrument }
                .forEach { layer ->
                    Button(
                        onClick = { onLayerSelect(layer) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            if (selectedLayer == layer) {
                                "✓ ${layer.displayName}"
                            } else {
                                layer.displayName
                            }
                        )
                    }
                }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                selectedLayer.displayName,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall
            )

            StageHardwareButton(
                label = if (layerEnabled) "LAYER: ON" else "LAYER: OFF",
                selected = layerEnabled,
                onClick = { onLayerEnabledChange(!layerEnabled) }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "LAYER VOLUME • ${(layerVolume * 100).toInt()}%",
                color = Color.White
            )
            StageFader(
                value = layerVolume,
                onValueChange = onLayerVolumeChange,
                valueRange = 0f..1f
            )
        }

        Text(
            "LOW KEY • $lowNote",
            color = Color.White
        )

        Slider(
            value = lowNote.toFloat(),
            onValueChange = {
                onLayerLowNoteChange(it.toInt())
            },
            valueRange = 0f..127f,
            steps = 126
        )

        Text(
            "HIGH KEY • $highNote",
            color = Color.White
        )

        Slider(
            value = highNote.toFloat(),
            onValueChange = {
                onLayerHighNoteChange(it.toInt())
            },
            valueRange = 0f..127f,
            steps = 126
        )

        Text(
            "KEYBOARD ZONE: $lowNote – $highNote",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.bodySmall
        )
            }
        }
        if (activeSection == StudioSection.LAYER_EFFECTS) {
            StageHardwarePanel(accent = Color(0xFFB58CFF)) {
        Text(
            "LAYER EFFECTS",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium.copy(
                fontSize = 16.sp,
                letterSpacing = 2.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
            )
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
        var mod1Settings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).mod1
            )
        }

        Modulation1Panel(
            settings = mod1Settings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                mod1Settings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(mod1 = updated))
            }
        )


        var mod2Settings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).mod2
            )
        }

        Modulation2Panel(
            settings = mod2Settings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                mod2Settings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(mod2 = updated))
            }
        )

        var delaySettings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).delay
            )
        }

        DelayPanel(
            settings = delaySettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                delaySettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(delay = updated))
            }
        )

            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
        var ampEqSettings by remember(
            if (selectedLayer == LayerId.ORGAN_1 ||
                selectedLayer == LayerId.ORGAN_2
            ) LayerId.ORGAN_1 else selectedLayer,
            performanceRecallRevision
        ) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).ampEq
            )
        }

        AmpEqPanel(
            settings = ampEqSettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                ampEqSettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(ampEq = updated))
            }
        )

        
        var tubeOverdriveSettings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).tubeOverdrive
            )
        }

        TubeOverdrivePanel(
            settings = tubeOverdriveSettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                tubeOverdriveSettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(tubeOverdrive = updated))
            }
        )

        var compressorSettings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).compressor
            )
        }

        CompressorPanel(
            settings = compressorSettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                compressorSettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(compressor = updated))
            }
        )

        Spacer(Modifier.height(8.dp))

        var reverbMenuExpanded by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(false)
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFF53658D), RoundedCornerShape(10.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                "LAYER REVERB • ${selectedLayer.displayName}",
                color = Color.White
            )

            Button(
                onClick = {
                    onReverbSettingsChange(
                        reverbSettings.copy(enabled = !reverbSettings.enabled)
                    )
                }
            ) {
                Text(
                    if (reverbSettings.enabled) "REVERB: ON"
                    else "REVERB: OFF"
                )
            }

            Box {
                Button(
                    onClick = { reverbMenuExpanded = true }
                ) {
                    Text("ALGORITHM: ${reverbSettings.type.name.replace('_', ' ')}")
                }

                DropdownMenu(
                    expanded = reverbMenuExpanded,
                    onDismissRequest = { reverbMenuExpanded = false }
                ) {
                    ReverbType.values().forEach { type ->
                        DropdownMenuItem(
                            text = {
                                Text(type.name.replace('_', ' '))
                            },
                            onClick = {
                                onReverbSettingsChange(
                                    reverbSettings.copy(type = type)
                                )
                                reverbMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Text(
                "ROOM SIZE • ${(reverbSettings.roomSize * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = reverbSettings.roomSize,
                onValueChange = {
                    onReverbSettingsChange(
                        reverbSettings.copy(roomSize = it)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "WET MIX • ${(reverbSettings.wetMix * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = reverbSettings.wetMix,
                onValueChange = {
                    onReverbSettingsChange(
                        reverbSettings.copy(wetMix = it)
                    )
                },
                valueRange = 0f..1f
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        onReverbSettingsChange(
                            reverbSettings.copy(bright = !reverbSettings.bright)
                        )
                    }
                ) {
                    Text(if (reverbSettings.bright) "BRIGHT: ON" else "BRIGHT: OFF")
                }

                Button(
                    onClick = {
                        onReverbSettingsChange(
                            reverbSettings.copy(chorale = !reverbSettings.chorale)
                        )
                    }
                ) {
                    Text(if (reverbSettings.chorale) "CHORALE: ON" else "CHORALE: OFF")
                }
            }
        }
            }
            }
        }
    }

if (activeSection != StudioSection.ORGAN) {
Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
) {
    Text(
        "MASTER VOLUME: ${(volume * 100).toInt()}%",
        color = Color.White
    )
    StageFader(
        value = volume,
        onValueChange = onVolumeChange,
        valueRange = 0f..1f
    )
}
}
        if (activeSection == StudioSection.SYNTH && instrument == InstrumentType.SYNTH) {
    StageHardwarePanel(accent = Color(0xFF79B8FF)) {
            Text(
                "SYNTHESIZER",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 16.sp,
                    letterSpacing = 2.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StageLayerSelectButton(label = "SYNTH 1", selected = selectedLayer == LayerId.SYNTH_1, onClick = { handleLayerButtonPress(LayerId.SYNTH_1) }, onHoldStart = { startLayerButtonHold(LayerId.SYNTH_1) }, onHoldEnd = { endLayerButtonHold(LayerId.SYNTH_1) }, modifier = Modifier.weight(1f))
                StageLayerSelectButton(label = "SYNTH 2", selected = selectedLayer == LayerId.SYNTH_2, onClick = { handleLayerButtonPress(LayerId.SYNTH_2) }, onHoldStart = { startLayerButtonHold(LayerId.SYNTH_2) }, onHoldEnd = { endLayerButtonHold(LayerId.SYNTH_2) }, modifier = Modifier.weight(1f))
                StageLayerSelectButton(label = "SYNTH 3", selected = selectedLayer == LayerId.SYNTH_3, onClick = { handleLayerButtonPress(LayerId.SYNTH_3) }, onHoldStart = { startLayerButtonHold(LayerId.SYNTH_3) }, onHoldEnd = { endLayerButtonHold(LayerId.SYNTH_3) }, modifier = Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("SYNTH 1: ${((layerVolumeValues[LayerId.SYNTH_1] ?: 1f) * 100).toInt()}%", color = Color.White)
                    Slider(value = layerVolumeValues[LayerId.SYNTH_1] ?: 1f, onValueChange = { onLayerVolumeChangeFor(LayerId.SYNTH_1, it) }, valueRange = 0f..1f)
                    StageHardwareButton(label = if (layerEnabledStates[LayerId.SYNTH_1] == true) "LAYER 1 ON" else "LAYER 1 OFF", selected = layerEnabledStates[LayerId.SYNTH_1] == true, onClick = { onLayerEnabledChangeFor(LayerId.SYNTH_1, (layerEnabledStates[LayerId.SYNTH_1] ?: false).not()) }, modifier = Modifier.fillMaxWidth(), compact = true)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("SYNTH 2: ${((layerVolumeValues[LayerId.SYNTH_2] ?: 1f) * 100).toInt()}%", color = Color.White)
                    Slider(value = layerVolumeValues[LayerId.SYNTH_2] ?: 1f, onValueChange = { onLayerVolumeChangeFor(LayerId.SYNTH_2, it) }, valueRange = 0f..1f)
                    StageHardwareButton(label = if (layerEnabledStates[LayerId.SYNTH_2] == true) "LAYER 2 ON" else "LAYER 2 OFF", selected = layerEnabledStates[LayerId.SYNTH_2] == true, onClick = { onLayerEnabledChangeFor(LayerId.SYNTH_2, (layerEnabledStates[LayerId.SYNTH_2] ?: false).not()) }, modifier = Modifier.fillMaxWidth(), compact = true)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("SYNTH 3: ${((layerVolumeValues[LayerId.SYNTH_3] ?: 1f) * 100).toInt()}%", color = Color.White)
                    Slider(value = layerVolumeValues[LayerId.SYNTH_3] ?: 1f, onValueChange = { onLayerVolumeChangeFor(LayerId.SYNTH_3, it) }, valueRange = 0f..1f)
                    StageHardwareButton(label = if (layerEnabledStates[LayerId.SYNTH_3] == true) "LAYER 3 ON" else "LAYER 3 OFF", selected = layerEnabledStates[LayerId.SYNTH_3] == true, onClick = { onLayerEnabledChangeFor(LayerId.SYNTH_3, (layerEnabledStates[LayerId.SYNTH_3] ?: false).not()) }, modifier = Modifier.fillMaxWidth(), compact = true)
                }
            }

            Text("WAVEFORM", color = Color.White)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Waveform.values().forEach { type ->
                    Button(
                        onClick = { onWaveformChange(type) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (waveform == type) {
                                "✓ " + type.name.take(3)
                            } else {
                                type.name.take(3)
                            },
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            Text(
                "DUAL OSCILLATOR",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

            Button(
                onClick = {
                    onOscillatorSettingsChange(
                        oscillatorSettings.copy(enabled = !oscillatorSettings.enabled)
                    )
                }
            ) {
                Text(
                    if (oscillatorSettings.enabled) "DUAL OSCILLATOR: ON"
                    else "DUAL OSCILLATOR: OFF"
                )
            }

            if (oscillatorSettings.enabled) {
                var oscillatorACategoryMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorADigitalMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorBCategoryMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorATypeMenuExpanded by remember { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { oscillatorATypeMenuExpanded = true }) {
                        Text("A TYPE: " + oscillatorSettings.oscillatorA.oscillatorType.name.replace('_', ' '))
                    }
                    DropdownMenu(
                        expanded = oscillatorATypeMenuExpanded,
                        onDismissRequest = { oscillatorATypeMenuExpanded = false }
                    ) {
                        listOf(
                            SynthOscillatorType.ANALOG,
                            SynthOscillatorType.FM_HARMONIC,
                            SynthOscillatorType.FM_INHARMONIC,
                            SynthOscillatorType.DIGITAL_WAVE
                        ).forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.name.replace('_', ' ')) },
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                oscillatorType = type
                                            )
                                        )
                                    )
                                    oscillatorATypeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("OSCILLATOR A", color = Color.White)

                if (oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.ANALOG) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Waveform.values().forEach { type ->
                            Button(
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                waveform = type
                                            )
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    if (oscillatorSettings.oscillatorA.waveform == type)
                                        "✓ " + type.name.take(3)
                                    else type.name.take(3),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { oscillatorACategoryMenuExpanded = true }
                        ) {
                            Text(
                                "A MODE: " +
                                    oscillatorSettings.oscillatorA.analogCategory.name
                                        .replace('_', ' ')
                            )
                        }

                        DropdownMenu(
                            expanded = oscillatorACategoryMenuExpanded,
                            onDismissRequest = {
                                oscillatorACategoryMenuExpanded = false
                            }
                        ) {
                            SynthAnalogCategory.values().forEach { category ->
                                DropdownMenuItem(
                                    text = {
                                        Text(category.name.replace('_', ' '))
                                    },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                    analogCategory = category
                                                )
                                            )
                                        )
                                        oscillatorACategoryMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    if (oscillatorSettings.oscillatorA.analogCategory != SynthAnalogCategory.PURE) {
                        Text(
                            "A OSC CTRL • ${(oscillatorSettings.oscillatorA.oscillatorControl * 100).toInt()}%",
                            color = Color.White
                        )
                        Slider(
                            value = oscillatorSettings.oscillatorA.oscillatorControl,
                            onValueChange = { value ->
                                onOscillatorSettingsChange(
                                    oscillatorSettings.copy(
                                        oscillatorA = oscillatorSettings.oscillatorA.copy(
                                            oscillatorControl = value
                                        )
                                    )
                                )
                            },
                            valueRange = 0f..1f
                        )
                    }
                }

                if (oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.FM_HARMONIC ||
                    oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.FM_INHARMONIC) {
                    val fmTypeA = oscillatorSettings.oscillatorA.oscillatorType
                    val harmonicA = fmTypeA == SynthOscillatorType.FM_HARMONIC
                    val ratioA = oscillatorSettings.oscillatorA.fmRatio
                        .coerceIn(if (harmonicA) 1f else 0.1f, 16f)

                    Text(
                        "A FM AMOUNT • ${(oscillatorSettings.oscillatorA.fmAmount * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorA.fmAmount.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorA = oscillatorSettings.oscillatorA.copy(
                                        fmAmount = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )

                    Text(
                        "A FM RATIO • ${if (harmonicA) ratioA.toInt().toString() else "%.1f".format(ratioA)}",
                        color = Color.White
                    )
                    Slider(
                        value = ratioA,
                        onValueChange = { value ->
                            val selectedRatio = if (harmonicA)
                                (value + 0.5f).toInt().toFloat()
                            else value
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorA = oscillatorSettings.oscillatorA.copy(
                                        fmRatio = selectedRatio
                                    )
                                )
                            )
                        },
                        valueRange = if (harmonicA) 1f..16f else 0.1f..16f,
                        steps = if (harmonicA) 14 else 0
                    )
                }

                if (oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.DIGITAL_WAVE) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { oscillatorADigitalMenuExpanded = true }) {
                            Text("A DIGITAL: " + oscillatorSettings.oscillatorA.digitalWave.name)
                        }
                        DropdownMenu(
                            expanded = oscillatorADigitalMenuExpanded,
                            onDismissRequest = { oscillatorADigitalMenuExpanded = false }
                        ) {
                            SynthDigitalWave.values().forEach { wave ->
                                DropdownMenuItem(
                                    text = { Text(wave.name) },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                    digitalWave = wave
                                                )
                                            )
                                        )
                                        oscillatorADigitalMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Text(
                        "A DIGITAL MORPH • ${(oscillatorSettings.oscillatorA.digitalMorph * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorA.digitalMorph.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorA = oscillatorSettings.oscillatorA.copy(
                                        digitalMorph = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )
                }

                Text(
                    "A SEMITONE • ${oscillatorSettings.oscillatorA.semitone}",
                    color = Color.White
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorA.semitone - 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("−") }

                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorA.semitone + 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("+") }
                }

                Text(
                    "A FINE TUNE • ${oscillatorSettings.oscillatorA.fineTune.toInt()} cents",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorA.fineTune,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    fineTune = value
                                )
                            )
                        )
                    },
                    valueRange = -100f..100f
                )

                Text(
                    "A LEVEL • ${(oscillatorSettings.oscillatorA.level * 100).toInt()}%",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorA.level,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    level = value
                                )
                            )
                        )
                    },
                    valueRange = 0f..1f
                )

                var oscillatorBTypeMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorBDigitalMenuExpanded by remember { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { oscillatorBTypeMenuExpanded = true }) {
                        Text("B TYPE: " + oscillatorSettings.oscillatorB.oscillatorType.name.replace('_', ' '))
                    }
                    DropdownMenu(
                        expanded = oscillatorBTypeMenuExpanded,
                        onDismissRequest = { oscillatorBTypeMenuExpanded = false }
                    ) {
                        listOf(
                            SynthOscillatorType.ANALOG,
                            SynthOscillatorType.FM_HARMONIC,
                            SynthOscillatorType.FM_INHARMONIC,
                            SynthOscillatorType.DIGITAL_WAVE
                        ).forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.name.replace('_', ' ')) },
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                oscillatorType = type
                                            )
                                        )
                                    )
                                    oscillatorBTypeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("OSCILLATOR B", color = Color.White)

                if (oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.ANALOG) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { oscillatorBCategoryMenuExpanded = true }
                        ) {
                            Text(
                                "B MODE: " +
                                    oscillatorSettings.oscillatorB.analogCategory.name
                                        .replace('_', ' ')
                            )
                        }

                        DropdownMenu(
                            expanded = oscillatorBCategoryMenuExpanded,
                            onDismissRequest = {
                                oscillatorBCategoryMenuExpanded = false
                            }
                        ) {
                            SynthAnalogCategory.values().forEach { category ->
                                DropdownMenuItem(
                                    text = {
                                        Text(category.name.replace('_', ' '))
                                    },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                    analogCategory = category
                                                )
                                            )
                                        )
                                        oscillatorBCategoryMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    if (oscillatorSettings.oscillatorB.analogCategory != SynthAnalogCategory.PURE) {
                        Text(
                            "B OSC CTRL • ${(oscillatorSettings.oscillatorB.oscillatorControl * 100).toInt()}%",
                            color = Color.White
                        )
                        Slider(
                            value = oscillatorSettings.oscillatorB.oscillatorControl,
                            onValueChange = { value ->
                                onOscillatorSettingsChange(
                                    oscillatorSettings.copy(
                                        oscillatorB = oscillatorSettings.oscillatorB.copy(
                                            oscillatorControl = value
                                        )
                                    )
                                )
                            },
                            valueRange = 0f..1f
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Waveform.values().forEach { type ->
                            Button(
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                waveform = type
                                            )
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    if (oscillatorSettings.oscillatorB.waveform == type)
                                        "✓ " + type.name.take(3)
                                    else type.name.take(3),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }

                if (oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.FM_HARMONIC ||
                    oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.FM_INHARMONIC) {
                    val fmTypeB = oscillatorSettings.oscillatorB.oscillatorType
                    val harmonicB = fmTypeB == SynthOscillatorType.FM_HARMONIC
                    val ratioB = oscillatorSettings.oscillatorB.fmRatio
                        .coerceIn(if (harmonicB) 1f else 0.1f, 16f)

                    Text(
                        "B FM AMOUNT • ${(oscillatorSettings.oscillatorB.fmAmount * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorB.fmAmount.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorB = oscillatorSettings.oscillatorB.copy(
                                        fmAmount = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )

                    Text(
                        "B FM RATIO • ${if (harmonicB) ratioB.toInt().toString() else "%.1f".format(ratioB)}",
                        color = Color.White
                    )
                    Slider(
                        value = ratioB,
                        onValueChange = { value ->
                            val selectedRatio = if (harmonicB)
                                (value + 0.5f).toInt().toFloat()
                            else value
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorB = oscillatorSettings.oscillatorB.copy(
                                        fmRatio = selectedRatio
                                    )
                                )
                            )
                        },
                        valueRange = if (harmonicB) 1f..16f else 0.1f..16f,
                        steps = if (harmonicB) 14 else 0
                    )
                }

                if (oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.DIGITAL_WAVE) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { oscillatorBDigitalMenuExpanded = true }) {
                            Text("B DIGITAL: " + oscillatorSettings.oscillatorB.digitalWave.name)
                        }
                        DropdownMenu(
                            expanded = oscillatorBDigitalMenuExpanded,
                            onDismissRequest = { oscillatorBDigitalMenuExpanded = false }
                        ) {
                            SynthDigitalWave.values().forEach { wave ->
                                DropdownMenuItem(
                                    text = { Text(wave.name) },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                    digitalWave = wave
                                                )
                                            )
                                        )
                                        oscillatorBDigitalMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Text(
                        "B DIGITAL MORPH • ${(oscillatorSettings.oscillatorB.digitalMorph * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorB.digitalMorph.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorB = oscillatorSettings.oscillatorB.copy(
                                        digitalMorph = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )
                }

                Text(
                    "B SEMITONE • ${oscillatorSettings.oscillatorB.semitone}",
                    color = Color.White
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorB.semitone - 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("−") }

                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorB.semitone + 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("+") }
                }

                Text(
                    "B FINE TUNE • ${oscillatorSettings.oscillatorB.fineTune.toInt()} cents",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorB.fineTune,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    fineTune = value
                                )
                            )
                        )
                    },
                    valueRange = -100f..100f
                )

                Text(
                    "B LEVEL • ${(oscillatorSettings.oscillatorB.level * 100).toInt()}%",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorB.level,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    level = value
                                )
                            )
                        )
                    },
                    valueRange = 0f..1f
                )

                Text(
                    "OSCILLATOR MIX • ${(oscillatorSettings.oscillatorMix * 100).toInt()}%",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorMix,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(oscillatorMix = value)
                        )
                    },
                    valueRange = 0f..1f
                )
            }

            Text(
                "FILTER • ADVANCED SYNTH FILTER",
                color = Color.White
            )

            var filterModeMenuExpanded by remember {
                mutableStateOf(false)
            }

            Button(
                onClick = { filterModeMenuExpanded = true }
            ) {
                Text("MODE • ${filterSettings.mode.name.replace('_', ' ')}")
            }

            DropdownMenu(
                expanded = filterModeMenuExpanded,
                onDismissRequest = { filterModeMenuExpanded = false }
            ) {
                SynthFilterMode.values().forEach { mode ->
                    DropdownMenuItem(
                        text = {
                            Text(mode.name.replace('_', ' '))
                        },
                        onClick = {
                            onFilterSettingsChange(
                                filterSettings.copy(mode = mode)
                            )
                            filterModeMenuExpanded = false
                        }
                    )
                }
            }

            val cutoffLabel = if (filterSettings.cutoffHz >= 1000f) {
                "${(filterSettings.cutoffHz / 100f).toInt() / 10f} kHz"
            } else {
                "${filterSettings.cutoffHz.toInt()} Hz"
            }

            Text(
                "CUTOFF • $cutoffLabel",
                color = Color.White
            )

            Slider(
                value = (
                    kotlin.math.ln(
                        filterSettings.cutoffHz.coerceIn(20f, 20000f) / 20f
                    ) / kotlin.math.ln(1000f)
                ).coerceIn(0f, 1f),
                onValueChange = { value ->
                    val cutoff = 20f * kotlin.math.exp(
                        kotlin.math.ln(1000f) * value
                    )
                    onFilterSettingsChange(
                        filterSettings.copy(cutoffHz = cutoff)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "RESONANCE • ${(filterSettings.resonance * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = filterSettings.resonance,
                onValueChange = { value ->
                    onFilterSettingsChange(
                        filterSettings.copy(resonance = value)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "DRIVE • ${(filterSettings.drive * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = filterSettings.drive,
                onValueChange = { value ->
                    onFilterSettingsChange(
                        filterSettings.copy(drive = value)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "FILTER ENVELOPE • INDEPENDENT ADSR",
                color = Color(0xFF91A9FF)
            )

            EnvelopeControl(
                "FILTER ATTACK",
                "${(modulationSettings.filterAttack * 1000).toInt()} ms",
                modulationSettings.filterAttack,
                0.001f..2f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterAttack = value)
                )
            }

            EnvelopeControl(
                "FILTER DECAY",
                "${(modulationSettings.filterDecay * 1000).toInt()} ms",
                modulationSettings.filterDecay,
                0.001f..2f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterDecay = value)
                )
            }

            EnvelopeControl(
                "FILTER SUSTAIN",
                "${(modulationSettings.filterSustain * 100).toInt()}%",
                modulationSettings.filterSustain,
                0f..1f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterSustain = value)
                )
            }

            EnvelopeControl(
                "FILTER RELEASE",
                "${(modulationSettings.filterRelease * 1000).toInt()} ms",
                modulationSettings.filterRelease,
                0.01f..3f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterRelease = value)
                )
            }

            Text(
                "FILTER & VELOCITY MODULATION",
                color = Color(0xFF91A9FF)
            )

            EnvelopeControl(
                "FILTER ENVELOPE AMOUNT",
                "${if (modulationSettings.filterEnvelopeAmountOctaves >= 0f) "+" else ""}${"%.1f".format(modulationSettings.filterEnvelopeAmountOctaves)} oct",
                modulationSettings.filterEnvelopeAmountOctaves,
                -4f..4f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterEnvelopeAmountOctaves = value)
                )
            }

            EnvelopeControl(
                "VELOCITY TO VOLUME",
                "${(modulationSettings.velocityToVolume * 100).toInt()}%",
                modulationSettings.velocityToVolume,
                0f..1f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(velocityToVolume = value)
                )
            }

            EnvelopeControl(
                "VELOCITY TO FILTER",
                "${if (modulationSettings.velocityToFilterOctaves >= 0f) "+" else ""}${"%.1f".format(modulationSettings.velocityToFilterOctaves)} oct",
                modulationSettings.velocityToFilterOctaves,
                -4f..4f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(velocityToFilterOctaves = value)
                )
            }

            EnvelopeControl(
                "ATTACK",
                "${(attack * 1000).toInt()} ms",
                attack,
                0.001f..2f,
                onAttackChange
            )

            EnvelopeControl(
                "DECAY",
                "${(decay * 1000).toInt()} ms",
                decay,
                0.001f..2f,
                onDecayChange
            )

            EnvelopeControl(
                "SUSTAIN",
                "${(sustain * 100).toInt()}%",
                sustain,
                0f..1f,
                onSustainChange
            )

            EnvelopeControl(
                "RELEASE",
                "${(release * 1000).toInt()} ms",
                release,
                0.01f..3f,
                onReleaseChange
            )
        
    }}

        if (activeSection == StudioSection.ORGAN && instrument == InstrumentType.ORGAN) {
    OrganFitPanel(modifier = Modifier.fillMaxWidth().weight(1f)) {
    OrganHardwarePanel {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color(0xFF9B1720), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFFE1E5EA), RoundedCornerShape(8.dp))
                    .padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text("MASTER LEVEL", color = Color.White, fontSize = 10.sp)
                StageRotary(
                    label = "VOLUME",
                    value = volume,
                    onValueChange = onVolumeChange,
                    valueRange = 0f..1f
                )
Column(
    modifier = Modifier
        .fillMaxWidth()
        .background(Color(0xFF8A2028), RoundedCornerShape(5.dp))
        .border(1.dp, Color(0xFFE1E5EA), RoundedCornerShape(5.dp))
        .padding(6.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(5.dp)
) {
Text(
    "ROTARY SPEAKER",
    color = Color.White,
    style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        letterSpacing = 0.5.sp
    )
)
StageRotary(
    label = "DRIVE",
    value = rotaryDrive * 10f,
    onValueChange = { onRotaryDriveChange(it / 10f) },
    valueRange = 0f..10f
)
StageHardwareButton(
    label = "ORGAN",
    selected = rotaryEnabled,
    onClick = { onRotaryEnabledChange(!rotaryEnabled) },
    modifier = Modifier.fillMaxWidth(),
    compact = true
)
var rotaryMicMenuExpanded by remember { mutableStateOf(false) }
Button(
    onClick = { rotaryMicMenuExpanded = true },
    modifier = Modifier.fillMaxWidth(),
    contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
) {
    Text(
        if (rotaryCloseMic) "CLOSE MIC" else "NORMAL MIC",
        fontSize = 9.sp
    )
}
DropdownMenu(
    expanded = rotaryMicMenuExpanded,
    onDismissRequest = { rotaryMicMenuExpanded = false }
) {
    listOf(false to "NORMAL MIC", true to "CLOSE MIC").forEach { (close, label) ->
        DropdownMenuItem(
            text = { Text(label) },
            onClick = {
                onRotaryCloseMicChange(close)
                rotaryMicMenuExpanded = false
            }
        )
    }
}
StageHardwareButton(
    label = "STOP MODE",
    selected = rotaryStopMode,
    onClick = { onRotaryStopModeChange(!rotaryStopMode) },
    modifier = Modifier.fillMaxWidth(),
    compact = true
)
var rotaryAngleMenuExpanded by remember { mutableStateOf(false) }
Text("ANGLE", color = Color.White, fontSize = 9.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
Button(
    onClick = { rotaryAngleMenuExpanded = true },
    modifier = Modifier.fillMaxWidth(),
    contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
) {
    Text(
        listOf("FREE", "FRONT CENTRE", "FRONT LEFT", "FRONT RIGHT",
            "BACK CENTRE", "BACK LEFT", "BACK RIGHT")[rotaryAngle.coerceIn(0, 6)],
        fontSize = 9.sp
    )
}
DropdownMenu(
    expanded = rotaryAngleMenuExpanded,
    onDismissRequest = { rotaryAngleMenuExpanded = false }
) {
    listOf("FREE", "FRONT CENTRE", "FRONT LEFT", "FRONT RIGHT",
        "BACK CENTRE", "BACK LEFT", "BACK RIGHT").forEachIndexed { index, label ->
        DropdownMenuItem(
            text = { Text(label) },
            onClick = {
                onRotaryAngleChange(index)
                rotaryAngleMenuExpanded = false
            }
        )
    }
}
Text("SPEED", color = Color.White, fontSize = 9.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(3.dp)
) {
    listOf(
        RotarySpeakerProcessor.SLOW to "SLOW",
        RotarySpeakerProcessor.FAST to "FAST"
    ).forEach { (mode, label) ->
        StageHardwareButton(
            label = label,
            selected = rotaryMode == mode,
            onClick = { onRotaryModeChange(mode) },
            modifier = Modifier.weight(1f),
            compact = true
        )
    }
}
    StageHardwareButton(
        label = "MORPH",
        selected = false,
        onClick = {},
        modifier = Modifier.fillMaxWidth(),
        enabled = false,
        compact = true
    )
}
            }
            Column(
                modifier = Modifier.weight(5.7f).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
            val organSectionIsOn = listOf(LayerId.ORGAN_1, LayerId.ORGAN_2)
                .any { layerEnabledStates[it] == true }
            val organSoloTarget = if (selectedLayer == LayerId.ORGAN_2) LayerId.ORGAN_2 else LayerId.ORGAN_1
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFD8DDE3), RoundedCornerShape(5.dp))
                    .border(1.dp, Color(0xFFF4F6F8), RoundedCornerShape(5.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "ORGAN",
                        color = Color(0xFF202832),
                        fontSize = 16.sp,
                        letterSpacing = 1.6.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    Text(
                        "SECTION",
                        color = Color(0xFF394653),
                        fontSize = 10.sp,
                        letterSpacing = 1.5.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                    )
                }
                StageStatusLed(
                    label = "FX FOCUS",
                    active = selectedLayer.instrument == InstrumentType.ORGAN
                )
                StageHardwareButton(
                    label = if (organSectionIsOn) "ON" else "OFF",
                    selected = organSectionIsOn,
                    onClick = { toggleInstrumentLayers(InstrumentType.ORGAN) },
                    compact = true
                )
                StageHardwareButton(
                    label = if (soloedLayer == organSoloTarget) "SOLO ON" else "SOLO",
                    selected = soloedLayer == organSoloTarget,
                    onClick = {
                        val nextSolo = if (soloedLayer == organSoloTarget) null else organSoloTarget
                        onSoloedLayerChange(nextSolo)
                    },
                    compact = true
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(0.32f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
            // ISAAC ORGAN LAYER STRIP
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StageLayerSelectButton(
                    label = "ORGAN 1",
                    selected = selectedLayer == LayerId.ORGAN_1,
                    onClick = { handleLayerButtonPress(LayerId.ORGAN_1) },
                    onHoldStart = { startLayerButtonHold(LayerId.ORGAN_1) },
                    onHoldEnd = { endLayerButtonHold(LayerId.ORGAN_1) }
                )
                StageLayerSelectButton(
                    label = "ORGAN 2",
                    selected = selectedLayer == LayerId.ORGAN_2,
                    onClick = { handleLayerButtonPress(LayerId.ORGAN_2) },
                    onHoldStart = { startLayerButtonHold(LayerId.ORGAN_2) },
                    onHoldEnd = { endLayerButtonHold(LayerId.ORGAN_2) }
                )
                StageHardwareButton(
                    label = if (layerEnabled) "LAYER ON" else "LAYER OFF",
                    selected = layerEnabled,
                    onClick = { onLayerEnabledChange(!layerEnabled) }
                )
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text("ORGAN 1", color = Color(0xFFFFC36B), fontSize = 9.sp)
                        StageFader(
                            value = organ1LayerVolume,
                            onValueChange = onOrgan1LayerVolumeChange,
                            valueRange = 0f..1f
                        )
                        Text(
                            "${(organ1LayerVolume * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 9.sp
                        )
                        StageHardwareButton(label = if (layerEnabledStates[LayerId.ORGAN_1] == true) "LAYER 1 ON" else "LAYER 1 OFF", selected = layerEnabledStates[LayerId.ORGAN_1] == true, onClick = { onLayerEnabledChangeFor(LayerId.ORGAN_1, (layerEnabledStates[LayerId.ORGAN_1] ?: false).not()) }, compact = true)
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text("ORGAN 2", color = Color(0xFFFFC36B), fontSize = 9.sp)
                        StageFader(
                            value = organ2LayerVolume,
                            onValueChange = onOrgan2LayerVolumeChange,
                            valueRange = 0f..1f
                        )
                        Text(
                            "${(organ2LayerVolume * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 9.sp
                        )
                        StageHardwareButton(label = if (layerEnabledStates[LayerId.ORGAN_2] == true) "LAYER 2 ON" else "LAYER 2 OFF", selected = layerEnabledStates[LayerId.ORGAN_2] == true, onClick = { onLayerEnabledChangeFor(LayerId.ORGAN_2, (layerEnabledStates[LayerId.ORGAN_2] ?: false).not()) }, compact = true)
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                color = Color(0xFF111923),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF8794A2))
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "AUX KEYBOARD ASSIGNMENT",
                        color = Color(0xFFDCE3EA),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                            letterSpacing = 1.0.sp
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f)
                                .background(Color(0xFF202A35), RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFF596675), RoundedCornerShape(4.dp))
                                .padding(7.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("A  AUX KB", color = Color.White, style = MaterialTheme.typography.labelMedium)
                                Spacer(Modifier.weight(1f))
                                StageStatusLed("", organ1AuxEnabled)
                            }
                            StageHardwareButton(
                                label = if (organ1AuxEnabled) "ASSIGN: ON" else "ASSIGN: OFF",
                                selected = organ1AuxEnabled,
                                onClick = { onOrgan1AuxEnabledChange(organ1AuxEnabled.not()) },
                                modifier = Modifier.fillMaxWidth(),
                                compact = true
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StageStatusLed("SUSTPED", organ1MidiMonitor.sustainDown)
                                StageStatusLed("PSTICK", organ1MidiMonitor.pitchBend14 != 8192)
                            }
                        }
                        Column(
                            modifier = Modifier.weight(1f)
                                .background(Color(0xFF202A35), RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFF596675), RoundedCornerShape(4.dp))
                                .padding(7.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("B  AUX KB", color = Color.White, style = MaterialTheme.typography.labelMedium)
                                Spacer(Modifier.weight(1f))
                                StageStatusLed("", organ2AuxEnabled)
                            }
                            StageHardwareButton(
                                label = if (organ2AuxEnabled) "ASSIGN: ON" else "ASSIGN: OFF",
                                selected = organ2AuxEnabled,
                                onClick = { onOrgan2AuxEnabledChange(organ2AuxEnabled.not()) },
                                modifier = Modifier.fillMaxWidth(),
                                compact = true
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StageStatusLed("SUSTPED", organ2MidiMonitor.sustainDown)
                                StageStatusLed("PSTICK", organ2MidiMonitor.pitchBend14 != 8192)
                            }
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                color = Color(0xFF182431),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF46515F))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "ORGAN PERFORMANCE • ${if (selectedLayer == LayerId.ORGAN_2) "ORGAN 2" else "ORGAN 1"}",
                        color = Color(0xFFFFC36B),
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.2.sp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Surface(
                            modifier = Modifier.weight(0.9f),
                            color = Color(0xFF101923),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF46515F))
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                Text("OCTAVE SHIFT", color = Color(0xFFFFC36B), style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold))
                                Row(
                                    modifier = Modifier.fillMaxWidth().background(Color(0xFF202B36), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    StageHardwareButton(label = "−", selected = false, onClick = { onOctaveChange((octave - 1).coerceAtLeast(-4)) }, compact = true)
                                    Text(if (octave > 0) "+$octave" else octave.toString(), color = Color(0xFF91A9FF), style = MaterialTheme.typography.titleMedium)
                                    StageHardwareButton(label = "+", selected = false, onClick = { onOctaveChange((octave + 1).coerceAtMost(4)) }, compact = true)
                                }
                                Text("TRANSPOSE • −4 TO +4 OCT", color = Color(0xFF9BA8B8), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(2.1f),
                            color = Color(0xFF101923),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF46515F))
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("KEYBOARD SPLIT / ZONE", color = Color(0xFFFFC36B), style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("LOW KEY  $lowNote", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Text("HIGH KEY  $highNote", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                                Slider(value = lowNote.toFloat(), onValueChange = { onLayerLowNoteChange(it.toInt()) }, valueRange = 0f..127f, steps = 126)
                                Slider(value = highNote.toFloat(), onValueChange = { onLayerHighNoteChange(it.toInt()) }, valueRange = 0f..127f, steps = 126)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    Text("●", color = if (lowNote <= 31 && highNote >= 0) Color(0xFF65D98A) else Color(0xFF77818C), fontSize = 17.sp)
                                    Text("●", color = if (lowNote <= 63 && highNote >= 32) Color(0xFF65D98A) else Color(0xFF77818C), fontSize = 17.sp)
                                    Text("●", color = if (lowNote <= 95 && highNote >= 64) Color(0xFF65D98A) else Color(0xFF77818C), fontSize = 17.sp)
                                    Text("●", color = if (lowNote <= 127 && highNote >= 96) Color(0xFF65D98A) else Color(0xFF77818C), fontSize = 17.sp)
                                }
                                Text("ACTIVE KEY RANGE  •  $lowNote–$highNote  •  MIDI 0–127", color = Color(0xFF91A9FF), style = MaterialTheme.typography.labelSmall.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold))
                            }
                        }
                    }
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF101923),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF46515F))
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    if (organMidiReceived) "MIDI DATA RECEIVED" else "WAITING FOR MIDI DATA",
                                    color = if (organMidiReceived) Color(0xFF72D99A) else Color(0xFFFFC36B),
                                    fontSize = 10.sp
                                )
                                Text("SUSTAIN • ${if (organMidiSustainDown) "DOWN" else "UP"}",
                                    color = Color.White, fontSize = 10.sp)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("VOL • ${organMidiVolume * 100 / 127}%", color = Color.White, fontSize = 10.sp)
                                Text("EXP • ${organMidiExpression * 100 / 127}%", color = Color.White, fontSize = 10.sp)
                                Text("MOD • ${organMidiModulation * 100 / 127}%", color = Color.White, fontSize = 10.sp)
                            }
                            Text(
                                "PITCH BEND • ${String.format(java.util.Locale.US, "%+.2f", (organMidiPitchBend14 - 8192) / 8192f * 2f)} ST",
                                color = Color(0xFF91A9FF), fontSize = 10.sp
                            )
                        }
                    }
                }
            }
                }
                Column(
                    modifier = Modifier.weight(0.68f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
            val organControlNames = when (organModel) {
                OrganModel.B3 -> DRAWBAR_NAMES

                OrganModel.B3_BASS ->
                    listOf("BASS 16'", "BASS 8'")

OrganModel.VOX ->
    listOf(
        "PARTIAL 1", "PARTIAL 2",
        "PARTIAL 3", "PARTIAL 4",
        "PARTIAL 5", "PARTIAL 6",
        "PARTIAL 7"
    )

                OrganModel.FARFISA ->
                    listOf(
                        "BASS 16'", "STRINGS 16'",
                        "FLUTE 8'", "OBOE 8'",
                        "TRUMPET 8'", "STRINGS 8'",
                        "FLUTE 4'", "STRINGS 4'",
                        "2 2/3'"
                    )

                OrganModel.PIPE_1,
                OrganModel.PIPE_2 -> DRAWBAR_NAMES
            }

            val organControlIndices = when (organModel) {
                OrganModel.B3_BASS ->
                    listOf(0, 2)

OrganModel.VOX ->
    (0..6).toList()

                else ->
                    (0..8).toList()
            }



        // ISAAC ORGAN THREE-ZONE LAYOUT
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(
                modifier = Modifier
                    .weight(1.15f)
                    .background(Color(0xFF202A35), RoundedCornerShape(6.dp))
                    .border(1.dp, Color(0xFF8996A5), RoundedCornerShape(6.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
        Text(
            "ORGAN MODEL",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OrganModel.values().toList().chunked(3).forEach { modelRow ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    modelRow.forEach { model ->
                        StageHardwareButton(
                            label = model.displayName,
                            selected = model == organModel,
                            onClick = { onOrganModelChange(model) },
                            modifier = Modifier.weight(1f),
                            compact = true
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF111923), RoundedCornerShape(4.dp))
                .border(1.dp, Color(0xFFB49A70), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    "ACTIVE ORGAN PRESET",
                    color = Color(0xFF91A9FF),
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.1.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                )
                Text(
                    organModel.displayName,
                    color = Color(0xFFFFD18A),
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Text(
                "MIDI PC ${organModel.ordinal}",
                color = Color(0xFFD6DEE8),
                style = MaterialTheme.typography.labelSmall
            )
        }

                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF202A35), RoundedCornerShape(6.dp))
                        .border(1.dp, Color(0xFF8996A5), RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
Column(
    modifier = Modifier
        .fillMaxWidth()
        .background(Color(0xFF252F39), RoundedCornerShape(5.dp))
        .border(1.dp, Color(0xFFB49A70), RoundedCornerShape(5.dp))
        .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp)
) {
    Text(
        "VIBRATO / CHORUS",
        color = Color(0xFF91A9FF),
        style = MaterialTheme.typography.titleMedium
    )
    listOf(
        0 to "OFF",
        1 to "V1",
        2 to "V2",
        3 to "V3",
        4 to "C1",
        5 to "C2",
        6 to "C3"
    ).chunked(4).forEach { modeRow ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            modeRow.forEach { (mode, label) ->
                StageHardwareButton(
                    label = label,
                    selected = vibratoChorusMode == mode,
                    onClick = { onVibratoChorusModeChange(mode) },
                    modifier = Modifier.weight(1f),
                    compact = true
                )
            }
        }
    }
}



if (organModel == OrganModel.VOX) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("FILTER MIX", color = Color.White)

            Text(
                "${(voxFilterMix * 100).toInt()}%",
                color = Color(0xFF91A9FF)
            )
        }

        Slider(
            value = voxFilterMix,
            onValueChange = onVoxFilterMixChange,
            valueRange = 0f..1f
        )
    }
}
        }
            }
        if (organModel == OrganModel.B3) {
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .background(Color(0xFF202A35), RoundedCornerShape(6.dp))
                    .border(1.dp, Color(0xFF8996A5), RoundedCornerShape(6.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF252F39), RoundedCornerShape(5.dp))
            .border(1.dp, Color(0xFFB49A70), RoundedCornerShape(5.dp))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "B3 PERCUSSION",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )
            StageHardwareButton(
                label = if (b3PercussionEnabled) "ON" else "OFF",
                selected = b3PercussionEnabled,
                compact = true,
                onClick = { onB3PercussionEnabledChange(!b3PercussionEnabled) }
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("HARMONIC", color = Color.White, modifier = Modifier.weight(0.8f))
            StageHardwareButton(
                label = "2nd", selected = b3PercussionHarmonic == 2,
                onClick = { onB3PercussionHarmonicChange(2) },
                modifier = Modifier.weight(1f), compact = true
            )
            StageHardwareButton(
                label = "3rd", selected = b3PercussionHarmonic == 3,
                onClick = { onB3PercussionHarmonicChange(3) },
                modifier = Modifier.weight(1f), compact = true
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("VOLUME", color = Color.White, modifier = Modifier.weight(0.8f))
            StageHardwareButton(
                label = "SOFT", selected = b3PercussionSoft,
                onClick = { onB3PercussionSoftChange(true) },
                modifier = Modifier.weight(1f), compact = true
            )
            StageHardwareButton(
                label = "NORMAL", selected = !b3PercussionSoft,
                onClick = { onB3PercussionSoftChange(false) },
                modifier = Modifier.weight(1f), compact = true
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("DECAY", color = Color.White, modifier = Modifier.weight(0.8f))
            StageHardwareButton(
                label = "FAST", selected = b3PercussionFastDecay,
                onClick = { onB3PercussionFastDecayChange(true) },
                modifier = Modifier.weight(1f), compact = true
            )
            StageHardwareButton(
                label = "SLOW", selected = !b3PercussionFastDecay,
                onClick = { onB3PercussionFastDecayChange(false) },
                modifier = Modifier.weight(1f), compact = true
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("TRIGGER MODE", color = Color.White, modifier = Modifier.weight(1.1f))
            StageHardwareButton(
                label = "SINGLE", selected = !b3PercussionPolyMode,
                onClick = { onB3PercussionPolyModeChange(false) },
                modifier = Modifier.weight(1f), compact = true
            )
            StageHardwareButton(
                label = "POLY", selected = b3PercussionPolyMode,
                onClick = { onB3PercussionPolyModeChange(true) },
                modifier = Modifier.weight(1f), compact = true
            )
        }
    }
    }

        }
        }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF171E27), RoundedCornerShape(6.dp))
                    .border(1.dp, Color(0xFFB49A70), RoundedCornerShape(6.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
            Text(
                when (organModel) {
                    OrganModel.B3 -> "B3 TONEWHEEL DRAWBARS"
                    OrganModel.B3_BASS -> "B3 BASS DRAWBARS"
                    OrganModel.VOX -> "VOX DRAWBARS"
                    OrganModel.FARFISA -> "FARFISA REGISTERS"
                    OrganModel.PIPE_1 -> "PIPE 1 REGISTERS"
                    OrganModel.PIPE_2 -> "PIPE 2 REGISTERS"
                },
                color = Color.White,
                style = MaterialTheme.typography.titleMedium
            )

            if (organModel == OrganModel.FARFISA) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    organControlNames.chunked(3).forEach { controlRow ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            controlRow.forEach { name ->
                                val controlIndex = organControlNames.indexOf(name)
                                val index = organControlIndices[controlIndex]
                                val currentValue = drawbars[index]
                                StageHardwareButton(
                                    label = name + (if (currentValue >= 5) ": ON" else ": OFF"),
                                    selected = currentValue >= 5,
                                    onClick = { onDrawbarChange(index, if (currentValue >= 5) 0 else 8) },
                                    modifier = Modifier.weight(1f),
                                    compact = true
                                )
                            }
                            repeat(3 - controlRow.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    organControlNames.forEachIndexed { controlIndex, name ->
                        val index = organControlIndices[controlIndex]

                        StageDrawbar(
                            name = name,
                            value = drawbars[index],
                            onValueChange = { level ->
                                onDrawbarChange(index, level)
                            },
                            compact = true,
                            tall = true,
                            organStyle = true
                        )
                    }
                }
            }
            }

            }
                }
            }
        }
    }
}
}
if (activeSection == StudioSection.PIANO && instrument == InstrumentType.PIANO) {
    StageHardwarePanel(accent = Color(0xFFE0B66B)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "PIANO LAYERS",
                color = Color(0xFFE0B66B),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 16.sp,
                    letterSpacing = 2.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                )
            )
            Spacer(Modifier.weight(1f))
            Button(onClick = { shiftActive = !shiftActive }) {
                Text(if (shiftActive) "SHIFT: ON" else "SHIFT")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StageLayerSelectButton(label = "PIANO 1", selected = selectedLayer == LayerId.PIANO_1, onClick = { handleLayerButtonPress(LayerId.PIANO_1) }, onHoldStart = { startLayerButtonHold(LayerId.PIANO_1) }, onHoldEnd = { endLayerButtonHold(LayerId.PIANO_1) }, modifier = Modifier.weight(1f))
            StageLayerSelectButton(label = "PIANO 2", selected = selectedLayer == LayerId.PIANO_2, onClick = { handleLayerButtonPress(LayerId.PIANO_2) }, onHoldStart = { startLayerButtonHold(LayerId.PIANO_2) }, onHoldEnd = { endLayerButtonHold(LayerId.PIANO_2) }, modifier = Modifier.weight(1f))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("PIANO 1 VOLUME: ${((layerVolumeValues[LayerId.PIANO_1] ?: 1f) * 100).toInt()}%", color = Color.White)
                Slider(value = layerVolumeValues[LayerId.PIANO_1] ?: 1f, onValueChange = { onLayerVolumeChangeFor(LayerId.PIANO_1, it) }, valueRange = 0f..1f)
                StageHardwareButton(label = if (layerEnabledStates[LayerId.PIANO_1] == true) "LAYER 1 ON" else "LAYER 1 OFF", selected = layerEnabledStates[LayerId.PIANO_1] == true, onClick = { onLayerEnabledChangeFor(LayerId.PIANO_1, (layerEnabledStates[LayerId.PIANO_1] ?: false).not()) }, modifier = Modifier.fillMaxWidth(), compact = true)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("PIANO 2 VOLUME: ${((layerVolumeValues[LayerId.PIANO_2] ?: 1f) * 100).toInt()}%", color = Color.White)
                Slider(value = layerVolumeValues[LayerId.PIANO_2] ?: 1f, onValueChange = { onLayerVolumeChangeFor(LayerId.PIANO_2, it) }, valueRange = 0f..1f)
                StageHardwareButton(label = if (layerEnabledStates[LayerId.PIANO_2] == true) "LAYER 2 ON" else "LAYER 2 OFF", selected = layerEnabledStates[LayerId.PIANO_2] == true, onClick = { onLayerEnabledChangeFor(LayerId.PIANO_2, (layerEnabledStates[LayerId.PIANO_2] ?: false).not()) }, modifier = Modifier.fillMaxWidth(), compact = true)
            }
        }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1.3f)) {
            StageHardwarePanel(accent = Color(0xFFE0B66B)) {
                Text(
                    "PIANO SOUND MODEL",
                    color = Color(0xFFE0B66B),
                    style = MaterialTheme.typography.titleSmall
                )
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    PianoSoundModel.values().toList().chunked(3).forEach { modelRow ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            modelRow.forEach { model ->
                                StageHardwareButton(
                                    label = model.displayName,
                                    selected = model == pianoSoundModel,
                                    onClick = { onPianoSoundModelChange(model) },
                                    modifier = Modifier.weight(1f),
                                    compact = true
                                )
                            }
                            repeat(3 - modelRow.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            StageHardwarePanel(accent = Color(0xFF91A9FF)) {
                Text(
                    "OCTAVE CONTROL",
                    color = Color(0xFF91A9FF),
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    if (shiftActive) "SHIFT STEP • 2 OCTAVES"
                    else "NORMAL STEP • 1 OCTAVE",
                    color = Color.White,
                    style = MaterialTheme.typography.bodySmall
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = {
                            val step = if (shiftActive) 2 else 1
                            onOctaveChange((octave - step).coerceAtLeast(-2))
                        }
                    ) {
                        Text("−")
                    }

                    Text(
                        text = if (octave > 0) "+$octave" else octave.toString(),
                        color = Color(0xFF91A9FF),
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Button(
                        onClick = {
                            val step = if (shiftActive) 2 else 1
                            onOctaveChange((octave + step).coerceAtMost(2))
                        }
                    ) {
                        Text("+")
                    }
                }
            }
        }
    }
}}
}
}


    }




@Composable
private fun Modulation1Panel(
    settings: Mod1Settings,
    layerName: String,
    onSettingsChange: (Mod1Settings) -> Unit
) {
    var typeMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "MODULATION 1 • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    val enabling = !settings.enabled
                    onSettingsChange(
                        settings.copy(
                            enabled = enabling,
                            type = if (
                                enabling && settings.type == Mod1Type.OFF
                            ) Mod1Type.TREMOLO else settings.type
                        )
                    )
                }
            ) {
                Text(if (settings.enabled) "EFFECT: ON" else "EFFECT: OFF")
            }
        }

        Text("EFFECT TYPE", color = Color.White)

        Button(onClick = { typeMenuExpanded = true }) {
            Text(
                if (settings.type == Mod1Type.OFF) "SELECT EFFECT"
                else settings.type.name.replace('_', ' ')
            )
        }

        DropdownMenu(
            expanded = typeMenuExpanded,
            onDismissRequest = { typeMenuExpanded = false }
        ) {
            Mod1Type.values().forEach { type ->
                DropdownMenuItem(
                    text = {
                        Text(
                            if (type == Mod1Type.OFF) "OFF"
                            else type.name.replace('_', ' ')
                        )
                    },
                    onClick = {
                        onSettingsChange(
                            settings.copy(
                                type = type,
                                enabled = if (type == Mod1Type.OFF) {
                                    false
                                } else {
                                    settings.enabled
                                }
                            )
                        )
                        typeMenuExpanded = false
                    }
                )
            }
        }

        EnvelopeControl(
            name = "RATE",
            displayValue = "${(settings.rate * 100).toInt()}%",
            value = settings.rate,
            range = 0f..1f,
            onChange = { onSettingsChange(settings.copy(rate = it)) }
        )

        EnvelopeControl(
            name = "AMOUNT",
            displayValue = "${(settings.amount * 100).toInt()}%",
            value = settings.amount,
            range = 0f..1f,
            onChange = { onSettingsChange(settings.copy(amount = it)) }
        )

        EnvelopeControl(
            name = "MIX",
            displayValue = "${(settings.mix * 100).toInt()}%",
            value = settings.mix,
            range = 0f..1f,
            onChange = { onSettingsChange(settings.copy(mix = it)) }
        )

        if (
            settings.type == Mod1Type.RING_MOD ||
            settings.type == Mod1Type.WAH ||
            settings.type == Mod1Type.AUTO_WAH
        ) {
            EnvelopeControl(
                name = "FREQUENCY",
                displayValue = "${(settings.frequency * 100).toInt()}%",
                value = settings.frequency,
                range = 0f..1f,
                onChange = {
                    onSettingsChange(settings.copy(frequency = it))
                }
            )

            EnvelopeControl(
                name = "RESONANCE",
                displayValue = "${(settings.resonance * 100).toInt()}%",
                value = settings.resonance,
                range = 0f..1f,
                onChange = {
                    onSettingsChange(settings.copy(resonance = it))
                }
            )
        }
    }
}

@Composable
private fun Modulation2Panel(
    settings: Mod2Settings,
    layerName: String,
    onSettingsChange: (Mod2Settings) -> Unit
) {
    var typeMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "MODULATION 2 • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)

            Button(
                onClick = {
                    val enabling = !settings.enabled
                    onSettingsChange(
                        settings.copy(
                            enabled = enabling,
                            type = if (
                                enabling && settings.type == Mod2Type.OFF
                            ) Mod2Type.CHORUS else settings.type
                        )
                    )
                }
            ) {
                Text(
                    if (settings.enabled) "EFFECT: ON"
                    else "EFFECT: OFF"
                )
            }
        }

        Text("EFFECT TYPE", color = Color.White)

        Button(onClick = { typeMenuExpanded = true }) {
            Text(
                if (settings.type == Mod2Type.OFF) "SELECT EFFECT"
                else settings.type.name.replace('_', ' ')
            )
        }

        DropdownMenu(
            expanded = typeMenuExpanded,
            onDismissRequest = { typeMenuExpanded = false }
        ) {
            Mod2Type.values().forEach { type ->
                DropdownMenuItem(
                    text = {
                        Text(
                            if (type == Mod2Type.OFF) "OFF"
                            else type.name.replace('_', ' ')
                        )
                    },
                    onClick = {
                        onSettingsChange(
                            settings.copy(
                                type = type,
                                enabled = if (type == Mod2Type.OFF) {
                                    false
                                } else {
                                    settings.enabled
                                }
                            )
                        )
                        typeMenuExpanded = false
                    }
                )
            }
        }

        EnvelopeControl(
            name = "RATE",
            displayValue = "${(settings.rate * 100).toInt()}%",
            value = settings.rate,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(rate = it))
            }
        )

        EnvelopeControl(
            name = "AMOUNT",
            displayValue = "${(settings.amount * 100).toInt()}%",
            value = settings.amount,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(amount = it))
            }
        )

        EnvelopeControl(
            name = "MIX",
            displayValue = "${(settings.mix * 100).toInt()}%",
            value = settings.mix,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(mix = it))
            }
        )

        if (
            settings.type == Mod2Type.CHORUS ||
            settings.type == Mod2Type.FLANGER ||
            settings.type == Mod2Type.SPIN
        ) {
            EnvelopeControl(
                name = "FEEDBACK",
                displayValue = "${(settings.feedback * 100).toInt()}%",
                value = settings.feedback,
                range = 0f..1f,
                onChange = {
                    onSettingsChange(settings.copy(feedback = it))
                }
            )
        }
    }
}

@Composable
private fun DelayPanel(
    settings: DelaySettings,
    layerName: String,
    onSettingsChange: (DelaySettings) -> Unit
) {
    var filterMenuExpanded by remember { mutableStateOf(false) }
    var feedbackMenuExpanded by remember { mutableStateOf(false) }
    var subdivisionMenuExpanded by remember { mutableStateOf(false) }
    var lastTapTimeMs by remember(layerName) { mutableStateOf(0L) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "DELAY • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)

            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(enabled = !settings.enabled)
                    )
                }
            ) {
                Text(if (settings.enabled) "DELAY: ON" else "DELAY: OFF")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TIME MODE", color = Color.White)

            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(tempoSync = !settings.tempoSync)
                    )
                }
            ) {
                Text(
                    if (settings.tempoSync) "TEMPO SYNC"
                    else "FREE TIME"
                )
            }
        }

        if (settings.tempoSync) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    EnvelopeControl(
                        name = "TEMPO",
                        displayValue = "${settings.tempoBpm.toInt()} BPM",
                        value = settings.tempoBpm,
                        range = 40f..240f,
                        onChange = {
                            onSettingsChange(settings.copy(tempoBpm = it))
                        }
                    )
                }

                Button(
                    onClick = {
                        val now = android.os.SystemClock.elapsedRealtime()
                        val previous = lastTapTimeMs

                        if (previous > 0L) {
                            val interval = now - previous

                            if (interval in 250L..1500L) {
                                val bpm = (60000f / interval.toFloat())
                                    .coerceIn(40f, 240f)

                                onSettingsChange(
                                    settings.copy(
                                        tempoBpm = bpm,
                                        tempoSync = true
                                    )
                                )
                            }
                        }

                        lastTapTimeMs = now
                    }
                ) {
                    Text(
                        if (lastTapTimeMs == 0L) "TAP TEMPO"
                        else "TAP AGAIN"
                    )
                }
            }

            Text("NOTE SUBDIVISION", color = Color.White)

            Button(
                onClick = { subdivisionMenuExpanded = true }
            ) {
                Text(settings.subdivision.displayName)
            }

            DropdownMenu(
                expanded = subdivisionMenuExpanded,
                onDismissRequest = {
                    subdivisionMenuExpanded = false
                }
            ) {
                DelaySubdivision.values().forEach { subdivision ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                "${subdivision.displayName} • " +
                                    subdivision.name.replace('_', ' ')
                            )
                        },
                        onClick = {
                            onSettingsChange(
                                settings.copy(subdivision = subdivision)
                            )
                            subdivisionMenuExpanded = false
                        }
                    )
                }
            }
        } else {
            EnvelopeControl(
                name = "DELAY TIME",
                displayValue = "${settings.timeMs.toInt()} ms",
                value = settings.timeMs.coerceIn(40f, 2000f),
                range = 40f..2000f,
                onChange = {
                    onSettingsChange(settings.copy(timeMs = it))
                }
            )
        }

        EnvelopeControl(
            name = "FEEDBACK",
            displayValue = "${(settings.feedback * 100).toInt()}%",
            value = settings.feedback.coerceIn(0f, 0.92f),
            range = 0f..0.92f,
            onChange = {
                onSettingsChange(settings.copy(feedback = it))
            }
        )

        EnvelopeControl(
            name = "WET MIX",
            displayValue = "${(settings.mix * 100).toInt()}%",
            value = settings.mix,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(mix = it))
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("PING-PONG STEREO", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(pingPong = !settings.pingPong)
                    )
                }
            ) {
                Text(if (settings.pingPong) "ON" else "OFF")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ANALOG CHARACTER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(analogMode = !settings.analogMode)
                    )
                }
            ) {
                Text(if (settings.analogMode) "ON" else "OFF")
            }
        }

        Text("FEEDBACK FILTER", color = Color.White)

        Button(onClick = { filterMenuExpanded = true }) {
            Text(settings.filter.name.replace('_', ' '))
        }

        DropdownMenu(
            expanded = filterMenuExpanded,
            onDismissRequest = { filterMenuExpanded = false }
        ) {
            DelayFilterType.values().forEach { filter ->
                DropdownMenuItem(
                    text = {
                        Text(filter.name.replace('_', ' '))
                    },
                    onClick = {
                        onSettingsChange(settings.copy(filter = filter))
                        filterMenuExpanded = false
                    }
                )
            }
        }

        Text("FEEDBACK VARIATION", color = Color.White)

        Button(onClick = { feedbackMenuExpanded = true }) {
            Text(settings.feedbackEffect.name.replace('_', ' '))
        }

        DropdownMenu(
            expanded = feedbackMenuExpanded,
            onDismissRequest = { feedbackMenuExpanded = false }
        ) {
            DelayFeedbackEffect.values().forEach { effect ->
                DropdownMenuItem(
                    text = {
                        Text(effect.name.replace('_', ' '))
                    },
                    onClick = {
                        onSettingsChange(
                            settings.copy(feedbackEffect = effect)
                        )
                        feedbackMenuExpanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun StageHardwarePanel(
    accent: Color,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D24), RoundedCornerShape(10.dp))
            .border(
                1.dp,
                accent.copy(alpha = 0.48f),
                RoundedCornerShape(10.dp)
            )
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
private fun OrganFitPanel(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopStart
    ) {
        content()
    }
}

@Composable
private fun OrganHardwarePanel(
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF9B1720), RoundedCornerShape(11.dp))
            .border(2.dp, Color(0xFFD5D9DF), RoundedCornerShape(11.dp))
            .padding(4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF26323E), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFFB7C1CC), RoundedCornerShape(8.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

@Composable
private fun StageStatusLed(
    label: String,
    active: Boolean,
    warning: Boolean = false
) {
    val ledColor = when {
        warning -> Color(0xFFFF5B5B)
        active -> Color(0xFF65D98A)
        else -> Color(0xFF77818C)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Canvas(modifier = Modifier.size(12.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(ledColor.copy(alpha = 0.18f), size.minDimension * 0.50f, center)
            drawCircle(ledColor.copy(alpha = 0.35f), size.minDimension * 0.39f, center)
            drawCircle(
                color = ledColor,
                radius = size.minDimension * 0.27f,
                center = center
            )
            drawCircle(
                color = Color.White.copy(alpha = if (active || warning) 0.75f else 0.18f),
                radius = size.minDimension * 0.09f,
                center = Offset(size.width * 0.39f, size.height * 0.34f)
            )
        }
        Text(
            label,
            color = if (warning) Color(0xFFFFB0A8) else Color(0xFFD6DEE8),
            style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 0.7.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
            )
        )
    }
}

@Composable
private fun StageHardwareButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    compact: Boolean = false
) {
    val accent = if (selected) Color(0xFFFFC36B) else Color(0xFF79B8FF)
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .border(
                width = 1.dp,
                color = if (selected) accent.copy(alpha = 0.95f)
                        else Color(0xFF46515F),
                shape = RoundedCornerShape(5.dp)
            )
            .then(
                if (selected) Modifier.background(
                    Color(0xFFFFC36B).copy(alpha = 0.055f),
                    RoundedCornerShape(5.dp)
                ) else Modifier
            ),
        shape = RoundedCornerShape(5.dp),
        contentPadding = if (compact) androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp) else ButtonDefaults.ContentPadding,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Color(0xFF49351F)
                             else Color(0xFF252A31),
            contentColor = if (selected) Color(0xFFFFE5B8)
                           else Color(0xFFD0D5DC),
            disabledContainerColor = Color(0xFF171C22),
            disabledContentColor = Color(0xFF68717B)
        )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 5.dp)
        ) {
            Text(
                text = if (selected) "●" else "○",
                color = if (selected) accent else Color(0xFF68717B),
                fontSize = if (compact) 8.sp else 10.sp
            )
            Text(
                text = label,
                fontSize = if (compact) 9.sp else 11.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun StageLayerSelectButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    onHoldStart: () -> Unit,
    onHoldEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = if (selected) Color(0xFFFFC36B) else Color(0xFF79B8FF)
    Row(
        modifier = modifier
            .border(1.dp, if (selected) accent else Color(0xFF46515F), RoundedCornerShape(5.dp))
            .background(if (selected) Color(0xFF49351F) else Color(0xFF252A31), RoundedCornerShape(5.dp))
            .pointerInput(label) {
                detectTapGestures(
                    onTap = { onClick() },
                    onPress = {
                        onHoldStart()
                        tryAwaitRelease()
                        onHoldEnd()
                    }
                )
            }
            .padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(if (selected) "●" else "○", color = accent, fontSize = 9.sp)
        Text(label, color = if (selected) Color(0xFFFFE5B8) else Color(0xFFD0D5DC),
            fontSize = 10.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
        )
    }
}

@Composable
private fun StageDrawbar(
    name: String,
    value: Int,
    onValueChange: (Int) -> Unit,
    enabled: Boolean = true,
    compact: Boolean = false,
    tall: Boolean = false,
    organStyle: Boolean = false
) {
    val latestValue by rememberUpdatedState(value)
    val latestOnValueChange by rememberUpdatedState(onValueChange)

    Column(
        modifier = Modifier.width(if (organStyle) 68.dp else if (compact) 42.dp else 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (organStyle) {
            Text(
                text = name,
                color = Color(0xFFE2E7ED),
                fontSize = 9.sp,
                maxLines = 1
            )
        }
        Canvas(
            modifier = Modifier
                .size(width = if (organStyle) 68.dp else if (compact) 42.dp else 56.dp, height = if (organStyle && tall) 202.dp else if (tall) 104.dp else if (compact) 78.dp else 112.dp)
                .pointerInput(enabled) {
                    if (enabled) {
                        var dragValue = latestValue.toFloat()

                        detectDragGestures(
                            onDragStart = {
                                dragValue = latestValue.toFloat()
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val travel = (
                                    size.height - 16.dp.toPx()
                                ).coerceAtLeast(1f)

                                dragValue = (
                                    dragValue - dragAmount.y * 8f / travel
                                ).coerceIn(0f, 8f)

                                latestOnValueChange(
                                    (dragValue + 0.5f).toInt().coerceIn(0, 8)
                                )
                            }
                        )
                    }
                }
        ) {
            val centerX = size.width / 2f
            val top = 8.dp.toPx()
            val bottom = size.height - top
            val trackHeight = bottom - top
            val fraction = latestValue.coerceIn(0, 8) / 8f
            val positionY = bottom - trackHeight * fraction
            for (level in 1..8) {
                val ledY = bottom - trackHeight * (level / 8f)
                val active = latestValue.coerceIn(0, 8) >= level
                if (active && organStyle) {
                    drawRoundRect(
                        color = Color(0xFFFF3030).copy(alpha = 0.22f),
                        topLeft = Offset(1.dp.toPx(), ledY - 4.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size(12.dp.toPx(), 12.dp.toPx()),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
                    )
                }
                drawRoundRect(
                    color = if (active) Color(0xFFFF3030) else Color(0xFF30343B),
                    topLeft = Offset(3.dp.toPx(), ledY - 2.5.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(if (organStyle) 10.dp.toPx() else 8.dp.toPx(), if (organStyle) 10.dp.toPx() else 8.dp.toPx()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(1.dp.toPx())
                )
            }

            drawRoundRect(
                color = Color(0xFF07090D),
                topLeft = Offset(centerX - 7.dp.toPx(), top),
                size = androidx.compose.ui.geometry.Size(
                    (if (organStyle) 20.dp else 14.dp).toPx(), trackHeight
                ),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx())
            )
            drawRoundRect(
                color = Color(0xFF303946),
                topLeft = Offset(centerX - 2.dp.toPx(), top + 2.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(
                    4.dp.toPx(), (trackHeight - 4.dp.toPx()).coerceAtLeast(1f)
                ),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )

            for (level in 0..8) {
                val tickY = bottom - trackHeight * (level / 8f)
                val major = level == 0 || level == 4 || level == 8
                val tickLength = if (major) (if (organStyle) 10.dp else if (compact) 8.dp else 10.dp).toPx() else (if (organStyle) 6.dp else if (compact) 4.dp else 6.dp).toPx()

                drawLine(
                    color = if (organStyle) {
                        if (major) Color(0xFFD5DCE5) else Color(0xFF8796A7)
                    } else if (major) Color(0xFFE0B66B) else Color(0xFF87909E),
                    start = Offset(centerX - (if (organStyle) 22.dp else if (compact) 9.dp else 22.dp).toPx(), tickY),
                    end = Offset(centerX - (if (organStyle) 22.dp else if (compact) 9.dp else 22.dp).toPx() + tickLength, tickY),
                    strokeWidth = if (major) 1.5.dp.toPx() else 1.dp.toPx()
                )
                drawLine(
                    color = if (organStyle) {
                        if (major) Color(0xFFD5DCE5) else Color(0xFF8796A7)
                    } else if (major) Color(0xFFE0B66B) else Color(0xFF87909E),
                    start = Offset(centerX + (if (organStyle) 22.dp else if (compact) 9.dp else 22.dp).toPx() - tickLength, tickY),
                    end = Offset(centerX + (if (organStyle) 22.dp else if (compact) 9.dp else 22.dp).toPx(), tickY),
                    strokeWidth = if (major) 1.5.dp.toPx() else 1.dp.toPx()
                )
            }

            drawRoundRect(
                color = Color(0xFF05070A),
                topLeft = Offset(centerX - (if (organStyle) 21.dp else if (compact) 10.5.dp else 17.dp).toPx(), positionY - (if (organStyle) 11.dp else if (compact) 7.dp else 8.dp).toPx()),
                size = androidx.compose.ui.geometry.Size((if (organStyle) 46.dp else if (compact) 21.dp else 34.dp).toPx(), (if (organStyle) 30.dp else if (compact) 14.dp else 16.dp).toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
            drawRoundRect(
                color = if (organStyle) {
                    if (enabled) Color(0xFFD8DEE6) else Color(0xFF555B65)
                } else if (enabled) Color(0xFFB7C0CC) else Color(0xFF555B65),
                topLeft = Offset(centerX - (if (organStyle) 21.dp else if (compact) 8.5.dp else 15.dp).toPx(), positionY - (if (organStyle) 11.dp else if (compact) 5.dp else 6.dp).toPx()),
                size = androidx.compose.ui.geometry.Size((if (organStyle) 38.dp else if (compact) 17.dp else 30.dp).toPx(), (if (organStyle) 22.dp else if (compact) 10.dp else 12.dp).toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
            drawLine(
                color = Color(0xFFF0F3F7),
                start = Offset(centerX - (if (organStyle) 10.dp else if (compact) 6.dp else 10.dp).toPx(), positionY - (if (compact) 2.dp else 3.dp).toPx()),
                end = Offset(centerX + (if (organStyle) 10.dp else if (compact) 6.dp else 10.dp).toPx(), positionY - (if (compact) 2.dp else 3.dp).toPx()),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = Color(0xFF555F6D),
                start = Offset(centerX - (if (compact) 6.5.dp else 11.dp).toPx(), positionY + (if (compact) 2.dp else 3.dp).toPx()),
                end = Offset(centerX + (if (compact) 6.5.dp else 11.dp).toPx(), positionY + (if (compact) 2.dp else 3.dp).toPx()),
                strokeWidth = 1.dp.toPx()
            )
            if (organStyle) {
                drawLine(Color(0xFFF5F7FA), Offset(centerX - (if (compact) 7.5.dp else 13.dp).toPx(), positionY - 4.dp.toPx()), Offset(centerX - (if (compact) 7.5.dp else 13.dp).toPx(), positionY + 4.dp.toPx()), 1.dp.toPx())
                drawLine(Color(0xFF68717D), Offset(centerX + (if (compact) 7.5.dp else 13.dp).toPx(), positionY - 4.dp.toPx()), Offset(centerX + (if (compact) 7.5.dp else 13.dp).toPx(), positionY + 4.dp.toPx()), 1.dp.toPx())
            }
        }

        if (!organStyle) {
            Text(
                text = name,
                color = Color(0xFFE0B66B),
                fontSize = if (tall) 8.sp else if (compact) 7.sp else 9.sp,
                maxLines = 1
            )
        }
        Text(
            text = value.coerceIn(0, 8).toString(),
            color = if (organStyle) Color(0xFFE2E7ED) else Color(0xFFE0B66B),
            fontSize = 11.sp
        )
    }
}


@Composable
private fun StageFader(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    enabled: Boolean = true
) {
    val span = (valueRange.endInclusive - valueRange.start).coerceAtLeast(0.0001f)
    val fraction = ((value - valueRange.start) / span).coerceIn(0f, 1f)
    val latestValue by rememberUpdatedState(value)
    val latestOnValueChange by rememberUpdatedState(onValueChange)

    Canvas(
        modifier = Modifier
            .size(width = 34.dp, height = 72.dp)
            .pointerInput(valueRange, enabled) {
                if (enabled) {
                    val travel = size.height.coerceAtLeast(1).toFloat()
                    var dragValue = latestValue
                    detectDragGestures(
                        onDragStart = { dragValue = latestValue },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragValue = (
                                dragValue - dragAmount.y * span / travel
                            ).coerceIn(valueRange.start, valueRange.endInclusive)
                            latestOnValueChange(dragValue)
                        }
                    )
                }
            }
    ) {
        val centerX = size.width / 2f
        val top = 7.dp.toPx()
        val bottom = size.height - top
        val trackHeight = bottom - top
        val positionY = bottom - trackHeight * fraction

        drawLine(
            color = Color(0xFF171B23),
            start = Offset(centerX, top),
            end = Offset(centerX, bottom),
            strokeWidth = 5.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF91A9FF),
            start = Offset(centerX, positionY),
            end = Offset(centerX, bottom),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawRoundRect(
            color = Color(0xFF080A0E),
            topLeft = Offset(centerX - 13.dp.toPx(), positionY - 6.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(26.dp.toPx(), 12.dp.toPx()),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
        )
        drawRoundRect(
            color = if (enabled) Color(0xFF9FAAB8) else Color(0xFF555B65),
            topLeft = Offset(centerX - 11.dp.toPx(), positionY - 5.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(22.dp.toPx(), 10.dp.toPx()),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
        )
        drawLine(
            color = Color(0xFFE5EAF1),
            start = Offset(centerX - 7.dp.toPx(), positionY - 2.dp.toPx()),
            end = Offset(centerX + 7.dp.toPx(), positionY - 2.dp.toPx()),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = Color(0xFF343B47),
            start = Offset(centerX - 8.dp.toPx(), positionY + 2.dp.toPx()),
            end = Offset(centerX + 8.dp.toPx(), positionY + 2.dp.toPx()),
            strokeWidth = 1.dp.toPx()
        )
    }
}

@Composable
private fun StageRotary(label: String, value: Float, onValueChange: (Float) -> Unit, valueRange: ClosedFloatingPointRange<Float>, modifier: Modifier = Modifier) {
    val span = valueRange.endInclusive - valueRange.start
    val fraction = if (span == 0f) 0f else ((value - valueRange.start) / span).coerceIn(0f, 1f)
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(modifier = Modifier.size(72.dp).pointerInput(value, valueRange) {
            detectDragGestures { change, drag ->
                change.consume()
                onValueChange((value - drag.y / 180f * span).coerceIn(valueRange.start, valueRange.endInclusive))
            }
        }) {
            val r = size.minDimension * 0.38f
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color(0xFF17191D), r * 1.35f, center)
            drawArc(Color(0xFF555B63), 135f, 270f, false, style = Stroke(5.dp.toPx()))
            drawArc(Color(0xFFD52B32), 135f, 270f * fraction, false, style = Stroke(5.dp.toPx()))
            val a = Math.toRadians((135f + 270f * fraction).toDouble())
            val tip = Offset(center.x + kotlin.math.cos(a).toFloat() * r, center.y + kotlin.math.sin(a).toFloat() * r)
            drawCircle(Color(0xFF30343A), r, center)
            drawLine(Color(0xFFE8E8E8), center, tip, 3.dp.toPx(), cap = StrokeCap.Round)
            drawCircle(Color(0xFFBFC3C8), 3.dp.toPx(), center)
        }
        Text(label, color = Color.White)
        Text(value.toInt().toString(), color = Color(0xFFE2B85B))
    }
}

@Composable
private fun EnvelopeControl(
    name: String,
    displayValue: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    val span = (range.endInclusive - range.start).coerceAtLeast(0.0001f)
    val fraction = ((value - range.start) / span).coerceIn(0f, 1f)
    val latestValue by rememberUpdatedState(value)
    val latestOnChange by rememberUpdatedState(onChange)

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                name,
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                letterSpacing = 0.8.sp
            )
            Text(
                displayValue,
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.labelLarge
            )
        }

        Canvas(
            modifier = Modifier
                .size(58.dp)
                .pointerInput(range) {
                    var dragValue = latestValue
                    detectDragGestures(
                        onDragStart = { dragValue = latestValue },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragValue = (
                                dragValue - dragAmount.y * span / 180f
                            ).coerceIn(range.start, range.endInclusive)
                            latestOnChange(dragValue)
                        }
                    )
                }
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = size.minDimension * 0.43f
            val center = Offset(cx, cy)

            for (tick in 0..10) {
                val angle = Math.toRadians(135.0 + tick * 27.0)
                val inner = radius * 1.02f
                val outer = radius * 1.13f
                drawLine(
                    color = Color(0xFF77829A),
                    start = Offset(
                        cx + kotlin.math.cos(angle).toFloat() * inner,
                        cy + kotlin.math.sin(angle).toFloat() * inner
                    ),
                    end = Offset(
                        cx + kotlin.math.cos(angle).toFloat() * outer,
                        cy + kotlin.math.sin(angle).toFloat() * outer
                    ),
                    strokeWidth = 1.1.dp.toPx()
                )
            }

            drawArc(
                color = Color(0xFF39414D),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color = Color(0xFFFFC36B),
                startAngle = 135f,
                sweepAngle = 270f * fraction,
                useCenter = false,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            drawCircle(Color(0xFF080A0E), radius * 0.82f, center)
            drawCircle(
                Color(0xFF9BA6B5),
                radius * 0.79f,
                center,
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(Color(0xFF252C36), radius * 0.74f, center)
            drawCircle(
                Color(0xFF596575),
                radius * 0.74f,
                center,
                style = Stroke(width = 1.dp.toPx())
            )
            drawCircle(Color(0xFF111720), radius * 0.66f, center)

            val pointerAngle = Math.toRadians(
                135.0 + fraction.toDouble() * 270.0
            )
            drawLine(
                color = Color(0xFFFFE2AE),
                start = center,
                end = Offset(
                    cx + kotlin.math.cos(pointerAngle).toFloat() * radius * 0.58f,
                    cy + kotlin.math.sin(pointerAngle).toFloat() * radius * 0.58f
                ),
                strokeWidth = 2.4.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(Color(0xFFBFC9DA), 2.2.dp.toPx(), center)
        }
    }
}

@Composable
private fun PianoKey(
    note: Int,
    label: String,
    black: Boolean,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    val keyColor = when {
        black && pressed -> Color(0xFF526DAA)
        black -> Color(0xFF171923)
        pressed -> Color(0xFFB0C4FF)
        else -> Color.White
    }

    val shape = RoundedCornerShape(
        bottomStart = 5.dp,
        bottomEnd = 5.dp
    )

    Box(
        modifier = modifier
            .background(keyColor, shape)
            .border(
                width = 0.7.dp,
                color = if (black) Color.Black else Color(0xFFB8B8B8),
                shape = shape
            )
            .pointerInput(note) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onNoteOn(note, 0.8f)
                        tryAwaitRelease()
                        pressed = false
                        onNoteOff(note)
                    }
                )
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        if (label.isNotEmpty()) {
            Text(
                text = label,
                color = Color.DarkGray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}
@Composable
private fun CompressorPanel(
    settings: CompressorSettings,
    layerName: String,
    onSettingsChange: (CompressorSettings) -> Unit
) {
    var detectorMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "COMPRESSOR • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(enabled = !settings.enabled))
                }
            ) {
                Text(if (settings.enabled) "COMPRESSOR: ON" else "COMPRESSOR: OFF")
            }
        }

        Text("DETECTOR MODE", color = Color.White)
        Button(onClick = { detectorMenuExpanded = true }) {
            Text(settings.detector.name)
        }

        DropdownMenu(
            expanded = detectorMenuExpanded,
            onDismissRequest = { detectorMenuExpanded = false }
        ) {
            CompressorDetector.values().forEach { detector ->
                DropdownMenuItem(
                    text = { Text(detector.name) },
                    onClick = {
                        onSettingsChange(settings.copy(detector = detector))
                        detectorMenuExpanded = false
                    }
                )
            }
        }

        EnvelopeControl(
            name = "COMPRESSION AMOUNT",
            displayValue = "${(settings.amount.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.amount.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(amount = it))
            }
        )

        EnvelopeControl(
            name = "THRESHOLD",
            displayValue = "${settings.thresholdDb.toInt()} dB",
            value = settings.thresholdDb.coerceIn(-60f, 0f),
            range = -60f..0f,
            onChange = {
                onSettingsChange(settings.copy(thresholdDb = it))
            }
        )

        EnvelopeControl(
            name = "RATIO",
            displayValue = String.format("%.1f:1", settings.ratio),
            value = settings.ratio.coerceIn(1f, 20f),
            range = 1f..20f,
            onChange = {
                onSettingsChange(settings.copy(ratio = it))
            }
        )

        EnvelopeControl(
            name = "ATTACK",
            displayValue = String.format("%.1f ms", settings.attackMs),
            value = settings.attackMs.coerceIn(0.1f, 100f),
            range = 0.1f..100f,
            onChange = {
                onSettingsChange(settings.copy(attackMs = it))
            }
        )

        EnvelopeControl(
            name = "RELEASE",
            displayValue = "${settings.releaseMs.toInt()} ms",
            value = settings.releaseMs.coerceIn(10f, 1000f),
            range = 10f..1000f,
            onChange = {
                onSettingsChange(settings.copy(releaseMs = it))
            }
        )

        EnvelopeControl(
            name = "SOFT KNEE",
            displayValue = "${settings.kneeDb.toInt()} dB",
            value = settings.kneeDb.coerceIn(0f, 24f),
            range = 0f..24f,
            onChange = {
                onSettingsChange(settings.copy(kneeDb = it))
            }
        )

        EnvelopeControl(
            name = "MAKEUP GAIN",
            displayValue = String.format("%+.1f dB", settings.makeupGainDb),
            value = settings.makeupGainDb.coerceIn(-12f, 24f),
            range = -12f..24f,
            onChange = {
                onSettingsChange(settings.copy(makeupGainDb = it))
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("FAST MODE", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(fast = !settings.fast))
                }
            ) {
                Text(if (settings.fast) "FAST: ON" else "FAST: OFF")
            }
        }
    }
}

@Composable
private fun AmpEqPanel(
    settings: AmpEqSettings,
    layerName: String,
    onSettingsChange: (AmpEqSettings) -> Unit
) {
    var ampMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "AMP / SPEAKER • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(enabled = !settings.enabled))
                }
            ) {
                Text(if (settings.enabled) "AMP / EQ: ON" else "AMP / EQ: OFF")
            }
        }

        Text("AMP MODEL", color = Color.White)

        Button(onClick = { ampMenuExpanded = true }) {
            Text(settings.ampModel.name.replace('_', ' '))
        }

        DropdownMenu(
            expanded = ampMenuExpanded,
            onDismissRequest = { ampMenuExpanded = false }
        ) {
            AmpModel.values().forEach { model ->
                DropdownMenuItem(
                    text = { Text(model.name.replace('_', ' ')) },
                    onClick = {
                        onSettingsChange(settings.copy(ampModel = model))
                        ampMenuExpanded = false
                    }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TO ROTARY", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(toRotary = !settings.toRotary))
                }
            ) {
                Text(if (settings.toRotary) "TO ROTARY: ON" else "TO ROTARY: OFF")
            }
        }

        EnvelopeControl(
            name = "DRIVE",
            displayValue = "${(settings.drive.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.drive.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(drive = it))
            }
        )

        Text("SPEAKER FILTERS", color = Color(0xFF91A9FF))

        EnvelopeControl(
            name = "HIGH PASS",
            displayValue = "${settings.highPassHz.toInt()} Hz",
            value = settings.highPassHz.coerceIn(20f, 1000f),
            range = 20f..1000f,
            onChange = {
                onSettingsChange(settings.copy(highPassHz = it))
            }
        )

        EnvelopeControl(
            name = "LOW PASS",
            displayValue = "${settings.lowPassHz.toInt()} Hz",
            value = settings.lowPassHz.coerceIn(1000f, 20000f),
            range = 1000f..20000f,
            onChange = {
                onSettingsChange(settings.copy(lowPassHz = it))
            }
        )

        Text("THREE-BAND EQUALIZER", color = Color(0xFF91A9FF))

        EnvelopeControl(
            name = "LOW",
            displayValue = "${settings.lowGainDb.toInt()} dB",
            value = settings.lowGainDb.coerceIn(-18f, 18f),
            range = -18f..18f,
            onChange = {
                onSettingsChange(settings.copy(lowGainDb = it))
            }
        )

        EnvelopeControl(
            name = "MID",
            displayValue = "${settings.midGainDb.toInt()} dB",
            value = settings.midGainDb.coerceIn(-18f, 18f),
            range = -18f..18f,
            onChange = {
                onSettingsChange(settings.copy(midGainDb = it))
            }
        )

        EnvelopeControl(
            name = "MID FREQUENCY",
            displayValue = "${settings.midFrequencyHz.toInt()} Hz",
            value = settings.midFrequencyHz.coerceIn(40f, 10000f),
            range = 40f..10000f,
            onChange = {
                onSettingsChange(settings.copy(midFrequencyHz = it))
            }
        )

        EnvelopeControl(
            name = "HIGH",
            displayValue = "${settings.highGainDb.toInt()} dB",
            value = settings.highGainDb.coerceIn(-18f, 18f),
            range = -18f..18f,
            onChange = {
                onSettingsChange(settings.copy(highGainDb = it))
            }
        )
    }
}

@Composable
private fun TubeOverdrivePanel(
    settings: TubeOverdriveSettings,
    layerName: String,
    onSettingsChange: (TubeOverdriveSettings) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF8A633F), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "TUBE OVERDRIVE • $layerName",
            color = Color(0xFFFFB36B),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(enabled = !settings.enabled))
                }
            ) {
                Text(
                    if (settings.enabled) "TUBE OVERDRIVE: ON"
                    else "TUBE OVERDRIVE: OFF"
                )
            }
        }

        EnvelopeControl(
            name = "DRIVE",
            displayValue = "${(settings.drive.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.drive.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(drive = it))
            }
        )

        EnvelopeControl(
            name = "TONE",
            displayValue = "${(settings.tone.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.tone.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(tone = it))
            }
        )

        EnvelopeControl(
            name = "OUTPUT LEVEL",
            displayValue = "${(settings.level.coerceIn(0f, 2f) * 100).toInt()}%",
            value = settings.level.coerceIn(0f, 2f),
            range = 0f..2f,
            onChange = {
                onSettingsChange(settings.copy(level = it))
            }
        )
    }
}