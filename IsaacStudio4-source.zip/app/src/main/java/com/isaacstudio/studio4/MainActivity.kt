package com.isaacstudio.studio4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.isaacstudio.studio4.audio.SynthEngine
import com.isaacstudio.studio4.audio.AudioOutputEngine
import com.isaacstudio.studio4.audio.Waveform
import com.isaacstudio.studio4.audio.SynthOscillatorSettings
import com.isaacstudio.studio4.audio.SynthFilterSettings
import com.isaacstudio.studio4.audio.SynthModulationSettings
import com.isaacstudio.studio4.audio.SynthFilterMode
import com.isaacstudio.studio4.audio.SynthAnalogCategory
import com.isaacstudio.studio4.audio.SynthDigitalWave
import com.isaacstudio.studio4.audio.SynthOscillatorType
import com.isaacstudio.studio4.audio.instruments.InstrumentType
import com.isaacstudio.studio4.audio.instruments.LayerId
import com.isaacstudio.studio4.audio.instruments.OrganEngine
import com.isaacstudio.studio4.audio.effects.RotarySpeakerProcessor
import com.isaacstudio.studio4.audio.effects.Mod1Settings
import com.isaacstudio.studio4.audio.effects.Mod1Type
import com.isaacstudio.studio4.audio.effects.Mod2Settings
import com.isaacstudio.studio4.audio.effects.Mod2Type
import com.isaacstudio.studio4.audio.effects.DelaySettings
import com.isaacstudio.studio4.audio.effects.DelaySubdivision
import com.isaacstudio.studio4.audio.effects.DelayFilterType
import com.isaacstudio.studio4.audio.effects.DelayFeedbackEffect
import com.isaacstudio.studio4.audio.effects.AmpEqSettings
import com.isaacstudio.studio4.audio.effects.TubeOverdriveSettings
import com.isaacstudio.studio4.audio.effects.AmpModel
import com.isaacstudio.studio4.audio.effects.CompressorSettings
import com.isaacstudio.studio4.audio.effects.CompressorDetector
import com.isaacstudio.studio4.audio.effects.ReverbSettings
import com.isaacstudio.studio4.audio.effects.ReverbType
import com.isaacstudio.studio4.audio.instruments.OrganModel
import com.isaacstudio.studio4.audio.instruments.PianoEngine
import com.isaacstudio.studio4.audio.instruments.PianoSoundModel
import com.isaacstudio.studio4.midi.MidiInput
import com.isaacstudio.studio4.audio.performance.PerformanceSnapshot
import com.isaacstudio.studio4.audio.performance.PerformanceLayer
import com.isaacstudio.studio4.audio.performance.PerformanceStorage

private val WHITE_KEYS = listOf(
    60, 62, 64, 65, 67, 69, 71,
    72, 74, 76, 77, 79, 81, 83, 84
)

private data class BlackKey(
    val note: Int,
    val afterWhiteIndex: Int
)

private val BLACK_KEYS = listOf(
    BlackKey(61, 0),
    BlackKey(63, 1),
    BlackKey(66, 3),
    BlackKey(68, 4),
    BlackKey(70, 5),
    BlackKey(73, 7),
    BlackKey(75, 8),
    BlackKey(78, 10),
    BlackKey(80, 11),
    BlackKey(82, 12)
)
private data class ActiveVoice(
    val source: String,
    val originalNote: Int,
    val layerId: LayerId,
    val voiceId: Long,
    val pressId: Long,
    var keyDown: Boolean = true
)

private data class MidiChannelState(
    var sustainDown: Boolean = false,
    var volume: Int = 127,
    var expression: Int = 127,
    var modulation: Int = 0,
    var pitchBend14: Int = 8192
)

private class LayerZone(
    enabledInitially: Boolean = false
) {
    var enabled by mutableStateOf(enabledInitially)
    var lowNote by mutableStateOf(0)
    var highNote by mutableStateOf(127)
}

private val WHITE_KEY_WIDTH = 42.dp
private val BLACK_KEY_WIDTH = 26.dp

private val DRAWBAR_NAMES = listOf(
    "16'", "5⅓'", "8'", "4'", "2⅔'",
    "2'", "1⅗'", "1⅓'", "1'"
)

class MainActivity : ComponentActivity() {

private val synth = SynthEngine()
private val synth2 = SynthEngine()
private val synth3 = SynthEngine()

private val organ = OrganEngine()
private val organ2 = OrganEngine()

private val piano = PianoEngine()
private val piano2 = PianoEngine()

private val audioOutput = AudioOutputEngine()

    // Stage 6B: persistent performance library and UI state.
    private val performanceStorage by lazy {
        PerformanceStorage(applicationContext)
    }
    private var performanceLibrary by mutableStateOf<List<PerformanceSnapshot>>(emptyList())
    private var performanceName by mutableStateOf("")
    private var selectedPerformanceName by mutableStateOf("")
    private var performanceRecallRevision by mutableIntStateOf(0)

    private var midi: MidiInput? = null
    private var status by mutableStateOf("Starting...")

    private var selectedInstrument by mutableStateOf(InstrumentType.SYNTH)
private var selectedLayer by mutableStateOf(LayerId.SYNTH_1)
    private var drawbars by mutableStateOf(
        listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
    )
private var organModel by mutableStateOf(OrganModel.B3)

private val activeVoices = mutableListOf<ActiveVoice>()
private val midiChannelStates = mutableMapOf<Pair<Int, Int>, MidiChannelState>()

private val layerZones = LayerId.values()
    .associateWith { LayerZone() }
    .toMutableMap()
    .apply {
        getValue(LayerId.SYNTH_1).enabled = true
    }
private val layerVolumes = LayerId.values()
    .associateWith { mutableFloatStateOf(1.0f) }

private val organDrawbarSettings = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith {
        mutableStateMapOf(
            OrganModel.B3 to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0),
OrganModel.B3_BASS to listOf(8, 0, 0, 0, 0, 0, 0, 0, 0),
            OrganModel.VOX to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0),
            OrganModel.FARFISA to listOf(1, 0, 1, 0, 0, 0, 0, 0, 0),
            OrganModel.PIPE_1 to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0),
            OrganModel.PIPE_2 to listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
        )
    }

private val organModelSettings = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(OrganModel.B3) }
private val organVoxFilterMix = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableFloatStateOf(0.5f) }
private val organB3PercussionEnabled = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(false) }

private val organB3PercussionHarmonic = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(2) }

private val organB3PercussionSoft = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(false) }

private val organB3PercussionFastDecay = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(true) }

private val organB3PercussionPolyMode = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableStateOf(false) }

private val organVibratoChorusMode = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableIntStateOf(0) }

private val organRotaryMode = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableIntStateOf(RotarySpeakerProcessor.STOP) }

private val organRotaryDrive = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith { mutableFloatStateOf(0.0f) }

private var nextPressId = 1L

    private var waveform by mutableStateOf(Waveform.SAWTOOTH)
private var volume by mutableStateOf(1.0f)
private var synthLayerVolume by mutableStateOf(1.0f)
private var organLayerVolume by mutableStateOf(1.0f)
private var pianoLayerVolume by mutableStateOf(1.0f)
private var pianoSoundModel by mutableStateOf(PianoSoundModel.STUDIO_GRAND)

private val pianoSoundModels = mapOf(
    LayerId.PIANO_1 to mutableStateOf(PianoSoundModel.STUDIO_GRAND),
    LayerId.PIANO_2 to mutableStateOf(PianoSoundModel.STUDIO_GRAND)
)
private var octave by mutableIntStateOf(0)
private val layerOctaves = LayerId.values()
    .associateWith { mutableIntStateOf(0) }

private val synthOscillatorSettings = mapOf(
    LayerId.SYNTH_1 to mutableStateOf(synth.oscillatorSettings),
    LayerId.SYNTH_2 to mutableStateOf(synth2.oscillatorSettings),
    LayerId.SYNTH_3 to mutableStateOf(synth3.oscillatorSettings)
)

private val synthFilterSettings = mapOf(
    LayerId.SYNTH_1 to mutableStateOf(synth.filterSettings),
    LayerId.SYNTH_2 to mutableStateOf(synth2.filterSettings),
    LayerId.SYNTH_3 to mutableStateOf(synth3.filterSettings)
)

private val synthModulationSettings = mapOf(
    LayerId.SYNTH_1 to mutableStateOf(synth.modulationSettings),
    LayerId.SYNTH_2 to mutableStateOf(synth2.modulationSettings),
    LayerId.SYNTH_3 to mutableStateOf(synth3.modulationSettings)
)
    private var attack by mutableStateOf(0.005f)
    private var decay by mutableStateOf(0.12f)
    private var sustain by mutableStateOf(0.7f)
    private var release by mutableStateOf(0.3f)

    private val layerReverbSettings = LayerId.values().associateWith { layerId ->
        mutableStateOf(audioOutput.layerEffectsRackManager.settingsFor(layerId).reverb)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshPerformanceLibrary()

synth.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_1).enabled
synth2.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_2).enabled
synth3.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_3).enabled

organ.isRenderingEnabled = layerZones.getValue(LayerId.ORGAN_1).enabled
organ2.isRenderingEnabled = layerZones.getValue(LayerId.ORGAN_2).enabled

piano.isRenderingEnabled = layerZones.getValue(LayerId.PIANO_1).enabled
piano2.isRenderingEnabled = layerZones.getValue(LayerId.PIANO_2).enabled

audioOutput.addRenderer(LayerId.SYNTH_1, "Synth 1", synth)
audioOutput.addRenderer(LayerId.SYNTH_2, "Synth 2", synth2)
audioOutput.addRenderer(LayerId.SYNTH_3, "Synth 3", synth3)
audioOutput.addStereoRenderer(LayerId.ORGAN_1, "Organ 1", organ)
audioOutput.addStereoRenderer(LayerId.ORGAN_2, "Organ 2", organ2)
audioOutput.addRenderer(LayerId.PIANO_1, "Piano 1", piano)
audioOutput.addRenderer(LayerId.PIANO_2, "Piano 2", piano2)


audioOutput.start()

organ.setDrawbars(
    organDrawbarSettings
        .getValue(LayerId.ORGAN_1)
        .getValue(OrganModel.B3)
        .toIntArray()
)

organ2.setDrawbars(
    organDrawbarSettings
        .getValue(LayerId.ORGAN_2)
        .getValue(OrganModel.B3)
        .toIntArray()
)

organ.organModel =
    organModelSettings.getValue(LayerId.ORGAN_1).value

organ2.organModel =
    organModelSettings.getValue(LayerId.ORGAN_2).value

organ.voxFilterMix =
    organVoxFilterMix.getValue(LayerId.ORGAN_1).floatValue

organ2.voxFilterMix =
    organVoxFilterMix.getValue(LayerId.ORGAN_2).floatValue

organ.b3PercussionEnabled =
    organB3PercussionEnabled.getValue(LayerId.ORGAN_1).value
organ.b3PercussionHarmonic =
    organB3PercussionHarmonic.getValue(LayerId.ORGAN_1).value
organ.b3PercussionSoft =
    organB3PercussionSoft.getValue(LayerId.ORGAN_1).value
organ.b3PercussionFastDecay =
    organB3PercussionFastDecay.getValue(LayerId.ORGAN_1).value
organ.b3PercussionPolyMode =
    organB3PercussionPolyMode.getValue(LayerId.ORGAN_1).value

organ2.b3PercussionEnabled =
    organB3PercussionEnabled.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionHarmonic =
    organB3PercussionHarmonic.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionSoft =
    organB3PercussionSoft.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionFastDecay =
    organB3PercussionFastDecay.getValue(LayerId.ORGAN_2).value
organ2.b3PercussionPolyMode =
    organB3PercussionPolyMode.getValue(LayerId.ORGAN_2).value
organ.vibratoChorusMode =
    organVibratoChorusMode.getValue(LayerId.ORGAN_1).intValue

organ2.vibratoChorusMode =
    organVibratoChorusMode.getValue(LayerId.ORGAN_2).intValue

organ.rotarySpeaker.mode =
    organRotaryMode.getValue(LayerId.ORGAN_1).intValue
organ.rotarySpeaker.drive =
    organRotaryDrive.getValue(LayerId.ORGAN_1).floatValue

organ2.rotarySpeaker.mode =
    organRotaryMode.getValue(LayerId.ORGAN_2).intValue
organ2.rotarySpeaker.drive =
    organRotaryDrive.getValue(LayerId.ORGAN_2).floatValue

midi = MidiInput(
    context = this,
    onNoteOn = { note, velocity, deviceId, channel ->
        playMidiNote(note, velocity, deviceId, channel)
    },
    onNoteOff = { note, deviceId, channel ->
        releaseMidiNote(note, deviceId, channel)
    },
    onSourceDisconnected = { deviceId ->
        releaseNotesFromDevice(deviceId)
    },
    onStatus = { text ->
        status = text
    },
    onControlChange = { controller, value, deviceId, channel ->
        handleMidiControlChange(controller, value, deviceId, channel)
    },
    onPitchBend = { value14, deviceId, channel ->
        handleMidiPitchBend(value14, deviceId, channel)
    },
    onProgramChange = { program, deviceId, channel ->
        handleMidiProgramChange(program, deviceId, channel)
    }
).also { it.start() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF101116)
                ) {
StudioScreen(
    status = status,
    performanceLibrary = performanceLibrary,
    performanceName = performanceName,
    selectedPerformanceName = selectedPerformanceName,
    performanceRecallRevision = performanceRecallRevision,
    onPerformanceNameChange = { performanceName = it },
    onPerformanceSelect = {
        selectedPerformanceName = it
        performanceName = it
    },
    onPerformanceSave = { savePerformance() },
    onPerformanceRecall = { recallPerformance(it) },
    onPerformanceRename = { oldName, newName ->
        renamePerformance(oldName, newName)
    },
    onPerformanceDelete = { deletePerformance(it) },
    audioOutput = audioOutput,
                        instrument = selectedInstrument,
selectedLayer = selectedLayer,
layerEnabled = layerZones.getValue(selectedLayer).enabled,
layerVolume = layerVolumes.getValue(selectedLayer).floatValue,
lowNote = layerZones.getValue(selectedLayer).lowNote,
highNote = layerZones.getValue(selectedLayer).highNote,

onLayerSelect = { selectLayer(it) },

onLayerEnabledChange = {
    setLayerEnabled(selectedLayer, it)
},

onLayerVolumeChange = {
    setLayerVolume(selectedLayer, it)
},

onLayerLowNoteChange = { value ->
    val zone = layerZones.getValue(selectedLayer)
    zone.lowNote = value.coerceIn(0, zone.highNote)
},

onLayerHighNoteChange = { value ->
    val zone = layerZones.getValue(selectedLayer)
    zone.highNote = value.coerceIn(zone.lowNote, 127)
},
drawbars = drawbars,
organModel = organModel,
voxFilterMix = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organVoxFilterMix.getValue(selectedLayer).floatValue
} else {
    0.5f
},
b3PercussionEnabled = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionEnabled.getValue(selectedLayer).value
} else {
    false
},
b3PercussionHarmonic = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionHarmonic.getValue(selectedLayer).value
} else {
    2
},
b3PercussionSoft = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionSoft.getValue(selectedLayer).value
} else {
    false
},
b3PercussionFastDecay = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionFastDecay.getValue(selectedLayer).value
} else {
    true
},
b3PercussionPolyMode = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organB3PercussionPolyMode.getValue(selectedLayer).value
} else {
    false
},
vibratoChorusMode = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organVibratoChorusMode.getValue(selectedLayer).intValue
} else {
    0
},
rotaryMode = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organRotaryMode.getValue(selectedLayer).intValue
} else {
    RotarySpeakerProcessor.STOP
},
rotaryDrive = if (selectedLayer.instrument == InstrumentType.ORGAN) {
    organRotaryDrive.getValue(selectedLayer).floatValue
} else {
    0.0f
},
onOrganModelChange = { model ->
    organModel = model
    organModelSettings.getValue(selectedLayer).value = model

    val registration = organDrawbarSettings
        .getValue(selectedLayer)
        .getValue(model)

    drawbars = registration

    when (selectedLayer) {
        LayerId.ORGAN_1 -> {
            organ.organModel = model
            organ.setDrawbars(registration.toIntArray())
        }

        LayerId.ORGAN_2 -> {
            organ2.organModel = model
            organ2.setDrawbars(registration.toIntArray())
        }

    else -> Unit
}
},
onVoxFilterMixChange = { value ->
    val mix = value.coerceIn(0.0f, 1.0f)

    organVoxFilterMix.getValue(selectedLayer).floatValue = mix

    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.voxFilterMix = mix
        LayerId.ORGAN_2 -> organ2.voxFilterMix = mix
        else -> Unit
    }
},
onB3PercussionEnabledChange = { value ->
    organB3PercussionEnabled.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionEnabled = value
        LayerId.ORGAN_2 -> organ2.b3PercussionEnabled = value
        else -> Unit
    }
},
onB3PercussionHarmonicChange = { value ->
    organB3PercussionHarmonic.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionHarmonic = value
        LayerId.ORGAN_2 -> organ2.b3PercussionHarmonic = value
        else -> Unit
    }
},
onB3PercussionSoftChange = { value ->
    organB3PercussionSoft.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionSoft = value
        LayerId.ORGAN_2 -> organ2.b3PercussionSoft = value
        else -> Unit
    }
},
onB3PercussionFastDecayChange = { value ->
    organB3PercussionFastDecay.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionFastDecay = value
        LayerId.ORGAN_2 -> organ2.b3PercussionFastDecay = value
        else -> Unit
    }
},
onB3PercussionPolyModeChange = { value ->
    organB3PercussionPolyMode.getValue(selectedLayer).value = value
    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.b3PercussionPolyMode = value
        LayerId.ORGAN_2 -> organ2.b3PercussionPolyMode = value
        else -> Unit
    }
},

onVibratoChorusModeChange = { mode ->
    val safeMode = mode.coerceIn(0, 6)
    organVibratoChorusMode.getValue(selectedLayer).intValue = safeMode

    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.vibratoChorusMode = safeMode
        LayerId.ORGAN_2 -> organ2.vibratoChorusMode = safeMode
        else -> Unit
    }
},

onRotaryModeChange = { mode ->
    val safeMode = mode.coerceIn(
        RotarySpeakerProcessor.STOP,
        RotarySpeakerProcessor.FAST
    )
    organRotaryMode.getValue(selectedLayer).intValue = safeMode

    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.rotarySpeaker.mode = safeMode
        LayerId.ORGAN_2 -> organ2.rotarySpeaker.mode = safeMode
        else -> Unit
    }
},
onRotaryDriveChange = { value ->
    val safeValue = value.coerceIn(0.0f, 1.0f)
    organRotaryDrive.getValue(selectedLayer).floatValue = safeValue

    when (selectedLayer) {
        LayerId.ORGAN_1 -> organ.rotarySpeaker.drive = safeValue
        LayerId.ORGAN_2 -> organ2.rotarySpeaker.drive = safeValue
        else -> Unit
    }
},

waveform = waveform,
oscillatorSettings = if (selectedInstrument == InstrumentType.SYNTH) {
    synthOscillatorSettings.getValue(selectedLayer).value
} else {
    SynthOscillatorSettings()
},
filterSettings = if (selectedInstrument == InstrumentType.SYNTH) {
    synthFilterSettings.getValue(selectedLayer).value
} else {
    SynthFilterSettings()
},
modulationSettings = if (selectedInstrument == InstrumentType.SYNTH) {
    synthModulationSettings.getValue(selectedLayer).value
} else {
    SynthModulationSettings()
},
pianoSoundModel = pianoSoundModel,
                        volume = volume,
synthLayerVolume = synthLayerVolume,
organLayerVolume = organLayerVolume,
pianoLayerVolume = pianoLayerVolume,
                        octave = octave,
                        attack = attack,
                        decay = decay,
                        sustain = sustain,
                        release = release,
                        reverbSettings = layerReverbSettings.getValue(selectedLayer).value,

                        onInstrumentChange = { type ->
                            switchInstrument(type)
                        },

                        onDrawbarChange = { index, level ->
                            val updated = drawbars.toMutableList()
                            updated[index] = level
                            drawbars = updated

organDrawbarSettings
    .getValue(selectedLayer)[organModel] = updated

                            when (selectedLayer) {
                                LayerId.ORGAN_1 ->
                                    organ.setDrawbar(index, level)

                                LayerId.ORGAN_2 ->
                                    organ2.setDrawbar(index, level)

                                else -> Unit
                            }
                        },

                        onWaveformChange = {
                            waveform = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.waveform = it
                                LayerId.SYNTH_2 -> synth2.waveform = it
                                LayerId.SYNTH_3 -> synth3.waveform = it
                                else -> Unit
                            }
                        },

                        onOscillatorSettingsChange = { updated ->
                            val engine = when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth
                                LayerId.SYNTH_2 -> synth2
                                LayerId.SYNTH_3 -> synth3
                                else -> null
                            }

                            if (engine != null) {
                                engine.oscillatorSettings = updated
                                synthOscillatorSettings.getValue(selectedLayer).value = updated
                            }
                        },
                        onFilterSettingsChange = { updated ->
                            val engine = when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth
                                LayerId.SYNTH_2 -> synth2
                                LayerId.SYNTH_3 -> synth3
                                else -> null
                            }

                            if (engine != null) {
                                engine.filterSettings = updated
                                synthFilterSettings.getValue(selectedLayer).value = updated
                            }
                        },
                        onModulationSettingsChange = { updated ->
                            val engine = when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth
                                LayerId.SYNTH_2 -> synth2
                                LayerId.SYNTH_3 -> synth3
                                else -> null
                            }

                            if (engine != null) {
                                engine.modulationSettings = updated
                                synthModulationSettings.getValue(selectedLayer).value = updated
                            }
                        },


                        onVolumeChange = {
                            volume = it
                            audioOutput.masterVolume = it
                        },

                        onSynthLayerVolumeChange = {
                            synthLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onOrganLayerVolumeChange = {
                            organLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onPianoLayerVolumeChange = {
                            pianoLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onPianoSoundModelChange = { model ->
                            pianoSoundModel = model
                            pianoSoundModels.getValue(selectedLayer).value = model

                            when (selectedLayer) {
                                LayerId.PIANO_1 -> piano.soundModel = model
                                LayerId.PIANO_2 -> piano2.soundModel = model
                                else -> Unit
                            }
                        },

onOctaveChange = {
    octave = it
    layerOctaves.getValue(selectedLayer).intValue = it

    when (selectedLayer) {
        LayerId.SYNTH_1 -> synth.transposeSemitones = it * 12
        LayerId.SYNTH_2 -> synth2.transposeSemitones = it * 12
        LayerId.SYNTH_3 -> synth3.transposeSemitones = it * 12
        else -> Unit
    }
},
	
                        onAttackChange = {
                            attack = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.attack = it
                                LayerId.SYNTH_2 -> synth2.attack = it
                                LayerId.SYNTH_3 -> synth3.attack = it
                                else -> Unit
                            }
                        },

                        onDecayChange = {
                            decay = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.decay = it
                                LayerId.SYNTH_2 -> synth2.decay = it
                                LayerId.SYNTH_3 -> synth3.decay = it
                                else -> Unit
                            }
                        },

                        onSustainChange = {
                            sustain = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.sustain = it
                                LayerId.SYNTH_2 -> synth2.sustain = it
                                LayerId.SYNTH_3 -> synth3.sustain = it
                                else -> Unit
                            }
                        },

                        onReleaseChange = {
                            release = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.release = it
                                LayerId.SYNTH_2 -> synth2.release = it
                                LayerId.SYNTH_3 -> synth3.release = it
                                else -> Unit
                            }
                        },

onReverbSettingsChange = { updated ->
    layerReverbSettings.getValue(selectedLayer).value = updated
    val manager = audioOutput.layerEffectsRackManager
    val latest = manager.settingsFor(selectedLayer)
    manager.update(selectedLayer, latest.copy(reverb = updated))
},
onNoteOn = { note, velocity ->
    playNote(note, velocity, "onscreen")
},

onNoteOff = { note ->
    releaseNote(note, "onscreen")
}
                    )
                }
            }
        }
    }

private fun playNote(note: Int, velocity: Float, source: String) {
    val safeNote = note.coerceIn(0, 127)
    val pressId = nextPressId++

    for ((layerId, zone) in layerZones) {
        if (!zone.enabled) continue

        if (safeNote !in zone.lowNote..zone.highNote) continue

val layerOctave = layerOctaves.getValue(layerId).intValue

val playedNote = if (layerId.instrument == InstrumentType.SYNTH) {
    safeNote
} else {
    (safeNote + layerOctave * 12).coerceIn(0, 127)
}

        val voiceId = when (layerId) {
            LayerId.SYNTH_1 -> synth.noteOn(playedNote, velocity)
            LayerId.SYNTH_2 -> synth2.noteOn(playedNote, velocity)
            LayerId.SYNTH_3 -> synth3.noteOn(playedNote, velocity)

            LayerId.ORGAN_1 -> organ.noteOn(playedNote)
            LayerId.ORGAN_2 -> organ2.noteOn(playedNote)

            LayerId.PIANO_1 -> piano.noteOn(playedNote, velocity)
            LayerId.PIANO_2 -> piano2.noteOn(playedNote, velocity)
        }

        if (voiceId != 0L) {
            activeVoices.add(
                ActiveVoice(
                    source,
                    safeNote,
                    layerId,
                    voiceId,
                    pressId
                )
            )
        }
    }
}

private fun releaseNote(note: Int, source: String) {
    val safeNote = note.coerceIn(0, 127)

    val matchingPress = activeVoices.lastOrNull {
        it.source == source && it.originalNote == safeNote
    } ?: return

    val voicesToRelease = activeVoices.filter {
        it.source == source &&
        it.originalNote == safeNote &&
        it.pressId == matchingPress.pressId
    }

    voicesToRelease.forEach {
        releaseVoice(it)
    }

    activeVoices.removeAll(voicesToRelease.toSet())
}

private fun midiLayerForChannel(channel: Int): LayerId? =
    when (channel) {
        0 -> LayerId.SYNTH_1
        1 -> LayerId.SYNTH_2
        2 -> LayerId.SYNTH_3
        3 -> LayerId.ORGAN_1
        4 -> LayerId.ORGAN_2
        5 -> LayerId.PIANO_1
        6 -> LayerId.PIANO_2
        else -> null
    }

private fun playMidiNote(
    note: Int,
    velocity: Float,
    deviceId: Int,
    channel: Int
) {
    val layerId = midiLayerForChannel(channel) ?: return
    val zone = layerZones.getValue(layerId)
    val safeNote = note.coerceIn(0, 127)

    if (!zone.enabled || safeNote !in zone.lowNote..zone.highNote) return

    val source = "midi:$deviceId:$channel"
    val state = midiChannelStates.getOrPut(deviceId to channel) {
        MidiChannelState()
    }

    val layerOctave = layerOctaves.getValue(layerId).intValue
    val playedNote = if (layerId.instrument == InstrumentType.SYNTH) {
        safeNote
    } else {
        (safeNote + layerOctave * 12).coerceIn(0, 127)
    }

    val safeVelocity = velocity.coerceIn(0f, 1f)
    val voiceId = when (layerId) {
        LayerId.SYNTH_1 -> synth.noteOn(playedNote, safeVelocity)
        LayerId.SYNTH_2 -> synth2.noteOn(playedNote, safeVelocity)
        LayerId.SYNTH_3 -> synth3.noteOn(playedNote, safeVelocity)
        LayerId.ORGAN_1 -> organ.noteOn(playedNote)
        LayerId.ORGAN_2 -> organ2.noteOn(playedNote)
        LayerId.PIANO_1 -> piano.noteOn(playedNote, safeVelocity)
        LayerId.PIANO_2 -> piano2.noteOn(playedNote, safeVelocity)
    }

    if (voiceId == 0L) return

    val voice = ActiveVoice(
        source,
        safeNote,
        layerId,
        voiceId,
        nextPressId++
    )
    activeVoices.add(voice)
    applyMidiControls(voice, state)
}

private fun releaseMidiNote(note: Int, deviceId: Int, channel: Int) {
    if (midiLayerForChannel(channel) == null) return

    val source = "midi:$deviceId:$channel"
    val safeNote = note.coerceIn(0, 127)

    val voice = activeVoices.lastOrNull {
        it.source == source &&
        it.originalNote == safeNote &&
        it.keyDown
    } ?: return

    voice.keyDown = false

    val state = midiChannelStates[deviceId to channel]
    if (state?.sustainDown == true) return

    releaseVoice(voice)
    activeVoices.remove(voice)
}

private fun applyMidiControls(
    voice: ActiveVoice,
    state: MidiChannelState
) {
    val normalizedBend =
        ((state.pitchBend14 - 8192) / 8192.0).coerceIn(-1.0, 1.0)
    val bendSemitones = normalizedBend * 2.0
    val gain = (state.volume / 127.0) * (state.expression / 127.0)
    val modulation = state.modulation / 127.0

    when (voice.layerId) {
        LayerId.SYNTH_1 -> synth.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.SYNTH_2 -> synth2.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.SYNTH_3 -> synth3.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.ORGAN_1 -> organ.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.ORGAN_2 -> organ2.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.PIANO_1 -> piano.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
        LayerId.PIANO_2 -> piano2.setMidiControls(
            voice.voiceId, bendSemitones, gain, modulation
        )
    }
}

private fun refreshMidiChannelVoices(
    deviceId: Int,
    channel: Int,
    state: MidiChannelState
) {
    val source = "midi:$deviceId:$channel"
    activeVoices
        .filter { it.source == source }
        .forEach { applyMidiControls(it, state) }
}

private fun handleMidiControlChange(
    controller: Int,
    value: Int,
    deviceId: Int,
    channel: Int
) {
    if (midiLayerForChannel(channel) == null) return

    val state = midiChannelStates.getOrPut(deviceId to channel) {
        MidiChannelState()
    }
    val safeValue = value.coerceIn(0, 127)

    when (controller) {
        64 -> {
            val pedalWasDown = state.sustainDown
            state.sustainDown = safeValue >= 64

            if (pedalWasDown && !state.sustainDown) {
                val source = "midi:$deviceId:$channel"
                val deferred = activeVoices.filter {
                    it.source == source && !it.keyDown
                }
                deferred.forEach { releaseVoice(it) }
                activeVoices.removeAll(deferred.toSet())
            }
            return
        }
        7 -> state.volume = safeValue
        11 -> state.expression = safeValue
        1 -> state.modulation = safeValue
        else -> return
    }

    refreshMidiChannelVoices(deviceId, channel, state)
}

private fun handleMidiPitchBend(
    value14: Int,
    deviceId: Int,
    channel: Int
) {
    if (midiLayerForChannel(channel) == null) return

    val state = midiChannelStates.getOrPut(deviceId to channel) {
        MidiChannelState()
    }
    state.pitchBend14 = value14.coerceIn(0, 16383)
    refreshMidiChannelVoices(deviceId, channel, state)
}

private fun handleMidiProgramChange(
    program: Int,
    deviceId: Int,
    channel: Int
) {
    val layerId = midiLayerForChannel(channel) ?: return

    when (layerId) {
        LayerId.SYNTH_1,
        LayerId.SYNTH_2,
        LayerId.SYNTH_3 -> {
            val waveformValue = when (program) {
                0 -> Waveform.SINE
                1 -> Waveform.TRIANGLE
                2 -> Waveform.SAWTOOTH
                3 -> Waveform.SQUARE
                else -> return
            }
            when (layerId) {
                LayerId.SYNTH_1 -> synth.waveform = waveformValue
                LayerId.SYNTH_2 -> synth2.waveform = waveformValue
                LayerId.SYNTH_3 -> synth3.waveform = waveformValue
                else -> Unit
            }
            if (selectedLayer == layerId) waveform = waveformValue
        }

        LayerId.ORGAN_1,
        LayerId.ORGAN_2 -> {
            val model = when (program) {
                0 -> OrganModel.B3
                1 -> OrganModel.B3_BASS
                2 -> OrganModel.VOX
                3 -> OrganModel.FARFISA
                4 -> OrganModel.PIPE_1
                5 -> OrganModel.PIPE_2
                else -> return
            }

            organModelSettings.getValue(layerId).value = model
            val engine = if (layerId == LayerId.ORGAN_1) organ else organ2
            engine.organModel = model

            if (selectedLayer == layerId) {
                organModel = model
                drawbars = organDrawbarSettings
                    .getValue(layerId)
                    .getValue(model)
            }
        }

        LayerId.PIANO_1,
        LayerId.PIANO_2 -> {
            val model = when (program) {
                0 -> PianoSoundModel.STUDIO_GRAND
                1 -> PianoSoundModel.BRIGHT_GRAND
                2 -> PianoSoundModel.SOFT_GRAND
                3 -> PianoSoundModel.ELECTRIC_PIANO
                else -> return
            }

            pianoSoundModels.getValue(layerId).value = model
            when (layerId) {
                LayerId.PIANO_1 -> piano.soundModel = model
                LayerId.PIANO_2 -> piano2.soundModel = model
                else -> Unit
            }
            if (selectedLayer == layerId) pianoSoundModel = model
        }
    }
}

private fun clearMidiChannelStateForLayer(layerId: LayerId) {
    val channel = when (layerId) {
        LayerId.SYNTH_1 -> 0
        LayerId.SYNTH_2 -> 1
        LayerId.SYNTH_3 -> 2
        LayerId.ORGAN_1 -> 3
        LayerId.ORGAN_2 -> 4
        LayerId.PIANO_1 -> 5
        LayerId.PIANO_2 -> 6
    }
    midiChannelStates.keys.removeAll { it.second == channel }
}

private fun releaseVoice(voice: ActiveVoice) {
    when (voice.layerId) {
        LayerId.SYNTH_1 -> synth.noteOffVoice(voice.voiceId)
        LayerId.SYNTH_2 -> synth2.noteOffVoice(voice.voiceId)
        LayerId.SYNTH_3 -> synth3.noteOffVoice(voice.voiceId)

        LayerId.ORGAN_1 -> organ.noteOffVoice(voice.voiceId)
        LayerId.ORGAN_2 -> organ2.noteOffVoice(voice.voiceId)

        LayerId.PIANO_1 -> piano.noteOffVoice(voice.voiceId)
        LayerId.PIANO_2 -> piano2.noteOffVoice(voice.voiceId)
    }
}
private fun setLayerRenderingEnabled(
    layerId: LayerId,
    enabled: Boolean
) {
    when (layerId) {
        LayerId.SYNTH_1 -> synth.isRenderingEnabled = enabled
        LayerId.SYNTH_2 -> synth2.isRenderingEnabled = enabled
        LayerId.SYNTH_3 -> synth3.isRenderingEnabled = enabled

        LayerId.ORGAN_1 -> organ.isRenderingEnabled = enabled
        LayerId.ORGAN_2 -> organ2.isRenderingEnabled = enabled

        LayerId.PIANO_1 -> piano.isRenderingEnabled = enabled
        LayerId.PIANO_2 -> piano2.isRenderingEnabled = enabled
    }
}

private fun setLayerEnabled(
    layerId: LayerId,
    enabled: Boolean
) {
    layerZones.getValue(layerId).enabled = enabled
    setLayerRenderingEnabled(layerId, enabled)

    if (!enabled) {
        val matchingVoices = activeVoices.filter {
            it.layerId == layerId
        }

        matchingVoices.forEach {
            releaseVoice(it)
        }

        activeVoices.removeAll(matchingVoices.toSet())
        clearMidiChannelStateForLayer(layerId)
    }
}

private fun setLayerVolume(
    layerId: LayerId,
    newVolume: Float
) {
    val safeVolume = newVolume.coerceIn(0f, 1f)

    layerVolumes.getValue(layerId).floatValue = safeVolume

    when (layerId) {
        LayerId.SYNTH_1 -> synth.layerVolume = safeVolume
        LayerId.SYNTH_2 -> synth2.layerVolume = safeVolume
        LayerId.SYNTH_3 -> synth3.layerVolume = safeVolume

        LayerId.ORGAN_1 -> organ.layerVolume = safeVolume
        LayerId.ORGAN_2 -> organ2.layerVolume = safeVolume

        LayerId.PIANO_1 -> piano.layerVolume = safeVolume
        LayerId.PIANO_2 -> piano2.layerVolume = safeVolume
    }
}



private fun refreshPerformanceLibrary() {
    try {
        performanceLibrary = performanceStorage.loadAll()
    } catch (error: Exception) {
        status = "Performance library error: ${error.message ?: "Unable to read"}"
    }
}

private fun savePerformance() {
    val name = performanceName.trim()
    if (name.isEmpty()) {
        status = "Enter a performance name first"
        return
    }
    try {
        performanceStorage.save(capturePerformance(name))
        refreshPerformanceLibrary()
        selectedPerformanceName = name
        performanceName = name
        status = "Saved performance: $name"
    } catch (error: Exception) {
        status = "Save failed: ${error.message ?: "Storage error"}"
    }
}

private fun recallPerformance(name: String) {
    val snapshot = performanceLibrary.firstOrNull {
        it.name.equals(name.trim(), ignoreCase = true)
    }
    if (snapshot == null) {
        status = "Performance not found: $name"
        return
    }
    try {
        restorePerformance(snapshot)
        selectedPerformanceName = snapshot.name
        performanceName = snapshot.name
        status = "Loaded performance: ${snapshot.name}"
    } catch (error: Exception) {
        status = "Load failed: ${error.message ?: "Invalid performance"}"
    }
}

private fun renamePerformance(oldName: String, newName: String) {
    if (newName.trim().isEmpty()) {
        status = "Enter a new performance name"
        return
    }
    try {
        performanceStorage.rename(oldName, newName)
        refreshPerformanceLibrary()
        selectedPerformanceName = newName.trim()
        performanceName = newName.trim()
        status = "Renamed performance to: ${newName.trim()}"
    } catch (error: Exception) {
        status = "Rename failed: ${error.message ?: "Storage error"}"
    }
}

private fun deletePerformance(name: String) {
    if (name.isBlank()) {
        status = "Select a performance to delete"
        return
    }
    try {
        performanceStorage.delete(name)
        refreshPerformanceLibrary()
        selectedPerformanceName = ""
        performanceName = ""
        status = "Deleted performance: $name"
    } catch (error: Exception) {
        status = "Delete failed: ${error.message ?: "Storage error"}"
    }
}

private fun capturePerformance(name: String): PerformanceSnapshot {
    val capturedLayers = LayerId.values().associateWith { layerId ->
        val zone = layerZones.getValue(layerId)
        val common = PerformanceLayer(
            enabled = zone.enabled,
            lowKey = zone.lowNote,
            highKey = zone.highNote,
            volume = layerVolumes.getValue(layerId).floatValue,
            octave = layerOctaves.getValue(layerId).intValue,
            effects = audioOutput.layerEffectsRackManager.settingsFor(layerId)
        )

        when (layerId) {
            LayerId.SYNTH_1,
            LayerId.SYNTH_2,
            LayerId.SYNTH_3 -> {
                val engine = when (layerId) {
                    LayerId.SYNTH_1 -> synth
                    LayerId.SYNTH_2 -> synth2
                    LayerId.SYNTH_3 -> synth3
                    else -> error("Unexpected synth layer")
                }
                common.copy(
                    waveform = engine.waveform,
                    attack = engine.attack,
                    decay = engine.decay,
                    sustain = engine.sustain,
                    release = engine.release,
                    oscillatorSettings = engine.oscillatorSettings,
                    filterSettings = engine.filterSettings,
                    modulationSettings = engine.modulationSettings
                )
            }

            LayerId.ORGAN_1,
            LayerId.ORGAN_2 -> common.copy(
                organModel = organModelSettings.getValue(layerId).value,
                organDrawbars = organDrawbarSettings.getValue(layerId).toMap(),
                organVoxFilterMix = organVoxFilterMix.getValue(layerId).floatValue,
                b3PercussionEnabled = organB3PercussionEnabled.getValue(layerId).value,
                b3PercussionHarmonic = organB3PercussionHarmonic.getValue(layerId).value,
                b3PercussionSoft = organB3PercussionSoft.getValue(layerId).value,
                b3PercussionFastDecay = organB3PercussionFastDecay.getValue(layerId).value,
                b3PercussionPolyMode = organB3PercussionPolyMode.getValue(layerId).value,
                vibratoChorusMode = organVibratoChorusMode.getValue(layerId).intValue,
                rotaryMode = organRotaryMode.getValue(layerId).intValue,
                rotaryDrive = organRotaryDrive.getValue(layerId).floatValue
            )

            LayerId.PIANO_1,
            LayerId.PIANO_2 -> common.copy(
                pianoSoundModel = pianoSoundModels.getValue(layerId).value
            )
        }
    }

    return PerformanceSnapshot(
        name = name,
        selectedLayer = selectedLayer,
        masterVolume = audioOutput.masterVolume,
        layers = capturedLayers
    )
}


private fun restorePerformance(snapshot: PerformanceSnapshot) {
    val previousEnabled = LayerId.values().associateWith { layerId ->
        layerZones.getValue(layerId).enabled
    }

    for (layerId in LayerId.values()) {
        val saved = snapshot.layers[layerId] ?: PerformanceLayer()
        val zone = layerZones.getValue(layerId)

        zone.lowNote = saved.lowKey.coerceIn(0, 127)
        zone.highNote = saved.highKey.coerceIn(zone.lowNote, 127)
        layerOctaves.getValue(layerId).intValue = saved.octave.coerceIn(-4, 4)
        setLayerVolume(layerId, saved.volume)

        when (layerId) {
            LayerId.SYNTH_1,
            LayerId.SYNTH_2,
            LayerId.SYNTH_3 -> {
                val engine = when (layerId) {
                    LayerId.SYNTH_1 -> synth
                    LayerId.SYNTH_2 -> synth2
                    LayerId.SYNTH_3 -> synth3
                    else -> error("Unexpected synth layer")
                }

                engine.waveform = saved.waveform
                engine.attack = saved.attack
                engine.decay = saved.decay
                engine.sustain = saved.sustain
                engine.release = saved.release
                engine.oscillatorSettings = saved.oscillatorSettings
                engine.filterSettings = saved.filterSettings
                engine.modulationSettings = saved.modulationSettings

                synthOscillatorSettings.getValue(layerId).value =
                    saved.oscillatorSettings
                synthFilterSettings.getValue(layerId).value =
                    saved.filterSettings
                synthModulationSettings.getValue(layerId).value =
                    saved.modulationSettings
                engine.transposeSemitones = layerOctaves.getValue(layerId).intValue * 12
            }

            LayerId.ORGAN_1,
            LayerId.ORGAN_2 -> {
                val engine = if (layerId == LayerId.ORGAN_1) organ else organ2
                val registrations = organDrawbarSettings.getValue(layerId)

                for (model in OrganModel.values()) {
                    val fallback = registrations[model] ?: List(9) { 0 }
                    val source = saved.organDrawbars[model] ?: fallback
                    registrations[model] = List(9) { index ->
                        (source.getOrNull(index) ?: fallback.getOrElse(index) { 0 })
                            .coerceIn(0, 8)
                    }
                }

                organModelSettings.getValue(layerId).value = saved.organModel
                organVoxFilterMix.getValue(layerId).floatValue =
                    saved.organVoxFilterMix.coerceIn(0.0f, 1.0f)
                organB3PercussionEnabled.getValue(layerId).value =
                    saved.b3PercussionEnabled
                organB3PercussionHarmonic.getValue(layerId).value =
                    saved.b3PercussionHarmonic.coerceIn(2, 3)
                organB3PercussionSoft.getValue(layerId).value =
                    saved.b3PercussionSoft
                organB3PercussionFastDecay.getValue(layerId).value =
                    saved.b3PercussionFastDecay
                organB3PercussionPolyMode.getValue(layerId).value =
                    saved.b3PercussionPolyMode
                organVibratoChorusMode.getValue(layerId).intValue =
                    saved.vibratoChorusMode.coerceIn(0, 6)
                organRotaryMode.getValue(layerId).intValue =
                    saved.rotaryMode.coerceIn(
                        RotarySpeakerProcessor.STOP,
                        RotarySpeakerProcessor.FAST
                    )
                organRotaryDrive.getValue(layerId).floatValue =
                    saved.rotaryDrive.coerceIn(0.0f, 1.0f)

                engine.organModel = saved.organModel
                engine.setDrawbars(
                    registrations.getValue(saved.organModel).toIntArray()
                )
                engine.voxFilterMix =
                    organVoxFilterMix.getValue(layerId).floatValue
                engine.b3PercussionEnabled = saved.b3PercussionEnabled
                engine.b3PercussionHarmonic = saved.b3PercussionHarmonic.coerceIn(2, 3)
                engine.b3PercussionSoft = saved.b3PercussionSoft
                engine.b3PercussionFastDecay = saved.b3PercussionFastDecay
                engine.b3PercussionPolyMode = saved.b3PercussionPolyMode
                engine.vibratoChorusMode =
                    organVibratoChorusMode.getValue(layerId).intValue
                engine.rotarySpeaker.mode =
                    organRotaryMode.getValue(layerId).intValue
                engine.rotarySpeaker.drive =
                    organRotaryDrive.getValue(layerId).floatValue
            }

            LayerId.PIANO_1,
            LayerId.PIANO_2 -> {
                pianoSoundModels.getValue(layerId).value =
                    saved.pianoSoundModel

                if (layerId == LayerId.PIANO_1) {
                    piano.soundModel = saved.pianoSoundModel
                } else {
                    piano2.soundModel = saved.pianoSoundModel
                }
            }
        }

        audioOutput.layerEffectsRackManager.update(
            layerId,
            saved.effects
        )
        layerReverbSettings.getValue(layerId).value =
            saved.effects.reverb
    }

    volume = snapshot.masterVolume.coerceIn(0.0f, 1.0f)
    audioOutput.masterVolume = volume

    for (layerId in LayerId.values()) {
        val shouldEnable = snapshot.layers[layerId]?.enabled ?: false
        if (previousEnabled.getValue(layerId) != shouldEnable) {
            setLayerEnabled(layerId, shouldEnable)
        }
    }

    selectLayer(snapshot.selectedLayer)
    performanceRecallRevision++
}


private fun selectLayer(layerId: LayerId) {
    selectedLayer = layerId
octave = layerOctaves.getValue(layerId).intValue
    selectedInstrument = layerId.instrument

    when (layerId) {
        LayerId.SYNTH_1,
        LayerId.SYNTH_2,
        LayerId.SYNTH_3 -> {
            val engine = when (layerId) {
                LayerId.SYNTH_1 -> synth
                LayerId.SYNTH_2 -> synth2
                LayerId.SYNTH_3 -> synth3
                else -> return
            }

engine.transposeSemitones = octave * 12
            waveform = engine.waveform
            synthOscillatorSettings.getValue(layerId).value =
                engine.oscillatorSettings
            synthFilterSettings.getValue(layerId).value =
                engine.filterSettings
            synthModulationSettings.getValue(layerId).value =
                engine.modulationSettings
            attack = engine.attack
            decay = engine.decay
            sustain = engine.sustain
            release = engine.release

            synthLayerVolume =
                layerVolumes.getValue(layerId).floatValue
        }

LayerId.ORGAN_1,
LayerId.ORGAN_2 -> {
    organModel =
        organModelSettings.getValue(layerId).value

    drawbars =
        organDrawbarSettings.getValue(layerId)
            .getValue(organModel)

val selectedVoxFilterMix =
    organVoxFilterMix.getValue(layerId).floatValue

val selectedPercussionEnabled =
    organB3PercussionEnabled.getValue(layerId).value
val selectedPercussionHarmonic =
    organB3PercussionHarmonic.getValue(layerId).value
val selectedPercussionSoft =
    organB3PercussionSoft.getValue(layerId).value
val selectedPercussionFastDecay =
    organB3PercussionFastDecay.getValue(layerId).value
val selectedPercussionPolyMode =
    organB3PercussionPolyMode.getValue(layerId).value
val selectedVibratoChorusMode =
    organVibratoChorusMode.getValue(layerId).intValue
val selectedRotaryMode =
    organRotaryMode.getValue(layerId).intValue
val selectedRotaryDrive =
    organRotaryDrive.getValue(layerId).floatValue

val engine = if (layerId == LayerId.ORGAN_1) organ else organ2

engine.organModel = organModel
engine.voxFilterMix = selectedVoxFilterMix
engine.b3PercussionEnabled = selectedPercussionEnabled
engine.b3PercussionHarmonic = selectedPercussionHarmonic
engine.b3PercussionSoft = selectedPercussionSoft
engine.b3PercussionFastDecay = selectedPercussionFastDecay
engine.b3PercussionPolyMode = selectedPercussionPolyMode
engine.vibratoChorusMode = selectedVibratoChorusMode
engine.rotarySpeaker.mode = selectedRotaryMode
engine.rotarySpeaker.drive = selectedRotaryDrive

            organLayerVolume =
                layerVolumes.getValue(layerId).floatValue
        }

        LayerId.PIANO_1,
        LayerId.PIANO_2 -> {
            pianoLayerVolume =
                layerVolumes.getValue(layerId).floatValue

            pianoSoundModel = pianoSoundModels.getValue(layerId).value

            when (layerId) {
                LayerId.PIANO_1 -> piano.soundModel = pianoSoundModel
                LayerId.PIANO_2 -> piano2.soundModel = pianoSoundModel
                else -> Unit
            }
        }
    }
}
private fun releaseAllNotes() {
    activeVoices.toList().forEach {
        releaseVoice(it)
    }

    activeVoices.clear()
    midiChannelStates.clear()
}

private fun releaseNotesFromDevice(deviceId: Int) {
    val sourcePrefix = "midi:$deviceId:"

    val matchingVoices = activeVoices.filter {
        it.source.startsWith(sourcePrefix)
    }

    matchingVoices.forEach {
        releaseVoice(it)
    }

    activeVoices.removeAll(matchingVoices.toSet())
    midiChannelStates.keys.removeAll { it.first == deviceId }
}

private fun switchInstrument(type: InstrumentType) {
    val firstLayer = when (type) {
        InstrumentType.SYNTH -> LayerId.SYNTH_1
        InstrumentType.ORGAN -> LayerId.ORGAN_1
        InstrumentType.PIANO -> LayerId.PIANO_1
    }

    selectLayer(firstLayer)
}

override fun onDestroy() {
    releaseAllNotes()
    midi?.stop()
    audioOutput.stop()
    super.onDestroy()
}
}

@Composable
fun StudioScreen(
    status: String,
    performanceLibrary: List<PerformanceSnapshot>,
    performanceName: String,
    selectedPerformanceName: String,
    performanceRecallRevision: Int,
    onPerformanceNameChange: (String) -> Unit,
    onPerformanceSelect: (String) -> Unit,
    onPerformanceSave: () -> Unit,
    onPerformanceRecall: (String) -> Unit,
    onPerformanceRename: (String, String) -> Unit,
    onPerformanceDelete: (String) -> Unit,
    audioOutput: AudioOutputEngine,
    instrument: InstrumentType,
selectedLayer: LayerId,
layerEnabled: Boolean,
layerVolume: Float,
lowNote: Int,
highNote: Int,
onLayerSelect: (LayerId) -> Unit,
onLayerEnabledChange: (Boolean) -> Unit,
onLayerVolumeChange: (Float) -> Unit,
onLayerLowNoteChange: (Int) -> Unit,
onLayerHighNoteChange: (Int) -> Unit,
    drawbars: List<Int>,
    organModel: OrganModel,
    voxFilterMix: Float,
    onOrganModelChange: (OrganModel) -> Unit,
    onVoxFilterMixChange: (Float) -> Unit,
    b3PercussionEnabled: Boolean,
    b3PercussionHarmonic: Int,
    b3PercussionSoft: Boolean,
    b3PercussionFastDecay: Boolean,
    b3PercussionPolyMode: Boolean,
vibratoChorusMode: Int,
    rotaryMode: Int,
    rotaryDrive: Float,
    onB3PercussionEnabledChange: (Boolean) -> Unit,
    onB3PercussionHarmonicChange: (Int) -> Unit,
    onB3PercussionSoftChange: (Boolean) -> Unit,
    onB3PercussionFastDecayChange: (Boolean) -> Unit,
    onB3PercussionPolyModeChange: (Boolean) -> Unit,
onVibratoChorusModeChange: (Int) -> Unit,
    onRotaryModeChange: (Int) -> Unit,
    onRotaryDriveChange: (Float) -> Unit,
    waveform: Waveform,
    oscillatorSettings: SynthOscillatorSettings,
    filterSettings: SynthFilterSettings,
    modulationSettings: SynthModulationSettings,
    pianoSoundModel: PianoSoundModel,
    onPianoSoundModelChange: (PianoSoundModel) -> Unit,
    volume: Float,
synthLayerVolume: Float,
organLayerVolume: Float,
pianoLayerVolume: Float,
    octave: Int,
    attack: Float,
    decay: Float,
    sustain: Float,
    release: Float,
    onInstrumentChange: (InstrumentType) -> Unit,
    onDrawbarChange: (Int, Int) -> Unit,
    onWaveformChange: (Waveform) -> Unit,
    onOscillatorSettingsChange: (SynthOscillatorSettings) -> Unit,
    onFilterSettingsChange: (SynthFilterSettings) -> Unit,
    onModulationSettingsChange: (SynthModulationSettings) -> Unit,
    onVolumeChange: (Float) -> Unit,
onSynthLayerVolumeChange: (Float) -> Unit,
onOrganLayerVolumeChange: (Float) -> Unit,
onPianoLayerVolumeChange: (Float) -> Unit,
    onOctaveChange: (Int) -> Unit,
    onAttackChange: (Float) -> Unit,
    onDecayChange: (Float) -> Unit,
    onSustainChange: (Float) -> Unit,
    onReleaseChange: (Float) -> Unit,
    reverbSettings: ReverbSettings,
    onReverbSettingsChange: (ReverbSettings) -> Unit,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit
) {
    var diagnostics by remember {
        mutableStateOf(audioOutput.getDiagnostics())
    }

    LaunchedEffect(audioOutput) {
        while (true) {
            diagnostics = audioOutput.getDiagnostics()
            kotlinx.coroutines.delay(500)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "ISAAC STUDIO 4",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White
        )

        Text(
            "STAGE 4D | THREE-INSTRUMENT WORKSTATION",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF91A9FF)
        )

        var performanceMenuExpanded by remember { mutableStateOf(false) }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF1B202B),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "PERFORMANCE MANAGER",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color(0xFFE0B66B)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = performanceName,
                        onValueChange = onPerformanceNameChange,
                        modifier = Modifier.weight(1f),
                        label = { Text("Performance name") },
                        singleLine = true
                    )

                    Box {
                        Button(onClick = {
                            performanceMenuExpanded = true
                        }) {
                            Text("SAVED")
                        }

                        DropdownMenu(
                            expanded = performanceMenuExpanded,
                            onDismissRequest = {
                                performanceMenuExpanded = false
                            }
                        ) {
                            if (performanceLibrary.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No saved performances") },
                                    onClick = {
                                        performanceMenuExpanded = false
                                    }
                                )
                            } else {
                                performanceLibrary.forEach { performance ->
                                    DropdownMenuItem(
                                        text = { Text(performance.name) },
                                        onClick = {
                                            onPerformanceSelect(performance.name)
                                            performanceMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                if (selectedPerformanceName.isNotBlank()) {
                    Text(
                        "Selected: $selectedPerformanceName",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF91A9FF)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onPerformanceSave,
                        enabled = performanceName.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("SAVE")
                    }

                    Button(
                        onClick = {
                            onPerformanceRecall(selectedPerformanceName)
                        },
                        enabled = selectedPerformanceName.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("LOAD")
                    }

                    Button(
                        onClick = {
                            onPerformanceRename(
                                selectedPerformanceName,
                                performanceName
                            )
                        },
                        enabled = selectedPerformanceName.isNotBlank() &&
                            performanceName.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("RENAME")
                    }

                    Button(
                        onClick = {
                            onPerformanceDelete(selectedPerformanceName)
                        },
                        enabled = selectedPerformanceName.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("DELETE")
                    }
                }
            }
        }

        Text(
            status,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFB8C4D9)
        )
Surface(
    modifier = Modifier.fillMaxWidth(),
    color = Color(0xFF1B202B),
    shape = RoundedCornerShape(10.dp)
) {
    Column(
        modifier = Modifier.padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(
            "AUDIO DIAGNOSTICS",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleSmall
        )

        diagnostics.renderers.forEach { renderer ->
            Text(
                "${renderer.name}: AVG ${renderer.averageTimeUs} µs | MAX ${renderer.maximumTimeUs} µs",
                color = Color.White,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Text(
            "TOTAL RENDER: ${diagnostics.totalRenderTimeUs} µs",
            color = Color.White
        )

        Text(
            "MAX BLOCK: ${diagnostics.maximumBlockTimeUs} µs / 11,610 µs",
            color = Color.White
        )

        Text(
            "AUDIOTRACK UNDERRUNS: ${diagnostics.underrunCount}",
            color = Color.White
        )
    }
}

        Spacer(Modifier.height(6.dp))

        Text("INSTRUMENT SELECTOR", color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { onInstrumentChange(InstrumentType.SYNTH) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.SYNTH) "✓ SYNTH" else "SYNTH")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.ORGAN) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.ORGAN) "✓ ORGAN" else "ORGAN")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.PIANO) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.PIANO) "✓ PIANO" else "PIANO")
            }
        }
        // SEVEN-LAYER CONTROL PANEL

        Text(
            "LAYER CONTROL",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LayerId.values()
                .filter { it.instrument == instrument }
                .forEach { layer ->
                    Button(
                        onClick = { onLayerSelect(layer) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            if (selectedLayer == layer) {
                                "✓ ${layer.displayName}"
                            } else {
                                layer.displayName
                            }
                        )
                    }
                }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                selectedLayer.displayName,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall
            )

            Button(
                onClick = {
                    onLayerEnabledChange(!layerEnabled)
                }
            ) {
                Text(
                    if (layerEnabled) "LAYER: ON" else "LAYER: OFF"
                )
            }
        }

        Text(
            "LAYER VOLUME • ${(layerVolume * 100).toInt()}%",
            color = Color.White
        )

        Slider(
            value = layerVolume,
            onValueChange = onLayerVolumeChange,
            valueRange = 0f..1f
        )

        Text(
            "LOW KEY • $lowNote",
            color = Color.White
        )

        Slider(
            value = lowNote.toFloat(),
            onValueChange = {
                onLayerLowNoteChange(it.toInt())
            },
            valueRange = 0f..127f,
            steps = 126
        )

        Text(
            "HIGH KEY • $highNote",
            color = Color.White
        )

        Slider(
            value = highNote.toFloat(),
            onValueChange = {
                onLayerHighNoteChange(it.toInt())
            },
            valueRange = 0f..127f,
            steps = 126
        )

        Text(
            "KEYBOARD ZONE: $lowNote – $highNote",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.bodySmall
        )

        var mod1Settings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).mod1
            )
        }

        Modulation1Panel(
            settings = mod1Settings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                mod1Settings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(mod1 = updated))
            }
        )


        var mod2Settings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).mod2
            )
        }

        Modulation2Panel(
            settings = mod2Settings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                mod2Settings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(mod2 = updated))
            }
        )

        var delaySettings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).delay
            )
        }

        DelayPanel(
            settings = delaySettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                delaySettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(delay = updated))
            }
        )

        var ampEqSettings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).ampEq
            )
        }

        AmpEqPanel(
            settings = ampEqSettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                ampEqSettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(ampEq = updated))
            }
        )

        
        var tubeOverdriveSettings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).tubeOverdrive
            )
        }

        TubeOverdrivePanel(
            settings = tubeOverdriveSettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                tubeOverdriveSettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(tubeOverdrive = updated))
            }
        )

        var compressorSettings by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(
                audioOutput.layerEffectsRackManager
                    .settingsFor(selectedLayer).compressor
            )
        }

        CompressorPanel(
            settings = compressorSettings,
            layerName = selectedLayer.displayName,
            onSettingsChange = { updated ->
                compressorSettings = updated
                val manager = audioOutput.layerEffectsRackManager
                val latest = manager.settingsFor(selectedLayer)
                manager.update(selectedLayer, latest.copy(compressor = updated))
            }
        )

        Spacer(Modifier.height(8.dp))

        var reverbMenuExpanded by remember(selectedLayer, performanceRecallRevision) {
            mutableStateOf(false)
        }

        Column {
            Text(
                "LAYER REVERB • ${selectedLayer.displayName}",
                color = Color.White
            )

            Button(
                onClick = {
                    onReverbSettingsChange(
                        reverbSettings.copy(enabled = !reverbSettings.enabled)
                    )
                }
            ) {
                Text(
                    if (reverbSettings.enabled) "REVERB: ON"
                    else "REVERB: OFF"
                )
            }

            Box {
                Button(
                    onClick = { reverbMenuExpanded = true }
                ) {
                    Text("ALGORITHM: ${reverbSettings.type.name.replace('_', ' ')}")
                }

                DropdownMenu(
                    expanded = reverbMenuExpanded,
                    onDismissRequest = { reverbMenuExpanded = false }
                ) {
                    ReverbType.values().forEach { type ->
                        DropdownMenuItem(
                            text = {
                                Text(type.name.replace('_', ' '))
                            },
                            onClick = {
                                onReverbSettingsChange(
                                    reverbSettings.copy(type = type)
                                )
                                reverbMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Text(
                "ROOM SIZE • ${(reverbSettings.roomSize * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = reverbSettings.roomSize,
                onValueChange = {
                    onReverbSettingsChange(
                        reverbSettings.copy(roomSize = it)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "WET MIX • ${(reverbSettings.wetMix * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = reverbSettings.wetMix,
                onValueChange = {
                    onReverbSettingsChange(
                        reverbSettings.copy(wetMix = it)
                    )
                },
                valueRange = 0f..1f
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        onReverbSettingsChange(
                            reverbSettings.copy(bright = !reverbSettings.bright)
                        )
                    }
                ) {
                    Text(if (reverbSettings.bright) "BRIGHT: ON" else "BRIGHT: OFF")
                }

                Button(
                    onClick = {
                        onReverbSettingsChange(
                            reverbSettings.copy(chorale = !reverbSettings.chorale)
                        )
                    }
                ) {
                    Text(if (reverbSettings.chorale) "CHORALE: ON" else "CHORALE: OFF")
                }
            }
        }

Text(
    "MASTER VOLUME: ${(volume * 100).toInt()}%",
    color = Color.White
)

Slider(
    value = volume,
    onValueChange = onVolumeChange,
    valueRange = 0f..1f
)
        if (instrument == InstrumentType.SYNTH) {
            Text(
                "SYNTHESIZER CONTROLS",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

            Text("WAVEFORM", color = Color.White)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Waveform.values().forEach { type ->
                    Button(
                        onClick = { onWaveformChange(type) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (waveform == type) {
                                "✓ " + type.name.take(3)
                            } else {
                                type.name.take(3)
                            },
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            Text(
                "DUAL OSCILLATOR",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

            Button(
                onClick = {
                    onOscillatorSettingsChange(
                        oscillatorSettings.copy(enabled = !oscillatorSettings.enabled)
                    )
                }
            ) {
                Text(
                    if (oscillatorSettings.enabled) "DUAL OSCILLATOR: ON"
                    else "DUAL OSCILLATOR: OFF"
                )
            }

            if (oscillatorSettings.enabled) {
                var oscillatorACategoryMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorADigitalMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorBCategoryMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorATypeMenuExpanded by remember { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { oscillatorATypeMenuExpanded = true }) {
                        Text("A TYPE: " + oscillatorSettings.oscillatorA.oscillatorType.name.replace('_', ' '))
                    }
                    DropdownMenu(
                        expanded = oscillatorATypeMenuExpanded,
                        onDismissRequest = { oscillatorATypeMenuExpanded = false }
                    ) {
                        listOf(
                            SynthOscillatorType.ANALOG,
                            SynthOscillatorType.FM_HARMONIC,
                            SynthOscillatorType.FM_INHARMONIC,
                            SynthOscillatorType.DIGITAL_WAVE
                        ).forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.name.replace('_', ' ')) },
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                oscillatorType = type
                                            )
                                        )
                                    )
                                    oscillatorATypeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("OSCILLATOR A", color = Color.White)

                if (oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.ANALOG) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Waveform.values().forEach { type ->
                            Button(
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                waveform = type
                                            )
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    if (oscillatorSettings.oscillatorA.waveform == type)
                                        "✓ " + type.name.take(3)
                                    else type.name.take(3),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { oscillatorACategoryMenuExpanded = true }
                        ) {
                            Text(
                                "A MODE: " +
                                    oscillatorSettings.oscillatorA.analogCategory.name
                                        .replace('_', ' ')
                            )
                        }

                        DropdownMenu(
                            expanded = oscillatorACategoryMenuExpanded,
                            onDismissRequest = {
                                oscillatorACategoryMenuExpanded = false
                            }
                        ) {
                            SynthAnalogCategory.values().forEach { category ->
                                DropdownMenuItem(
                                    text = {
                                        Text(category.name.replace('_', ' '))
                                    },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                    analogCategory = category
                                                )
                                            )
                                        )
                                        oscillatorACategoryMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    if (oscillatorSettings.oscillatorA.analogCategory != SynthAnalogCategory.PURE) {
                        Text(
                            "A OSC CTRL • ${(oscillatorSettings.oscillatorA.oscillatorControl * 100).toInt()}%",
                            color = Color.White
                        )
                        Slider(
                            value = oscillatorSettings.oscillatorA.oscillatorControl,
                            onValueChange = { value ->
                                onOscillatorSettingsChange(
                                    oscillatorSettings.copy(
                                        oscillatorA = oscillatorSettings.oscillatorA.copy(
                                            oscillatorControl = value
                                        )
                                    )
                                )
                            },
                            valueRange = 0f..1f
                        )
                    }
                }

                if (oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.FM_HARMONIC ||
                    oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.FM_INHARMONIC) {
                    val fmTypeA = oscillatorSettings.oscillatorA.oscillatorType
                    val harmonicA = fmTypeA == SynthOscillatorType.FM_HARMONIC
                    val ratioA = oscillatorSettings.oscillatorA.fmRatio
                        .coerceIn(if (harmonicA) 1f else 0.1f, 16f)

                    Text(
                        "A FM AMOUNT • ${(oscillatorSettings.oscillatorA.fmAmount * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorA.fmAmount.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorA = oscillatorSettings.oscillatorA.copy(
                                        fmAmount = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )

                    Text(
                        "A FM RATIO • ${if (harmonicA) ratioA.toInt().toString() else "%.1f".format(ratioA)}",
                        color = Color.White
                    )
                    Slider(
                        value = ratioA,
                        onValueChange = { value ->
                            val selectedRatio = if (harmonicA)
                                (value + 0.5f).toInt().toFloat()
                            else value
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorA = oscillatorSettings.oscillatorA.copy(
                                        fmRatio = selectedRatio
                                    )
                                )
                            )
                        },
                        valueRange = if (harmonicA) 1f..16f else 0.1f..16f,
                        steps = if (harmonicA) 14 else 0
                    )
                }

                if (oscillatorSettings.oscillatorA.oscillatorType == SynthOscillatorType.DIGITAL_WAVE) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { oscillatorADigitalMenuExpanded = true }) {
                            Text("A DIGITAL: " + oscillatorSettings.oscillatorA.digitalWave.name)
                        }
                        DropdownMenu(
                            expanded = oscillatorADigitalMenuExpanded,
                            onDismissRequest = { oscillatorADigitalMenuExpanded = false }
                        ) {
                            SynthDigitalWave.values().forEach { wave ->
                                DropdownMenuItem(
                                    text = { Text(wave.name) },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                                    digitalWave = wave
                                                )
                                            )
                                        )
                                        oscillatorADigitalMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Text(
                        "A DIGITAL MORPH • ${(oscillatorSettings.oscillatorA.digitalMorph * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorA.digitalMorph.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorA = oscillatorSettings.oscillatorA.copy(
                                        digitalMorph = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )
                }

                Text(
                    "A SEMITONE • ${oscillatorSettings.oscillatorA.semitone}",
                    color = Color.White
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorA.semitone - 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("−") }

                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorA.semitone + 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("+") }
                }

                Text(
                    "A FINE TUNE • ${oscillatorSettings.oscillatorA.fineTune.toInt()} cents",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorA.fineTune,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    fineTune = value
                                )
                            )
                        )
                    },
                    valueRange = -100f..100f
                )

                Text(
                    "A LEVEL • ${(oscillatorSettings.oscillatorA.level * 100).toInt()}%",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorA.level,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorA = oscillatorSettings.oscillatorA.copy(
                                    level = value
                                )
                            )
                        )
                    },
                    valueRange = 0f..1f
                )

                var oscillatorBTypeMenuExpanded by remember { mutableStateOf(false) }
                var oscillatorBDigitalMenuExpanded by remember { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { oscillatorBTypeMenuExpanded = true }) {
                        Text("B TYPE: " + oscillatorSettings.oscillatorB.oscillatorType.name.replace('_', ' '))
                    }
                    DropdownMenu(
                        expanded = oscillatorBTypeMenuExpanded,
                        onDismissRequest = { oscillatorBTypeMenuExpanded = false }
                    ) {
                        listOf(
                            SynthOscillatorType.ANALOG,
                            SynthOscillatorType.FM_HARMONIC,
                            SynthOscillatorType.FM_INHARMONIC,
                            SynthOscillatorType.DIGITAL_WAVE
                        ).forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.name.replace('_', ' ')) },
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                oscillatorType = type
                                            )
                                        )
                                    )
                                    oscillatorBTypeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("OSCILLATOR B", color = Color.White)

                if (oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.ANALOG) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { oscillatorBCategoryMenuExpanded = true }
                        ) {
                            Text(
                                "B MODE: " +
                                    oscillatorSettings.oscillatorB.analogCategory.name
                                        .replace('_', ' ')
                            )
                        }

                        DropdownMenu(
                            expanded = oscillatorBCategoryMenuExpanded,
                            onDismissRequest = {
                                oscillatorBCategoryMenuExpanded = false
                            }
                        ) {
                            SynthAnalogCategory.values().forEach { category ->
                                DropdownMenuItem(
                                    text = {
                                        Text(category.name.replace('_', ' '))
                                    },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                    analogCategory = category
                                                )
                                            )
                                        )
                                        oscillatorBCategoryMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    if (oscillatorSettings.oscillatorB.analogCategory != SynthAnalogCategory.PURE) {
                        Text(
                            "B OSC CTRL • ${(oscillatorSettings.oscillatorB.oscillatorControl * 100).toInt()}%",
                            color = Color.White
                        )
                        Slider(
                            value = oscillatorSettings.oscillatorB.oscillatorControl,
                            onValueChange = { value ->
                                onOscillatorSettingsChange(
                                    oscillatorSettings.copy(
                                        oscillatorB = oscillatorSettings.oscillatorB.copy(
                                            oscillatorControl = value
                                        )
                                    )
                                )
                            },
                            valueRange = 0f..1f
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Waveform.values().forEach { type ->
                            Button(
                                onClick = {
                                    onOscillatorSettingsChange(
                                        oscillatorSettings.copy(
                                            oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                waveform = type
                                            )
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    if (oscillatorSettings.oscillatorB.waveform == type)
                                        "✓ " + type.name.take(3)
                                    else type.name.take(3),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }

                if (oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.FM_HARMONIC ||
                    oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.FM_INHARMONIC) {
                    val fmTypeB = oscillatorSettings.oscillatorB.oscillatorType
                    val harmonicB = fmTypeB == SynthOscillatorType.FM_HARMONIC
                    val ratioB = oscillatorSettings.oscillatorB.fmRatio
                        .coerceIn(if (harmonicB) 1f else 0.1f, 16f)

                    Text(
                        "B FM AMOUNT • ${(oscillatorSettings.oscillatorB.fmAmount * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorB.fmAmount.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorB = oscillatorSettings.oscillatorB.copy(
                                        fmAmount = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )

                    Text(
                        "B FM RATIO • ${if (harmonicB) ratioB.toInt().toString() else "%.1f".format(ratioB)}",
                        color = Color.White
                    )
                    Slider(
                        value = ratioB,
                        onValueChange = { value ->
                            val selectedRatio = if (harmonicB)
                                (value + 0.5f).toInt().toFloat()
                            else value
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorB = oscillatorSettings.oscillatorB.copy(
                                        fmRatio = selectedRatio
                                    )
                                )
                            )
                        },
                        valueRange = if (harmonicB) 1f..16f else 0.1f..16f,
                        steps = if (harmonicB) 14 else 0
                    )
                }

                if (oscillatorSettings.oscillatorB.oscillatorType == SynthOscillatorType.DIGITAL_WAVE) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { oscillatorBDigitalMenuExpanded = true }) {
                            Text("B DIGITAL: " + oscillatorSettings.oscillatorB.digitalWave.name)
                        }
                        DropdownMenu(
                            expanded = oscillatorBDigitalMenuExpanded,
                            onDismissRequest = { oscillatorBDigitalMenuExpanded = false }
                        ) {
                            SynthDigitalWave.values().forEach { wave ->
                                DropdownMenuItem(
                                    text = { Text(wave.name) },
                                    onClick = {
                                        onOscillatorSettingsChange(
                                            oscillatorSettings.copy(
                                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                                    digitalWave = wave
                                                )
                                            )
                                        )
                                        oscillatorBDigitalMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Text(
                        "B DIGITAL MORPH • ${(oscillatorSettings.oscillatorB.digitalMorph * 100).toInt()}%",
                        color = Color.White
                    )
                    Slider(
                        value = oscillatorSettings.oscillatorB.digitalMorph.coerceIn(0f, 1f),
                        onValueChange = { value ->
                            onOscillatorSettingsChange(
                                oscillatorSettings.copy(
                                    oscillatorB = oscillatorSettings.oscillatorB.copy(
                                        digitalMorph = value
                                    )
                                )
                            )
                        },
                        valueRange = 0f..1f
                    )
                }

                Text(
                    "B SEMITONE • ${oscillatorSettings.oscillatorB.semitone}",
                    color = Color.White
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorB.semitone - 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("−") }

                    Button(onClick = {
                        val value = (oscillatorSettings.oscillatorB.semitone + 1)
                            .coerceIn(-24, 24)
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    semitone = value
                                )
                            )
                        )
                    }) { Text("+") }
                }

                Text(
                    "B FINE TUNE • ${oscillatorSettings.oscillatorB.fineTune.toInt()} cents",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorB.fineTune,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    fineTune = value
                                )
                            )
                        )
                    },
                    valueRange = -100f..100f
                )

                Text(
                    "B LEVEL • ${(oscillatorSettings.oscillatorB.level * 100).toInt()}%",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorB.level,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(
                                oscillatorB = oscillatorSettings.oscillatorB.copy(
                                    level = value
                                )
                            )
                        )
                    },
                    valueRange = 0f..1f
                )

                Text(
                    "OSCILLATOR MIX • ${(oscillatorSettings.oscillatorMix * 100).toInt()}%",
                    color = Color.White
                )
                Slider(
                    value = oscillatorSettings.oscillatorMix,
                    onValueChange = { value ->
                        onOscillatorSettingsChange(
                            oscillatorSettings.copy(oscillatorMix = value)
                        )
                    },
                    valueRange = 0f..1f
                )
            }

            Text(
                "FILTER • ADVANCED SYNTH FILTER",
                color = Color.White
            )

            var filterModeMenuExpanded by remember {
                mutableStateOf(false)
            }

            Button(
                onClick = { filterModeMenuExpanded = true }
            ) {
                Text("MODE • ${filterSettings.mode.name.replace('_', ' ')}")
            }

            DropdownMenu(
                expanded = filterModeMenuExpanded,
                onDismissRequest = { filterModeMenuExpanded = false }
            ) {
                SynthFilterMode.values().forEach { mode ->
                    DropdownMenuItem(
                        text = {
                            Text(mode.name.replace('_', ' '))
                        },
                        onClick = {
                            onFilterSettingsChange(
                                filterSettings.copy(mode = mode)
                            )
                            filterModeMenuExpanded = false
                        }
                    )
                }
            }

            val cutoffLabel = if (filterSettings.cutoffHz >= 1000f) {
                "${(filterSettings.cutoffHz / 100f).toInt() / 10f} kHz"
            } else {
                "${filterSettings.cutoffHz.toInt()} Hz"
            }

            Text(
                "CUTOFF • $cutoffLabel",
                color = Color.White
            )

            Slider(
                value = (
                    kotlin.math.ln(
                        filterSettings.cutoffHz.coerceIn(20f, 20000f) / 20f
                    ) / kotlin.math.ln(1000f)
                ).coerceIn(0f, 1f),
                onValueChange = { value ->
                    val cutoff = 20f * kotlin.math.exp(
                        kotlin.math.ln(1000f) * value
                    )
                    onFilterSettingsChange(
                        filterSettings.copy(cutoffHz = cutoff)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "RESONANCE • ${(filterSettings.resonance * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = filterSettings.resonance,
                onValueChange = { value ->
                    onFilterSettingsChange(
                        filterSettings.copy(resonance = value)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "DRIVE • ${(filterSettings.drive * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = filterSettings.drive,
                onValueChange = { value ->
                    onFilterSettingsChange(
                        filterSettings.copy(drive = value)
                    )
                },
                valueRange = 0f..1f
            )

            Text(
                "FILTER ENVELOPE • INDEPENDENT ADSR",
                color = Color(0xFF91A9FF)
            )

            EnvelopeControl(
                "FILTER ATTACK",
                "${(modulationSettings.filterAttack * 1000).toInt()} ms",
                modulationSettings.filterAttack,
                0.001f..2f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterAttack = value)
                )
            }

            EnvelopeControl(
                "FILTER DECAY",
                "${(modulationSettings.filterDecay * 1000).toInt()} ms",
                modulationSettings.filterDecay,
                0.001f..2f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterDecay = value)
                )
            }

            EnvelopeControl(
                "FILTER SUSTAIN",
                "${(modulationSettings.filterSustain * 100).toInt()}%",
                modulationSettings.filterSustain,
                0f..1f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterSustain = value)
                )
            }

            EnvelopeControl(
                "FILTER RELEASE",
                "${(modulationSettings.filterRelease * 1000).toInt()} ms",
                modulationSettings.filterRelease,
                0.01f..3f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterRelease = value)
                )
            }

            Text(
                "FILTER & VELOCITY MODULATION",
                color = Color(0xFF91A9FF)
            )

            EnvelopeControl(
                "FILTER ENVELOPE AMOUNT",
                "${if (modulationSettings.filterEnvelopeAmountOctaves >= 0f) "+" else ""}${"%.1f".format(modulationSettings.filterEnvelopeAmountOctaves)} oct",
                modulationSettings.filterEnvelopeAmountOctaves,
                -4f..4f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(filterEnvelopeAmountOctaves = value)
                )
            }

            EnvelopeControl(
                "VELOCITY TO VOLUME",
                "${(modulationSettings.velocityToVolume * 100).toInt()}%",
                modulationSettings.velocityToVolume,
                0f..1f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(velocityToVolume = value)
                )
            }

            EnvelopeControl(
                "VELOCITY TO FILTER",
                "${if (modulationSettings.velocityToFilterOctaves >= 0f) "+" else ""}${"%.1f".format(modulationSettings.velocityToFilterOctaves)} oct",
                modulationSettings.velocityToFilterOctaves,
                -4f..4f
            ) { value ->
                onModulationSettingsChange(
                    modulationSettings.copy(velocityToFilterOctaves = value)
                )
            }

            EnvelopeControl(
                "ATTACK",
                "${(attack * 1000).toInt()} ms",
                attack,
                0.001f..2f,
                onAttackChange
            )

            EnvelopeControl(
                "DECAY",
                "${(decay * 1000).toInt()} ms",
                decay,
                0.001f..2f,
                onDecayChange
            )

            EnvelopeControl(
                "SUSTAIN",
                "${(sustain * 100).toInt()}%",
                sustain,
                0f..1f,
                onSustainChange
            )

            EnvelopeControl(
                "RELEASE",
                "${(release * 1000).toInt()} ms",
                release,
                0.01f..3f,
                onReleaseChange
            )
        }

        if (instrument == InstrumentType.ORGAN) {
            val organControlNames = when (organModel) {
                OrganModel.B3 -> DRAWBAR_NAMES

                OrganModel.B3_BASS ->
                    listOf("BASS 16'", "BASS 8'")

OrganModel.VOX ->
    listOf(
        "PARTIAL 1", "PARTIAL 2",
        "PARTIAL 3", "PARTIAL 4",
        "PARTIAL 5", "PARTIAL 6",
        "PARTIAL 7"
    )

                OrganModel.FARFISA ->
                    listOf(
                        "BASS 16'", "STRINGS 16'",
                        "FLUTE 8'", "OBOE 8'",
                        "TRUMPET 8'", "STRINGS 8'",
                        "FLUTE 4'", "STRINGS 4'",
                        "2 2/3'"
                    )

                OrganModel.PIPE_1,
                OrganModel.PIPE_2 -> DRAWBAR_NAMES
            }

            val organControlIndices = when (organModel) {
                OrganModel.B3_BASS ->
                    listOf(0, 2)

OrganModel.VOX ->
    (0..6).toList()

                else ->
                    (0..8).toList()
            }

            Text(
                when (organModel) {
                    OrganModel.B3 -> "B3 TONEWHEEL DRAWBARS"
                    OrganModel.B3_BASS -> "B3 BASS DRAWBARS"
                    OrganModel.VOX -> "VOX DRAWBARS"
                    OrganModel.FARFISA -> "FARFISA REGISTERS"
                    OrganModel.PIPE_1 -> "PIPE 1 REGISTERS"
                    OrganModel.PIPE_2 -> "PIPE 2 REGISTERS"
                },
                color = Color.White,
                style = MaterialTheme.typography.titleMedium
            )

        Text(
            "ORGAN MODEL",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OrganModel.values().forEach { model ->
                Button(
                    onClick = { onOrganModelChange(model) }
                ) {
                    Text(model.displayName)
                }
            }
        }
            organControlNames.forEachIndexed { controlIndex, name ->
                val index = organControlIndices[controlIndex]
                val currentValue = drawbars[index]

                if (organModel == OrganModel.FARFISA) {
                    Button(
                        onClick = {
                            onDrawbarChange(
                                index,
                                if (currentValue >= 5) 0 else 8
                            )
                        }
                    ) {
                        Text(
                            "$name: ${
                                if (currentValue >= 5) "ON" else "OFF"
                            }"
                        )
                    }
                } else {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement =
                                Arrangement.SpaceBetween
                        ) {
                            Text(name, color = Color.White)

                            Text(
                                currentValue.toString(),
                                color = Color(0xFF91A9FF)
                            )
                        }

                        Slider(
                            value = currentValue.toFloat(),
                            onValueChange = {
                                onDrawbarChange(index, it.toInt())
                            },
                            valueRange = 0f..8f,
                            steps = 7
                        )
                    }
                }
            }

Text(
    "VIBRATO / CHORUS",
    color = Color(0xFF91A9FF),
    style = MaterialTheme.typography.titleMedium
)

Row(
    modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(6.dp)
) {
    listOf(
        0 to "OFF",
        1 to "V1",
        2 to "V2",
        3 to "V3",
        4 to "C1",
        5 to "C2",
        6 to "C3"
    ).forEach { (mode, label) ->
        Button(
            onClick = {
                onVibratoChorusModeChange(mode)
            }
        ) {
            Text(
                if (vibratoChorusMode == mode) {
                    "● $label"
                } else {
                    label
                }
            )
        }
    }
}

Text(
    "ROTARY SPEAKER",
    color = Color(0xFF91A9FF),
    style = MaterialTheme.typography.titleMedium
)

Row(
    modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(6.dp)
) {
    listOf(
        RotarySpeakerProcessor.STOP to "STOP",
        RotarySpeakerProcessor.SLOW to "SLOW",
        RotarySpeakerProcessor.FAST to "FAST"
    ).forEach { (mode, label) ->
        Button(
            onClick = {
                onRotaryModeChange(mode)
            }
        ) {
            Text(
                if (rotaryMode == mode) {
                    "● $label"
                } else {
                    label
                }
            )
        }
    }
}

Column {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("DRIVE", color = Color.White)
        Text(
            "${(rotaryDrive * 100).toInt()}%",
            color = Color(0xFF91A9FF)
        )
    }

    Slider(
        value = rotaryDrive,
        onValueChange = onRotaryDriveChange,
        valueRange = 0f..1f
    )
}

if (organModel == OrganModel.VOX) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("FILTER MIX", color = Color.White)

            Text(
                "${(voxFilterMix * 100).toInt()}%",
                color = Color(0xFF91A9FF)
            )
        }

        Slider(
            value = voxFilterMix,
            onValueChange = onVoxFilterMixChange,
            valueRange = 0f..1f
        )
    }
}
if (organModel == OrganModel.B3) {
    Column {
        Text(
            "B3 PERCUSSION",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("PERCUSSION", color = Color.White)
            Button(
                onClick = {
                    onB3PercussionEnabledChange(!b3PercussionEnabled)
                }
            ) {
                Text(if (b3PercussionEnabled) "ON" else "OFF")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("HARMONIC", color = Color.White)
            Row {
                Button(
                    onClick = { onB3PercussionHarmonicChange(2) }
                ) {
                    Text("2nd")
                }
                Button(
                    onClick = { onB3PercussionHarmonicChange(3) }
                ) {
                    Text("3rd")
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("VOLUME", color = Color.White)
            Row {
                Button(
                    onClick = { onB3PercussionSoftChange(true) }
                ) {
                    Text("SOFT")
                }
                Button(
                    onClick = { onB3PercussionSoftChange(false) }
                ) {
                    Text("NORMAL")
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("DECAY", color = Color.White)
            Row {
                Button(
                    onClick = { onB3PercussionFastDecayChange(true) }
                ) {
                    Text("FAST")
                }
                Button(
                    onClick = { onB3PercussionFastDecayChange(false) }
                ) {
                    Text("SLOW")
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("TRIGGER MODE", color = Color.White)
            Row {
                Button(
                    onClick = { onB3PercussionPolyModeChange(false) }
                ) {
                    Text("SINGLE")
                }
                Button(
                    onClick = { onB3PercussionPolyModeChange(true) }
                ) {
                    Text("POLY")
                }
            }
        }
    }
}
}
if (instrument == InstrumentType.PIANO) {
    Text(
        "PIANO MODEL",
        color = Color(0xFF91A9FF),
        style = MaterialTheme.typography.titleMedium
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        PianoSoundModel.values().forEach { model ->
            Button(
                onClick = { onPianoSoundModelChange(model) }
            ) {
                Text(
                    if (model == pianoSoundModel) {
                        "✓ ${model.displayName}"
                    } else {
                        model.displayName
                    }
                )
            }
        }
    }
}

            Text(
"LAYER OCTAVE CONTROLS",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("OCTAVE", color = Color.White)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        onOctaveChange((octave - 1).coerceAtLeast(-2))
                    }
                ) {
                    Text("−")
                }

                Text(
                    text = if (octave > 0) "+$octave" else octave.toString(),
                    color = Color(0xFF91A9FF),
                    modifier = Modifier.padding(horizontal = 14.dp)
                )

                Button(
                    onClick = {
                        onOctaveChange((octave + 1).coerceAtMost(2))
                    }
                ) {
                    Text("+")
                }
            }
        }
        Spacer(Modifier.height(8.dp))

        Text(
            "TWO-OCTAVE KEYBOARD",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall
        )

        Text(
            "Swipe left or right to explore the keys",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .width(WHITE_KEY_WIDTH * WHITE_KEYS.size)
                    .height(220.dp)
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    WHITE_KEYS.forEach { note ->
                        PianoKey(
                            note = note,
                            label = when (note) {
                                60 -> "C${4 + octave}"
                                72 -> "C${5 + octave}"
                                84 -> "C${6 + octave}"
                                else -> ""
                            },
                            black = false,
                            onNoteOn = onNoteOn,
                            onNoteOff = onNoteOff,
                            modifier = Modifier
                                .width(WHITE_KEY_WIDTH)
                                .fillMaxHeight()
                        )
                    }
                }

                BLACK_KEYS.forEach { key ->
                    PianoKey(
                        note = key.note,
                        label = "",
                        black = true,
                        onNoteOn = onNoteOn,
                        onNoteOff = onNoteOff,
                        modifier = Modifier
                            .offset(
                                x = WHITE_KEY_WIDTH *
                                    (key.afterWhiteIndex + 1) -
                                    BLACK_KEY_WIDTH / 2
                            )
                            .width(BLACK_KEY_WIDTH)
                            .height(130.dp)
                    )
                }
            }
        }

        Text(
            "ISAAC STUDIO 4 • DIGITAL INSTRUMENT",
            color = Color(0xFF77829A),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun Modulation1Panel(
    settings: Mod1Settings,
    layerName: String,
    onSettingsChange: (Mod1Settings) -> Unit
) {
    var typeMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "MODULATION 1 • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    val enabling = !settings.enabled
                    onSettingsChange(
                        settings.copy(
                            enabled = enabling,
                            type = if (
                                enabling && settings.type == Mod1Type.OFF
                            ) Mod1Type.TREMOLO else settings.type
                        )
                    )
                }
            ) {
                Text(if (settings.enabled) "EFFECT: ON" else "EFFECT: OFF")
            }
        }

        Text("EFFECT TYPE", color = Color.White)

        Button(onClick = { typeMenuExpanded = true }) {
            Text(
                if (settings.type == Mod1Type.OFF) "SELECT EFFECT"
                else settings.type.name.replace('_', ' ')
            )
        }

        DropdownMenu(
            expanded = typeMenuExpanded,
            onDismissRequest = { typeMenuExpanded = false }
        ) {
            Mod1Type.values().forEach { type ->
                DropdownMenuItem(
                    text = {
                        Text(
                            if (type == Mod1Type.OFF) "OFF"
                            else type.name.replace('_', ' ')
                        )
                    },
                    onClick = {
                        onSettingsChange(
                            settings.copy(
                                type = type,
                                enabled = if (type == Mod1Type.OFF) {
                                    false
                                } else {
                                    settings.enabled
                                }
                            )
                        )
                        typeMenuExpanded = false
                    }
                )
            }
        }

        EnvelopeControl(
            name = "RATE",
            displayValue = "${(settings.rate * 100).toInt()}%",
            value = settings.rate,
            range = 0f..1f,
            onChange = { onSettingsChange(settings.copy(rate = it)) }
        )

        EnvelopeControl(
            name = "AMOUNT",
            displayValue = "${(settings.amount * 100).toInt()}%",
            value = settings.amount,
            range = 0f..1f,
            onChange = { onSettingsChange(settings.copy(amount = it)) }
        )

        EnvelopeControl(
            name = "MIX",
            displayValue = "${(settings.mix * 100).toInt()}%",
            value = settings.mix,
            range = 0f..1f,
            onChange = { onSettingsChange(settings.copy(mix = it)) }
        )

        if (
            settings.type == Mod1Type.RING_MOD ||
            settings.type == Mod1Type.WAH ||
            settings.type == Mod1Type.AUTO_WAH
        ) {
            EnvelopeControl(
                name = "FREQUENCY",
                displayValue = "${(settings.frequency * 100).toInt()}%",
                value = settings.frequency,
                range = 0f..1f,
                onChange = {
                    onSettingsChange(settings.copy(frequency = it))
                }
            )

            EnvelopeControl(
                name = "RESONANCE",
                displayValue = "${(settings.resonance * 100).toInt()}%",
                value = settings.resonance,
                range = 0f..1f,
                onChange = {
                    onSettingsChange(settings.copy(resonance = it))
                }
            )
        }
    }
}

@Composable
private fun Modulation2Panel(
    settings: Mod2Settings,
    layerName: String,
    onSettingsChange: (Mod2Settings) -> Unit
) {
    var typeMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "MODULATION 2 • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)

            Button(
                onClick = {
                    val enabling = !settings.enabled
                    onSettingsChange(
                        settings.copy(
                            enabled = enabling,
                            type = if (
                                enabling && settings.type == Mod2Type.OFF
                            ) Mod2Type.CHORUS else settings.type
                        )
                    )
                }
            ) {
                Text(
                    if (settings.enabled) "EFFECT: ON"
                    else "EFFECT: OFF"
                )
            }
        }

        Text("EFFECT TYPE", color = Color.White)

        Button(onClick = { typeMenuExpanded = true }) {
            Text(
                if (settings.type == Mod2Type.OFF) "SELECT EFFECT"
                else settings.type.name.replace('_', ' ')
            )
        }

        DropdownMenu(
            expanded = typeMenuExpanded,
            onDismissRequest = { typeMenuExpanded = false }
        ) {
            Mod2Type.values().forEach { type ->
                DropdownMenuItem(
                    text = {
                        Text(
                            if (type == Mod2Type.OFF) "OFF"
                            else type.name.replace('_', ' ')
                        )
                    },
                    onClick = {
                        onSettingsChange(
                            settings.copy(
                                type = type,
                                enabled = if (type == Mod2Type.OFF) {
                                    false
                                } else {
                                    settings.enabled
                                }
                            )
                        )
                        typeMenuExpanded = false
                    }
                )
            }
        }

        EnvelopeControl(
            name = "RATE",
            displayValue = "${(settings.rate * 100).toInt()}%",
            value = settings.rate,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(rate = it))
            }
        )

        EnvelopeControl(
            name = "AMOUNT",
            displayValue = "${(settings.amount * 100).toInt()}%",
            value = settings.amount,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(amount = it))
            }
        )

        EnvelopeControl(
            name = "MIX",
            displayValue = "${(settings.mix * 100).toInt()}%",
            value = settings.mix,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(mix = it))
            }
        )

        if (
            settings.type == Mod2Type.CHORUS ||
            settings.type == Mod2Type.FLANGER ||
            settings.type == Mod2Type.SPIN
        ) {
            EnvelopeControl(
                name = "FEEDBACK",
                displayValue = "${(settings.feedback * 100).toInt()}%",
                value = settings.feedback,
                range = 0f..1f,
                onChange = {
                    onSettingsChange(settings.copy(feedback = it))
                }
            )
        }
    }
}

@Composable
private fun DelayPanel(
    settings: DelaySettings,
    layerName: String,
    onSettingsChange: (DelaySettings) -> Unit
) {
    var filterMenuExpanded by remember { mutableStateOf(false) }
    var feedbackMenuExpanded by remember { mutableStateOf(false) }
    var subdivisionMenuExpanded by remember { mutableStateOf(false) }
    var lastTapTimeMs by remember(layerName) { mutableStateOf(0L) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "DELAY • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)

            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(enabled = !settings.enabled)
                    )
                }
            ) {
                Text(if (settings.enabled) "DELAY: ON" else "DELAY: OFF")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TIME MODE", color = Color.White)

            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(tempoSync = !settings.tempoSync)
                    )
                }
            ) {
                Text(
                    if (settings.tempoSync) "TEMPO SYNC"
                    else "FREE TIME"
                )
            }
        }

        if (settings.tempoSync) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    EnvelopeControl(
                        name = "TEMPO",
                        displayValue = "${settings.tempoBpm.toInt()} BPM",
                        value = settings.tempoBpm,
                        range = 40f..240f,
                        onChange = {
                            onSettingsChange(settings.copy(tempoBpm = it))
                        }
                    )
                }

                Button(
                    onClick = {
                        val now = android.os.SystemClock.elapsedRealtime()
                        val previous = lastTapTimeMs

                        if (previous > 0L) {
                            val interval = now - previous

                            if (interval in 250L..1500L) {
                                val bpm = (60000f / interval.toFloat())
                                    .coerceIn(40f, 240f)

                                onSettingsChange(
                                    settings.copy(
                                        tempoBpm = bpm,
                                        tempoSync = true
                                    )
                                )
                            }
                        }

                        lastTapTimeMs = now
                    }
                ) {
                    Text(
                        if (lastTapTimeMs == 0L) "TAP TEMPO"
                        else "TAP AGAIN"
                    )
                }
            }

            Text("NOTE SUBDIVISION", color = Color.White)

            Button(
                onClick = { subdivisionMenuExpanded = true }
            ) {
                Text(settings.subdivision.displayName)
            }

            DropdownMenu(
                expanded = subdivisionMenuExpanded,
                onDismissRequest = {
                    subdivisionMenuExpanded = false
                }
            ) {
                DelaySubdivision.values().forEach { subdivision ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                "${subdivision.displayName} • " +
                                    subdivision.name.replace('_', ' ')
                            )
                        },
                        onClick = {
                            onSettingsChange(
                                settings.copy(subdivision = subdivision)
                            )
                            subdivisionMenuExpanded = false
                        }
                    )
                }
            }
        } else {
            EnvelopeControl(
                name = "DELAY TIME",
                displayValue = "${settings.timeMs.toInt()} ms",
                value = settings.timeMs.coerceIn(40f, 2000f),
                range = 40f..2000f,
                onChange = {
                    onSettingsChange(settings.copy(timeMs = it))
                }
            )
        }

        EnvelopeControl(
            name = "FEEDBACK",
            displayValue = "${(settings.feedback * 100).toInt()}%",
            value = settings.feedback.coerceIn(0f, 0.92f),
            range = 0f..0.92f,
            onChange = {
                onSettingsChange(settings.copy(feedback = it))
            }
        )

        EnvelopeControl(
            name = "WET MIX",
            displayValue = "${(settings.mix * 100).toInt()}%",
            value = settings.mix,
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(mix = it))
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("PING-PONG STEREO", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(pingPong = !settings.pingPong)
                    )
                }
            ) {
                Text(if (settings.pingPong) "ON" else "OFF")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ANALOG CHARACTER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(
                        settings.copy(analogMode = !settings.analogMode)
                    )
                }
            ) {
                Text(if (settings.analogMode) "ON" else "OFF")
            }
        }

        Text("FEEDBACK FILTER", color = Color.White)

        Button(onClick = { filterMenuExpanded = true }) {
            Text(settings.filter.name.replace('_', ' '))
        }

        DropdownMenu(
            expanded = filterMenuExpanded,
            onDismissRequest = { filterMenuExpanded = false }
        ) {
            DelayFilterType.values().forEach { filter ->
                DropdownMenuItem(
                    text = {
                        Text(filter.name.replace('_', ' '))
                    },
                    onClick = {
                        onSettingsChange(settings.copy(filter = filter))
                        filterMenuExpanded = false
                    }
                )
            }
        }

        Text("FEEDBACK VARIATION", color = Color.White)

        Button(onClick = { feedbackMenuExpanded = true }) {
            Text(settings.feedbackEffect.name.replace('_', ' '))
        }

        DropdownMenu(
            expanded = feedbackMenuExpanded,
            onDismissRequest = { feedbackMenuExpanded = false }
        ) {
            DelayFeedbackEffect.values().forEach { effect ->
                DropdownMenuItem(
                    text = {
                        Text(effect.name.replace('_', ' '))
                    },
                    onClick = {
                        onSettingsChange(
                            settings.copy(feedbackEffect = effect)
                        )
                        feedbackMenuExpanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun EnvelopeControl(
    name: String,
    displayValue: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(name, color = Color.White)
            Text(displayValue, color = Color(0xFF91A9FF))
        }

        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range
        )
    }
}

@Composable
private fun PianoKey(
    note: Int,
    label: String,
    black: Boolean,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    val keyColor = when {
        black && pressed -> Color(0xFF526DAA)
        black -> Color(0xFF171923)
        pressed -> Color(0xFFB0C4FF)
        else -> Color.White
    }

    val shape = RoundedCornerShape(
        bottomStart = 5.dp,
        bottomEnd = 5.dp
    )

    Box(
        modifier = modifier
            .background(keyColor, shape)
            .border(
                width = 0.7.dp,
                color = if (black) Color.Black else Color(0xFFB8B8B8),
                shape = shape
            )
            .pointerInput(note) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onNoteOn(note, 0.8f)
                        tryAwaitRelease()
                        pressed = false
                        onNoteOff(note)
                    }
                )
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        if (label.isNotEmpty()) {
            Text(
                text = label,
                color = Color.DarkGray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}
@Composable
private fun CompressorPanel(
    settings: CompressorSettings,
    layerName: String,
    onSettingsChange: (CompressorSettings) -> Unit
) {
    var detectorMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "COMPRESSOR • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(enabled = !settings.enabled))
                }
            ) {
                Text(if (settings.enabled) "COMPRESSOR: ON" else "COMPRESSOR: OFF")
            }
        }

        Text("DETECTOR MODE", color = Color.White)
        Button(onClick = { detectorMenuExpanded = true }) {
            Text(settings.detector.name)
        }

        DropdownMenu(
            expanded = detectorMenuExpanded,
            onDismissRequest = { detectorMenuExpanded = false }
        ) {
            CompressorDetector.values().forEach { detector ->
                DropdownMenuItem(
                    text = { Text(detector.name) },
                    onClick = {
                        onSettingsChange(settings.copy(detector = detector))
                        detectorMenuExpanded = false
                    }
                )
            }
        }

        EnvelopeControl(
            name = "COMPRESSION AMOUNT",
            displayValue = "${(settings.amount.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.amount.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(amount = it))
            }
        )

        EnvelopeControl(
            name = "THRESHOLD",
            displayValue = "${settings.thresholdDb.toInt()} dB",
            value = settings.thresholdDb.coerceIn(-60f, 0f),
            range = -60f..0f,
            onChange = {
                onSettingsChange(settings.copy(thresholdDb = it))
            }
        )

        EnvelopeControl(
            name = "RATIO",
            displayValue = String.format("%.1f:1", settings.ratio),
            value = settings.ratio.coerceIn(1f, 20f),
            range = 1f..20f,
            onChange = {
                onSettingsChange(settings.copy(ratio = it))
            }
        )

        EnvelopeControl(
            name = "ATTACK",
            displayValue = String.format("%.1f ms", settings.attackMs),
            value = settings.attackMs.coerceIn(0.1f, 100f),
            range = 0.1f..100f,
            onChange = {
                onSettingsChange(settings.copy(attackMs = it))
            }
        )

        EnvelopeControl(
            name = "RELEASE",
            displayValue = "${settings.releaseMs.toInt()} ms",
            value = settings.releaseMs.coerceIn(10f, 1000f),
            range = 10f..1000f,
            onChange = {
                onSettingsChange(settings.copy(releaseMs = it))
            }
        )

        EnvelopeControl(
            name = "SOFT KNEE",
            displayValue = "${settings.kneeDb.toInt()} dB",
            value = settings.kneeDb.coerceIn(0f, 24f),
            range = 0f..24f,
            onChange = {
                onSettingsChange(settings.copy(kneeDb = it))
            }
        )

        EnvelopeControl(
            name = "MAKEUP GAIN",
            displayValue = String.format("%+.1f dB", settings.makeupGainDb),
            value = settings.makeupGainDb.coerceIn(-12f, 24f),
            range = -12f..24f,
            onChange = {
                onSettingsChange(settings.copy(makeupGainDb = it))
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("FAST MODE", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(fast = !settings.fast))
                }
            ) {
                Text(if (settings.fast) "FAST: ON" else "FAST: OFF")
            }
        }
    }
}

@Composable
private fun AmpEqPanel(
    settings: AmpEqSettings,
    layerName: String,
    onSettingsChange: (AmpEqSettings) -> Unit
) {
    var ampMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF354568), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "AMP / SPEAKER • $layerName",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(enabled = !settings.enabled))
                }
            ) {
                Text(if (settings.enabled) "AMP / EQ: ON" else "AMP / EQ: OFF")
            }
        }

        Text("AMP MODEL", color = Color.White)

        Button(onClick = { ampMenuExpanded = true }) {
            Text(settings.ampModel.name.replace('_', ' '))
        }

        DropdownMenu(
            expanded = ampMenuExpanded,
            onDismissRequest = { ampMenuExpanded = false }
        ) {
            AmpModel.values().forEach { model ->
                DropdownMenuItem(
                    text = { Text(model.name.replace('_', ' ')) },
                    onClick = {
                        onSettingsChange(settings.copy(ampModel = model))
                        ampMenuExpanded = false
                    }
                )
            }
        }

        EnvelopeControl(
            name = "DRIVE",
            displayValue = "${(settings.drive.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.drive.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(drive = it))
            }
        )

        Text("SPEAKER FILTERS", color = Color(0xFF91A9FF))

        EnvelopeControl(
            name = "HIGH PASS",
            displayValue = "${settings.highPassHz.toInt()} Hz",
            value = settings.highPassHz.coerceIn(20f, 1000f),
            range = 20f..1000f,
            onChange = {
                onSettingsChange(settings.copy(highPassHz = it))
            }
        )

        EnvelopeControl(
            name = "LOW PASS",
            displayValue = "${settings.lowPassHz.toInt()} Hz",
            value = settings.lowPassHz.coerceIn(1000f, 20000f),
            range = 1000f..20000f,
            onChange = {
                onSettingsChange(settings.copy(lowPassHz = it))
            }
        )

        Text("THREE-BAND EQUALIZER", color = Color(0xFF91A9FF))

        EnvelopeControl(
            name = "LOW",
            displayValue = "${settings.lowGainDb.toInt()} dB",
            value = settings.lowGainDb.coerceIn(-18f, 18f),
            range = -18f..18f,
            onChange = {
                onSettingsChange(settings.copy(lowGainDb = it))
            }
        )

        EnvelopeControl(
            name = "MID",
            displayValue = "${settings.midGainDb.toInt()} dB",
            value = settings.midGainDb.coerceIn(-18f, 18f),
            range = -18f..18f,
            onChange = {
                onSettingsChange(settings.copy(midGainDb = it))
            }
        )

        EnvelopeControl(
            name = "MID FREQUENCY",
            displayValue = "${settings.midFrequencyHz.toInt()} Hz",
            value = settings.midFrequencyHz.coerceIn(40f, 10000f),
            range = 40f..10000f,
            onChange = {
                onSettingsChange(settings.copy(midFrequencyHz = it))
            }
        )

        EnvelopeControl(
            name = "HIGH",
            displayValue = "${settings.highGainDb.toInt()} dB",
            value = settings.highGainDb.coerceIn(-18f, 18f),
            range = -18f..18f,
            onChange = {
                onSettingsChange(settings.copy(highGainDb = it))
            }
        )
    }
}

@Composable
private fun TubeOverdrivePanel(
    settings: TubeOverdriveSettings,
    layerName: String,
    onSettingsChange: (TubeOverdriveSettings) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171D2B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF8A633F), RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            "TUBE OVERDRIVE • $layerName",
            color = Color(0xFFFFB36B),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EFFECT POWER", color = Color.White)
            Button(
                onClick = {
                    onSettingsChange(settings.copy(enabled = !settings.enabled))
                }
            ) {
                Text(
                    if (settings.enabled) "TUBE OVERDRIVE: ON"
                    else "TUBE OVERDRIVE: OFF"
                )
            }
        }

        EnvelopeControl(
            name = "DRIVE",
            displayValue = "${(settings.drive.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.drive.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(drive = it))
            }
        )

        EnvelopeControl(
            name = "TONE",
            displayValue = "${(settings.tone.coerceIn(0f, 1f) * 100).toInt()}%",
            value = settings.tone.coerceIn(0f, 1f),
            range = 0f..1f,
            onChange = {
                onSettingsChange(settings.copy(tone = it))
            }
        )

        EnvelopeControl(
            name = "OUTPUT LEVEL",
            displayValue = "${(settings.level.coerceIn(0f, 2f) * 100).toInt()}%",
            value = settings.level.coerceIn(0f, 2f),
            range = 0f..2f,
            onChange = {
                onSettingsChange(settings.copy(level = it))
            }
        )
    }
}

