package com.isaacstudio.studio4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.isaacstudio.studio4.audio.SynthEngine
import com.isaacstudio.studio4.audio.Waveform
import com.isaacstudio.studio4.audio.instruments.InstrumentType
import com.isaacstudio.studio4.audio.instruments.OrganEngine
import com.isaacstudio.studio4.audio.instruments.PianoEngine
import com.isaacstudio.studio4.midi.MidiInput

private val WHITE_KEYS = listOf(
    60, 62, 64, 65, 67, 69, 71,
    72, 74, 76, 77, 79, 81, 83, 84
)

private data class BlackKey(
    val note: Int,
    val afterWhiteIndex: Int
)

private val BLACK_KEYS = listOf(
    BlackKey(61, 0),
    BlackKey(63, 1),
    BlackKey(66, 3),
    BlackKey(68, 4),
    BlackKey(70, 5),
    BlackKey(73, 7),
    BlackKey(75, 8),
    BlackKey(78, 10),
    BlackKey(80, 11),
    BlackKey(82, 12)
)

private val WHITE_KEY_WIDTH = 42.dp
private val BLACK_KEY_WIDTH = 26.dp

private val DRAWBAR_NAMES = listOf(
    "16'", "5⅓'", "8'", "4'", "2⅔'",
    "2'", "1⅗'", "1⅓'", "1'"
)

class MainActivity : ComponentActivity() {

    private val synth = SynthEngine()
    private val organ = OrganEngine()
    private val piano = PianoEngine()

    private var midi: MidiInput? = null
    private var status by mutableStateOf("Starting...")

    private var selectedInstrument by mutableStateOf(InstrumentType.SYNTH)
    private var drawbars by mutableStateOf(
        listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
    )

    private val activeNotes = mutableMapOf<Int, Int>()

    private var waveform by mutableStateOf(Waveform.SAWTOOTH)
    private var volume by mutableStateOf(0.7f)
    private var octave by mutableStateOf(0)
    private var attack by mutableStateOf(0.005f)
    private var decay by mutableStateOf(0.12f)
    private var sustain by mutableStateOf(0.7f)
    private var release by mutableStateOf(0.3f)

    private var reverbEnabled by mutableStateOf(false)
    private var reverbRoomSize by mutableStateOf(0.5f)
    private var reverbWetMix by mutableStateOf(0.25f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        synth.start()
        organ.setDrawbars(drawbars.toIntArray())

        midi = MidiInput(
            context = this,
            onNoteOn = { note, velocity ->
                playNote(note, velocity)
            },
            onNoteOff = { note ->
                releaseNote(note)
            },
            onStatus = { text ->
                status = text
            }
        ).also { it.start() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF101116)
                ) {
                    StudioScreen(
                        status = status,
                        instrument = selectedInstrument,
                        drawbars = drawbars,
                        waveform = waveform,
                        volume = volume,
                        octave = octave,
                        attack = attack,
                        decay = decay,
                        sustain = sustain,
                        release = release,
                        reverbEnabled = reverbEnabled,
                        reverbRoomSize = reverbRoomSize,
                        reverbWetMix = reverbWetMix,

                        onInstrumentChange = { type ->
                            switchInstrument(type)
                        },

                        onDrawbarChange = { index, level ->
                            val updated = drawbars.toMutableList()
                            updated[index] = level
                            drawbars = updated
                            organ.setDrawbar(index, level)
                        },

                        onWaveformChange = {
                            waveform = it
                            synth.waveform = it
                        },

                        onVolumeChange = {
                            volume = it
                            synth.volume = it
                        },

                        onOctaveChange = {
                            octave = it
                            synth.transposeSemitones = it * 12
                        },

                        onAttackChange = {
                            attack = it
                            synth.attack = it
                        },

                        onDecayChange = {
                            decay = it
                            synth.decay = it
                        },

                        onSustainChange = {
                            sustain = it
                            synth.sustain = it
                        },

                        onReleaseChange = {
                            release = it
                            synth.release = it
                        },

                        onReverbEnabledChange = { enabled ->
                            reverbEnabled = enabled
                            synth.configureReverb(enabled, reverbRoomSize, reverbWetMix)
                            organ.configureReverb(enabled, reverbRoomSize, reverbWetMix)
                            piano.configureReverb(enabled, reverbRoomSize, reverbWetMix)
                        },
                        onReverbRoomSizeChange = { value ->
                            reverbRoomSize = value
                            synth.configureReverb(reverbEnabled, value, reverbWetMix)
                            organ.configureReverb(reverbEnabled, value, reverbWetMix)
                            piano.configureReverb(reverbEnabled, value, reverbWetMix)
                        },
                        onReverbWetMixChange = { value ->
                            reverbWetMix = value
                            synth.configureReverb(reverbEnabled, reverbRoomSize, value)
                            organ.configureReverb(reverbEnabled, reverbRoomSize, value)
                            piano.configureReverb(reverbEnabled, reverbRoomSize, value)
                        },
                        onNoteOn = { note, velocity ->
                            playNote(note, velocity)
                        },

                        onNoteOff = { note ->
                            releaseNote(note)
                        }
                    )
                }
            }
        }
    }

    private fun playNote(note: Int, velocity: Float) {
        val safeNote = note.coerceIn(0, 127)

        when (selectedInstrument) {
            InstrumentType.SYNTH -> {
                activeNotes[safeNote] = safeNote
                synth.noteOn(safeNote, velocity)
            }

            InstrumentType.ORGAN -> {
                val playedNote = (safeNote + octave * 12)
                    .coerceIn(0, 127)

                activeNotes[safeNote] = playedNote
                organ.noteOn(playedNote)
            }

            InstrumentType.PIANO -> {
                val playedNote = (safeNote + octave * 12).coerceIn(0, 127)
                activeNotes[safeNote] = playedNote
                piano.noteOn(playedNote, velocity)
            }
        }
    }

    private fun releaseNote(note: Int) {
        val safeNote = note.coerceIn(0, 127)
        val playedNote = activeNotes.remove(safeNote) ?: return

        when (selectedInstrument) {
            InstrumentType.SYNTH -> synth.noteOff(playedNote)
            InstrumentType.ORGAN -> organ.noteOff(playedNote)
            InstrumentType.PIANO -> piano.noteOff(playedNote)
        }
    }

    private fun releaseAllNotes() {
        when (selectedInstrument) {
            InstrumentType.SYNTH -> {
                activeNotes.values.forEach { synth.noteOff(it) }
            }

            InstrumentType.ORGAN -> {
                activeNotes.values.forEach { organ.noteOff(it) }
            }

            InstrumentType.PIANO -> {
                activeNotes.values.forEach { piano.noteOff(it) }
            }
        }

        activeNotes.clear()
    }

    private fun switchInstrument(type: InstrumentType) {
        if (type == selectedInstrument) return

        releaseAllNotes()
        selectedInstrument = type
    }

    override fun onDestroy() {
        releaseAllNotes()
        midi?.stop()
        synth.stop()
        organ.stop()
        piano.stop()
        super.onDestroy()
    }
}

@Composable
fun StudioScreen(
    status: String,
    instrument: InstrumentType,
    drawbars: List<Int>,
    waveform: Waveform,
    volume: Float,
    octave: Int,
    attack: Float,
    decay: Float,
    sustain: Float,
    release: Float,
    onInstrumentChange: (InstrumentType) -> Unit,
    onDrawbarChange: (Int, Int) -> Unit,
    onWaveformChange: (Waveform) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onOctaveChange: (Int) -> Unit,
    onAttackChange: (Float) -> Unit,
    onDecayChange: (Float) -> Unit,
    onSustainChange: (Float) -> Unit,
    onReleaseChange: (Float) -> Unit,
    reverbEnabled: Boolean,
    reverbRoomSize: Float,
    reverbWetMix: Float,
    onReverbEnabledChange: (Boolean) -> Unit,
    onReverbRoomSizeChange: (Float) -> Unit,
    onReverbWetMixChange: (Float) -> Unit,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "ISAAC STUDIO 4",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White
        )

        Text(
            "STAGE 4D | THREE-INSTRUMENT WORKSTATION",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF91A9FF)
        )

        Text(
            status,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFB8C4D9)
        )

        Spacer(Modifier.height(6.dp))

        Text("INSTRUMENT SELECTOR", color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { onInstrumentChange(InstrumentType.SYNTH) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.SYNTH) "✓ SYNTH" else "SYNTH")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.ORGAN) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.ORGAN) "✓ ORGAN" else "ORGAN")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.PIANO) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.PIANO) "✓ PIANO" else "PIANO")
            }
        }

        Spacer(Modifier.height(4.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                "AUDIO EFFECTS",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("REVERB", color = Color.White)
                Button(onClick = { onReverbEnabledChange(!reverbEnabled) }) {
                    Text(if (reverbEnabled) "ON" else "OFF")
                }
            }

            Text("ROOM SIZE • ${(reverbRoomSize * 100).toInt()}%", color = Color.White)
            Slider(
                value = reverbRoomSize,
                onValueChange = onReverbRoomSizeChange,
                valueRange = 0f..1f
            )

            Text("WET MIX • ${(reverbWetMix * 100).toInt()}%", color = Color.White)
            Slider(
                value = reverbWetMix,
                onValueChange = onReverbWetMixChange,
                valueRange = 0f..1f
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("OCTAVE", color = Color.White)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        onOctaveChange((octave - 1).coerceAtLeast(-2))
                    }
                ) {
                    Text("−")
                }

                Text(
                    text = if (octave > 0) "+$octave" else octave.toString(),
                    color = Color(0xFF91A9FF),
                    modifier = Modifier.padding(horizontal = 14.dp)
                )

                Button(
                    onClick = {
                        onOctaveChange((octave + 1).coerceAtMost(2))
                    }
                ) {
                    Text("+")
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Text(
            "TWO-OCTAVE KEYBOARD",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall
        )

        Text(
            "Swipe left or right to explore the keys",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .width(WHITE_KEY_WIDTH * WHITE_KEYS.size)
                    .height(220.dp)
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    WHITE_KEYS.forEach { note ->
                        PianoKey(
                            note = note,
                            label = when (note) {
                                60 -> "C${4 + octave}"
                                72 -> "C${5 + octave}"
                                84 -> "C${6 + octave}"
                                else -> ""
                            },
                            black = false,
                            onNoteOn = onNoteOn,
                            onNoteOff = onNoteOff,
                            modifier = Modifier
                                .width(WHITE_KEY_WIDTH)
                                .fillMaxHeight()
                        )
                    }
                }

                BLACK_KEYS.forEach { key ->
                    PianoKey(
                        note = key.note,
                        label = "",
                        black = true,
                        onNoteOn = onNoteOn,
                        onNoteOff = onNoteOff,
                        modifier = Modifier
                            .offset(
                                x = WHITE_KEY_WIDTH *
                                    (key.afterWhiteIndex + 1) -
                                    BLACK_KEY_WIDTH / 2
                            )
                            .width(BLACK_KEY_WIDTH)
                            .height(130.dp)
                    )
                }
            }
        }

        Text(
            "ISAAC STUDIO 4 • DIGITAL INSTRUMENT",
            color = Color(0xFF77829A),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun EnvelopeControl(
    name: String,
    displayValue: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(name, color = Color.White)
            Text(displayValue, color = Color(0xFF91A9FF))
        }

        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range
        )
    }
}

@Composable
private fun PianoKey(
    note: Int,
    label: String,
    black: Boolean,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    val keyColor = when {
        black && pressed -> Color(0xFF526DAA)
        black -> Color(0xFF171923)
        pressed -> Color(0xFFB0C4FF)
        else -> Color.White
    }

    val shape = RoundedCornerShape(
        bottomStart = 5.dp,
        bottomEnd = 5.dp
    )

    Box(
        modifier = modifier
            .background(keyColor, shape)
            .border(
                width = 0.7.dp,
                color = if (black) Color.Black else Color(0xFFB8B8B8),
                shape = shape
            )
            .pointerInput(note) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onNoteOn(note, 0.8f)
                        tryAwaitRelease()
                        pressed = false
                        onNoteOff(note)
                    }
                )
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        if (label.isNotEmpty()) {
            Text(
                text = label,
                color = Color.DarkGray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}
