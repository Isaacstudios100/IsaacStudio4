package com.isaacstudio.studio4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.isaacstudio.studio4.audio.SynthEngine
import com.isaacstudio.studio4.audio.AudioOutputEngine
import com.isaacstudio.studio4.audio.Waveform
import com.isaacstudio.studio4.audio.instruments.InstrumentType
import com.isaacstudio.studio4.audio.instruments.LayerId
import com.isaacstudio.studio4.audio.instruments.OrganEngine
import com.isaacstudio.studio4.audio.instruments.PianoEngine
import com.isaacstudio.studio4.midi.MidiInput

private val WHITE_KEYS = listOf(
    60, 62, 64, 65, 67, 69, 71,
    72, 74, 76, 77, 79, 81, 83, 84
)

private data class BlackKey(
    val note: Int,
    val afterWhiteIndex: Int
)

private val BLACK_KEYS = listOf(
    BlackKey(61, 0),
    BlackKey(63, 1),
    BlackKey(66, 3),
    BlackKey(68, 4),
    BlackKey(70, 5),
    BlackKey(73, 7),
    BlackKey(75, 8),
    BlackKey(78, 10),
    BlackKey(80, 11),
    BlackKey(82, 12)
)
private data class ActiveVoice(
    val source: String,
    val originalNote: Int,
    val layerId: LayerId,
    val voiceId: Long,
    val pressId: Long
)

private class LayerZone(
    enabledInitially: Boolean = false
) {
    var enabled by mutableStateOf(enabledInitially)
    var lowNote by mutableStateOf(0)
    var highNote by mutableStateOf(127)
}

private val WHITE_KEY_WIDTH = 42.dp
private val BLACK_KEY_WIDTH = 26.dp

private val DRAWBAR_NAMES = listOf(
    "16'", "5⅓'", "8'", "4'", "2⅔'",
    "2'", "1⅗'", "1⅓'", "1'"
)

class MainActivity : ComponentActivity() {

private val synth = SynthEngine()
private val synth2 = SynthEngine()
private val synth3 = SynthEngine()

private val organ = OrganEngine()
private val organ2 = OrganEngine()

private val piano = PianoEngine()
private val piano2 = PianoEngine()

private val audioOutput = AudioOutputEngine()

    private var midi: MidiInput? = null
    private var status by mutableStateOf("Starting...")

    private var selectedInstrument by mutableStateOf(InstrumentType.SYNTH)
private var selectedLayer by mutableStateOf(LayerId.SYNTH_1)
    private var drawbars by mutableStateOf(
        listOf(8, 0, 5, 0, 0, 0, 0, 0, 0)
    )

private val activeVoices = mutableListOf<ActiveVoice>()
private val layerZones = LayerId.values()
    .associateWith { LayerZone() }
    .toMutableMap()
    .apply {
        getValue(LayerId.SYNTH_1).enabled = true
    }
private val layerVolumes = LayerId.values()
    .associateWith { mutableFloatStateOf(1.0f) }

private val organDrawbarSettings = LayerId.values()
    .filter { it.instrument == InstrumentType.ORGAN }
    .associateWith {
        mutableStateOf(listOf(8, 0, 5, 0, 0, 0, 0, 0, 0))
    }

private var nextPressId = 1L

    private var waveform by mutableStateOf(Waveform.SAWTOOTH)
private var volume by mutableStateOf(1.0f)
private var synthLayerVolume by mutableStateOf(1.0f)
private var organLayerVolume by mutableStateOf(1.0f)
private var pianoLayerVolume by mutableStateOf(1.0f)
    private var octave by mutableStateOf(0)
    private var attack by mutableStateOf(0.005f)
    private var decay by mutableStateOf(0.12f)
    private var sustain by mutableStateOf(0.7f)
    private var release by mutableStateOf(0.3f)

    private var reverbEnabled by mutableStateOf(false)
    private var reverbRoomSize by mutableStateOf(0.5f)
    private var reverbWetMix by mutableStateOf(0.25f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

synth.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_1).enabled
synth2.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_2).enabled
synth3.isRenderingEnabled = layerZones.getValue(LayerId.SYNTH_3).enabled

organ.isRenderingEnabled = layerZones.getValue(LayerId.ORGAN_1).enabled
organ2.isRenderingEnabled = layerZones.getValue(LayerId.ORGAN_2).enabled

piano.isRenderingEnabled = layerZones.getValue(LayerId.PIANO_1).enabled
piano2.isRenderingEnabled = layerZones.getValue(LayerId.PIANO_2).enabled

audioOutput.addRenderer(synth)
audioOutput.addRenderer(synth2)
audioOutput.addRenderer(synth3)

audioOutput.addRenderer(organ)
audioOutput.addRenderer(organ2)

audioOutput.addRenderer(piano)
audioOutput.addRenderer(piano2)

audioOutput.configureReverb(
    reverbEnabled,
    reverbRoomSize,
    reverbWetMix
)

audioOutput.start()

organ.setDrawbars(
    organDrawbarSettings
        .getValue(LayerId.ORGAN_1)
        .value.toIntArray()
)

organ2.setDrawbars(
    organDrawbarSettings
        .getValue(LayerId.ORGAN_2)
        .value.toIntArray()
)

midi = MidiInput(
    context = this,
    onNoteOn = { note, velocity, deviceId, channel ->
        playNote(note, velocity, "midi:$deviceId:$channel")
    },
    onNoteOff = { note, deviceId, channel ->
        releaseNote(note, "midi:$deviceId:$channel")
    },
    onSourceDisconnected = { deviceId ->
        releaseNotesFromDevice(deviceId)
    },
    onStatus = { text ->
        status = text
    }
).also { it.start() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF101116)
                ) {
                    StudioScreen(
                        status = status,
                        instrument = selectedInstrument,
selectedLayer = selectedLayer,
layerEnabled = layerZones.getValue(selectedLayer).enabled,
layerVolume = layerVolumes.getValue(selectedLayer).floatValue,
lowNote = layerZones.getValue(selectedLayer).lowNote,
highNote = layerZones.getValue(selectedLayer).highNote,

onLayerSelect = { selectLayer(it) },

onLayerEnabledChange = {
    setLayerEnabled(selectedLayer, it)
},

onLayerVolumeChange = {
    setLayerVolume(selectedLayer, it)
},

onLayerLowNoteChange = { value ->
    val zone = layerZones.getValue(selectedLayer)
    zone.lowNote = value.coerceIn(0, zone.highNote)
},

onLayerHighNoteChange = { value ->
    val zone = layerZones.getValue(selectedLayer)
    zone.highNote = value.coerceIn(zone.lowNote, 127)
},
                        drawbars = drawbars,
                        waveform = waveform,
                        volume = volume,
synthLayerVolume = synthLayerVolume,
organLayerVolume = organLayerVolume,
pianoLayerVolume = pianoLayerVolume,
                        octave = octave,
                        attack = attack,
                        decay = decay,
                        sustain = sustain,
                        release = release,
                        reverbEnabled = reverbEnabled,
                        reverbRoomSize = reverbRoomSize,
                        reverbWetMix = reverbWetMix,

                        onInstrumentChange = { type ->
                            switchInstrument(type)
                        },

                        onDrawbarChange = { index, level ->
                            val updated = drawbars.toMutableList()
                            updated[index] = level
                            drawbars = updated

                            organDrawbarSettings
                                .getValue(selectedLayer).value = updated

                            when (selectedLayer) {
                                LayerId.ORGAN_1 ->
                                    organ.setDrawbar(index, level)

                                LayerId.ORGAN_2 ->
                                    organ2.setDrawbar(index, level)

                                else -> Unit
                            }
                        },

                        onWaveformChange = {
                            waveform = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.waveform = it
                                LayerId.SYNTH_2 -> synth2.waveform = it
                                LayerId.SYNTH_3 -> synth3.waveform = it
                                else -> Unit
                            }
                        },

                        onVolumeChange = {
                            volume = it
                            audioOutput.masterVolume = it
                        },

                        onSynthLayerVolumeChange = {
                            synthLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onOrganLayerVolumeChange = {
                            organLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onPianoLayerVolumeChange = {
                            pianoLayerVolume = it
                            setLayerVolume(selectedLayer, it)
                        },

                        onOctaveChange = {
                            octave = it

                            synth.transposeSemitones = it * 12
                            synth2.transposeSemitones = it * 12
                            synth3.transposeSemitones = it * 12
                        },

                        onAttackChange = {
                            attack = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.attack = it
                                LayerId.SYNTH_2 -> synth2.attack = it
                                LayerId.SYNTH_3 -> synth3.attack = it
                                else -> Unit
                            }
                        },

                        onDecayChange = {
                            decay = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.decay = it
                                LayerId.SYNTH_2 -> synth2.decay = it
                                LayerId.SYNTH_3 -> synth3.decay = it
                                else -> Unit
                            }
                        },

                        onSustainChange = {
                            sustain = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.sustain = it
                                LayerId.SYNTH_2 -> synth2.sustain = it
                                LayerId.SYNTH_3 -> synth3.sustain = it
                                else -> Unit
                            }
                        },

                        onReleaseChange = {
                            release = it

                            when (selectedLayer) {
                                LayerId.SYNTH_1 -> synth.release = it
                                LayerId.SYNTH_2 -> synth2.release = it
                                LayerId.SYNTH_3 -> synth3.release = it
                                else -> Unit
                            }
                        },

onReverbEnabledChange = { enabled ->
    reverbEnabled = enabled
    audioOutput.configureReverb(
        enabled,
        reverbRoomSize,
        reverbWetMix
    )
},
onReverbRoomSizeChange = { value ->
    reverbRoomSize = value
    audioOutput.configureReverb(
        reverbEnabled,
        value,
        reverbWetMix
    )
},
onReverbWetMixChange = { value ->
    reverbWetMix = value
    audioOutput.configureReverb(
        reverbEnabled,
        reverbRoomSize,
        value
    )
},
onNoteOn = { note, velocity ->
    playNote(note, velocity, "onscreen")
},

onNoteOff = { note ->
    releaseNote(note, "onscreen")
}
                    )
                }
            }
        }
    }

private fun playNote(note: Int, velocity: Float, source: String) {
    val safeNote = note.coerceIn(0, 127)
    val pressId = nextPressId++

    for ((layerId, zone) in layerZones) {
        if (!zone.enabled) continue

        if (safeNote !in zone.lowNote..zone.highNote) continue

        val playedNote = if (layerId.instrument == InstrumentType.SYNTH) {
            safeNote
        } else {
            (safeNote + octave * 12).coerceIn(0, 127)
        }

        val voiceId = when (layerId) {
            LayerId.SYNTH_1 -> synth.noteOn(playedNote, velocity)
            LayerId.SYNTH_2 -> synth2.noteOn(playedNote, velocity)
            LayerId.SYNTH_3 -> synth3.noteOn(playedNote, velocity)

            LayerId.ORGAN_1 -> organ.noteOn(playedNote)
            LayerId.ORGAN_2 -> organ2.noteOn(playedNote)

            LayerId.PIANO_1 -> piano.noteOn(playedNote, velocity)
            LayerId.PIANO_2 -> piano2.noteOn(playedNote, velocity)
        }

        if (voiceId != 0L) {
            activeVoices.add(
                ActiveVoice(
                    source,
                    safeNote,
                    layerId,
                    voiceId,
                    pressId
                )
            )
        }
    }
}

private fun releaseNote(note: Int, source: String) {
    val safeNote = note.coerceIn(0, 127)

    val matchingPress = activeVoices.lastOrNull {
        it.source == source && it.originalNote == safeNote
    } ?: return

    val voicesToRelease = activeVoices.filter {
        it.source == source &&
        it.originalNote == safeNote &&
        it.pressId == matchingPress.pressId
    }

    voicesToRelease.forEach {
        releaseVoice(it)
    }

    activeVoices.removeAll(voicesToRelease.toSet())
}

private fun releaseVoice(voice: ActiveVoice) {
    when (voice.layerId) {
        LayerId.SYNTH_1 -> synth.noteOffVoice(voice.voiceId)
        LayerId.SYNTH_2 -> synth2.noteOffVoice(voice.voiceId)
        LayerId.SYNTH_3 -> synth3.noteOffVoice(voice.voiceId)

        LayerId.ORGAN_1 -> organ.noteOffVoice(voice.voiceId)
        LayerId.ORGAN_2 -> organ2.noteOffVoice(voice.voiceId)

        LayerId.PIANO_1 -> piano.noteOffVoice(voice.voiceId)
        LayerId.PIANO_2 -> piano2.noteOffVoice(voice.voiceId)
    }
}
private fun setLayerRenderingEnabled(
    layerId: LayerId,
    enabled: Boolean
) {
    when (layerId) {
        LayerId.SYNTH_1 -> synth.isRenderingEnabled = enabled
        LayerId.SYNTH_2 -> synth2.isRenderingEnabled = enabled
        LayerId.SYNTH_3 -> synth3.isRenderingEnabled = enabled

        LayerId.ORGAN_1 -> organ.isRenderingEnabled = enabled
        LayerId.ORGAN_2 -> organ2.isRenderingEnabled = enabled

        LayerId.PIANO_1 -> piano.isRenderingEnabled = enabled
        LayerId.PIANO_2 -> piano2.isRenderingEnabled = enabled
    }
}

private fun setLayerEnabled(
    layerId: LayerId,
    enabled: Boolean
) {
    layerZones.getValue(layerId).enabled = enabled
    setLayerRenderingEnabled(layerId, enabled)

    if (!enabled) {
        val matchingVoices = activeVoices.filter {
            it.layerId == layerId
        }

        matchingVoices.forEach {
            releaseVoice(it)
        }

        activeVoices.removeAll(matchingVoices.toSet())
    }
}

private fun setLayerVolume(
    layerId: LayerId,
    newVolume: Float
) {
    val safeVolume = newVolume.coerceIn(0f, 1f)

    layerVolumes.getValue(layerId).floatValue = safeVolume

    when (layerId) {
        LayerId.SYNTH_1 -> synth.layerVolume = safeVolume
        LayerId.SYNTH_2 -> synth2.layerVolume = safeVolume
        LayerId.SYNTH_3 -> synth3.layerVolume = safeVolume

        LayerId.ORGAN_1 -> organ.layerVolume = safeVolume
        LayerId.ORGAN_2 -> organ2.layerVolume = safeVolume

        LayerId.PIANO_1 -> piano.layerVolume = safeVolume
        LayerId.PIANO_2 -> piano2.layerVolume = safeVolume
    }
}

private fun selectLayer(layerId: LayerId) {
    selectedLayer = layerId
    selectedInstrument = layerId.instrument

    when (layerId) {
        LayerId.SYNTH_1,
        LayerId.SYNTH_2,
        LayerId.SYNTH_3 -> {
            val engine = when (layerId) {
                LayerId.SYNTH_1 -> synth
                LayerId.SYNTH_2 -> synth2
                LayerId.SYNTH_3 -> synth3
                else -> return
            }

            waveform = engine.waveform
            attack = engine.attack
            decay = engine.decay
            sustain = engine.sustain
            release = engine.release

            synthLayerVolume =
                layerVolumes.getValue(layerId).floatValue
        }

        LayerId.ORGAN_1,
        LayerId.ORGAN_2 -> {
            drawbars =
                organDrawbarSettings.getValue(layerId).value

            organLayerVolume =
                layerVolumes.getValue(layerId).floatValue
        }

        LayerId.PIANO_1,
        LayerId.PIANO_2 -> {
            pianoLayerVolume =
                layerVolumes.getValue(layerId).floatValue
        }
    }
}
private fun releaseAllNotes() {
    activeVoices.toList().forEach {
        releaseVoice(it)
    }

    activeVoices.clear()
}

private fun releaseNotesFromDevice(deviceId: Int) {
    val sourcePrefix = "midi:$deviceId:"

    val matchingVoices = activeVoices.filter {
        it.source.startsWith(sourcePrefix)
    }

    matchingVoices.forEach {
        releaseVoice(it)
    }

    activeVoices.removeAll(matchingVoices.toSet())
}

private fun switchInstrument(type: InstrumentType) {
    val firstLayer = when (type) {
        InstrumentType.SYNTH -> LayerId.SYNTH_1
        InstrumentType.ORGAN -> LayerId.ORGAN_1
        InstrumentType.PIANO -> LayerId.PIANO_1
    }

    selectLayer(firstLayer)
}

override fun onDestroy() {
    releaseAllNotes()
    midi?.stop()
    audioOutput.stop()
    super.onDestroy()
}

@Composable
fun StudioScreen(
    status: String,
    instrument: InstrumentType,
selectedLayer: LayerId,
layerEnabled: Boolean,
layerVolume: Float,
lowNote: Int,
highNote: Int,
onLayerSelect: (LayerId) -> Unit,
onLayerEnabledChange: (Boolean) -> Unit,
onLayerVolumeChange: (Float) -> Unit,
onLayerLowNoteChange: (Int) -> Unit,
onLayerHighNoteChange: (Int) -> Unit,
    drawbars: List<Int>,
    waveform: Waveform,
    volume: Float,
synthLayerVolume: Float,
organLayerVolume: Float,
pianoLayerVolume: Float,
    octave: Int,
    attack: Float,
    decay: Float,
    sustain: Float,
    release: Float,
    onInstrumentChange: (InstrumentType) -> Unit,
    onDrawbarChange: (Int, Int) -> Unit,
    onWaveformChange: (Waveform) -> Unit,
    onVolumeChange: (Float) -> Unit,
onSynthLayerVolumeChange: (Float) -> Unit,
onOrganLayerVolumeChange: (Float) -> Unit,
onPianoLayerVolumeChange: (Float) -> Unit,
    onOctaveChange: (Int) -> Unit,
    onAttackChange: (Float) -> Unit,
    onDecayChange: (Float) -> Unit,
    onSustainChange: (Float) -> Unit,
    onReleaseChange: (Float) -> Unit,
    reverbEnabled: Boolean,
    reverbRoomSize: Float,
    reverbWetMix: Float,
    onReverbEnabledChange: (Boolean) -> Unit,
    onReverbRoomSizeChange: (Float) -> Unit,
    onReverbWetMixChange: (Float) -> Unit,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "ISAAC STUDIO 4",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White
        )

        Text(
            "STAGE 4D | THREE-INSTRUMENT WORKSTATION",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF91A9FF)
        )

        Text(
            status,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFB8C4D9)
        )

        Spacer(Modifier.height(6.dp))

        Text("INSTRUMENT SELECTOR", color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { onInstrumentChange(InstrumentType.SYNTH) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.SYNTH) "✓ SYNTH" else "SYNTH")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.ORGAN) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.ORGAN) "✓ ORGAN" else "ORGAN")
            }

            Button(
                onClick = { onInstrumentChange(InstrumentType.PIANO) },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (instrument == InstrumentType.PIANO) "✓ PIANO" else "PIANO")
            }
        }
        // SEVEN-LAYER CONTROL PANEL

        Text(
            "LAYER CONTROL",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LayerId.values()
                .filter { it.instrument == instrument }
                .forEach { layer ->
                    Button(
                        onClick = { onLayerSelect(layer) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            if (selectedLayer == layer) {
                                "✓ ${layer.displayName}"
                            } else {
                                layer.displayName
                            }
                        )
                    }
                }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                selectedLayer.displayName,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall
            )

            Button(
                onClick = {
                    onLayerEnabledChange(!layerEnabled)
                }
            ) {
                Text(
                    if (layerEnabled) "LAYER: ON" else "LAYER: OFF"
                )
            }
        }

        Text(
            "LAYER VOLUME • ${(layerVolume * 100).toInt()}%",
            color = Color.White
        )

        Slider(
            value = layerVolume,
            onValueChange = onLayerVolumeChange,
            valueRange = 0f..1f
        )

        Text(
            "LOW KEY • $lowNote",
            color = Color.White
        )

        Slider(
            value = lowNote.toFloat(),
            onValueChange = {
                onLayerLowNoteChange(it.toInt())
            },
            valueRange = 0f..127f,
            steps = 126
        )

        Text(
            "HIGH KEY • $highNote",
            color = Color.White
        )

        Slider(
            value = highNote.toFloat(),
            onValueChange = {
                onLayerHighNoteChange(it.toInt())
            },
            valueRange = 0f..127f,
            steps = 126
        )

        Text(
            "KEYBOARD ZONE: $lowNote – $highNote",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(8.dp))

        Column {
            Button(
                onClick = {
                    onReverbEnabledChange(!reverbEnabled)
                }
            ) {
                Text(
                    if (reverbEnabled) "REVERB: ON"
                    else "REVERB: OFF"
                )
            }

            Text(
                "ROOM SIZE • ${(reverbRoomSize * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = reverbRoomSize,
                onValueChange = onReverbRoomSizeChange,
                valueRange = 0f..1f
            )

            Text(
                "WET MIX • ${(reverbWetMix * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = reverbWetMix,
                onValueChange = onReverbWetMixChange,
                valueRange = 0f..1f
            )
        }
        if (instrument == InstrumentType.SYNTH) {
            Text(
                "SYNTHESIZER CONTROLS",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

            Text("WAVEFORM", color = Color.White)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Waveform.values().forEach { type ->
                    Button(
                        onClick = { onWaveformChange(type) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (waveform == type) {
                                "✓ " + type.name.take(3)
                            } else {
                                type.name.take(3)
                            },
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            Text(
                "MASTER VOLUME: ${(volume * 100).toInt()}%",
                color = Color.White
            )

            Slider(
                value = volume,
                onValueChange = onVolumeChange,
                valueRange = 0f..1f
            )
            EnvelopeControl(
                "ATTACK",
                "${(attack * 1000).toInt()} ms",
                attack,
                0.001f..2f,
                onAttackChange
            )

            EnvelopeControl(
                "DECAY",
                "${(decay * 1000).toInt()} ms",
                decay,
                0.001f..2f,
                onDecayChange
            )

            EnvelopeControl(
                "SUSTAIN",
                "${(sustain * 100).toInt()}%",
                sustain,
                0f..1f,
                onSustainChange
            )

            EnvelopeControl(
                "RELEASE",
                "${(release * 1000).toInt()} ms",
                release,
                0.01f..3f,
                onReleaseChange
            )
        }

        if (instrument == InstrumentType.ORGAN) {
            Text(
                "TONEWHEEL ORGAN",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

            Text(
                "NINE DRAWBARS • HARMONIC MIXER",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium
            )

            DRAWBAR_NAMES.forEachIndexed { index, name ->
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(name, color = Color.White)
                        Text(
                            drawbars[index].toString(),
                            color = Color(0xFF91A9FF)
                        )
                    }

                    Slider(
                        value = drawbars[index].toFloat(),
                        onValueChange = {
                            onDrawbarChange(index, it.toInt())
                        },
                        valueRange = 0f..8f,
                        steps = 7
                    )
                }
            }

            Text(
                "Adjust each drawbar to shape the organ tone.",
                color = Color.Gray,
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (instrument == InstrumentType.PIANO) {
            Text(
                "PIANO CONTROLS",
                color = Color(0xFF91A9FF),
                style = MaterialTheme.typography.titleMedium
            )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("OCTAVE", color = Color.White)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        onOctaveChange((octave - 1).coerceAtLeast(-2))
                    }
                ) {
                    Text("−")
                }

                Text(
                    text = if (octave > 0) "+$octave" else octave.toString(),
                    color = Color(0xFF91A9FF),
                    modifier = Modifier.padding(horizontal = 14.dp)
                )

                Button(
                    onClick = {
                        onOctaveChange((octave + 1).coerceAtMost(2))
                    }
                ) {
                    Text("+")
                }
            }
        }
}
        Spacer(Modifier.height(8.dp))

        Text(
            "TWO-OCTAVE KEYBOARD",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall
        )

        Text(
            "Swipe left or right to explore the keys",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .width(WHITE_KEY_WIDTH * WHITE_KEYS.size)
                    .height(220.dp)
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    WHITE_KEYS.forEach { note ->
                        PianoKey(
                            note = note,
                            label = when (note) {
                                60 -> "C${4 + octave}"
                                72 -> "C${5 + octave}"
                                84 -> "C${6 + octave}"
                                else -> ""
                            },
                            black = false,
                            onNoteOn = onNoteOn,
                            onNoteOff = onNoteOff,
                            modifier = Modifier
                                .width(WHITE_KEY_WIDTH)
                                .fillMaxHeight()
                        )
                    }
                }

                BLACK_KEYS.forEach { key ->
                    PianoKey(
                        note = key.note,
                        label = "",
                        black = true,
                        onNoteOn = onNoteOn,
                        onNoteOff = onNoteOff,
                        modifier = Modifier
                            .offset(
                                x = WHITE_KEY_WIDTH *
                                    (key.afterWhiteIndex + 1) -
                                    BLACK_KEY_WIDTH / 2
                            )
                            .width(BLACK_KEY_WIDTH)
                            .height(130.dp)
                    )
                }
            }
        }

        Text(
            "ISAAC STUDIO 4 • DIGITAL INSTRUMENT",
            color = Color(0xFF77829A),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun EnvelopeControl(
    name: String,
    displayValue: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(name, color = Color.White)
            Text(displayValue, color = Color(0xFF91A9FF))
        }

        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range
        )
    }
}

@Composable
private fun PianoKey(
    note: Int,
    label: String,
    black: Boolean,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    val keyColor = when {
        black && pressed -> Color(0xFF526DAA)
        black -> Color(0xFF171923)
        pressed -> Color(0xFFB0C4FF)
        else -> Color.White
    }

    val shape = RoundedCornerShape(
        bottomStart = 5.dp,
        bottomEnd = 5.dp
    )

    Box(
        modifier = modifier
            .background(keyColor, shape)
            .border(
                width = 0.7.dp,
                color = if (black) Color.Black else Color(0xFFB8B8B8),
                shape = shape
            )
            .pointerInput(note) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onNoteOn(note, 0.8f)
                        tryAwaitRelease()
                        pressed = false
                        onNoteOff(note)
                    }
                )
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        if (label.isNotEmpty()) {
            Text(
                text = label,
                color = Color.DarkGray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

