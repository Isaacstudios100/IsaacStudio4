package com.isaacstudio.studio4.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.isaacstudio.studio4.audio.effects.ReverbProcessor
import java.util.concurrent.CopyOnWriteArrayList

class AudioOutputEngine {

    companion object {
        private const val SAMPLE_RATE = 44100
        private const val BUFFER_FRAMES = 256
    }

    private val lifecycleLock = Any()
    private val reverb = ReverbProcessor()

    private val outputBuffer = FloatArray(BUFFER_FRAMES)

    private val renderers =
        CopyOnWriteArrayList<AudioRenderer>()

    private var track: AudioTrack? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    @Volatile
    var reverbEnabled = false

    @Volatile
    var reverbRoomSize = 0.5f

    @Volatile
    var reverbWetMix = 0.25f

    fun addRenderer(renderer: AudioRenderer) {
        renderers.addIfAbsent(renderer)
    }

    fun removeRenderer(renderer: AudioRenderer) {
        renderers.remove(renderer)
    }

    fun configureReverb(
        enabled: Boolean,
        roomSize: Float,
        wetMix: Float
    ) {
        reverbEnabled = enabled
        reverbRoomSize = roomSize.coerceIn(0f, 1f)
        reverbWetMix = wetMix.coerceIn(0f, 1f)

        reverb.enabled = reverbEnabled
        reverb.roomSize = reverbRoomSize
        reverb.wetMix = reverbWetMix
    }

    fun start() {
        synchronized(lifecycleLock) {
            if (running) return

            val minBytes = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_FLOAT
            )

            if (minBytes <= 0) return

            var newTrack: AudioTrack? = null

            try {
                val createdTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(
                                AudioAttributes.CONTENT_TYPE_MUSIC
                            )
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(
                                AudioFormat.ENCODING_PCM_FLOAT
                            )
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(
                                AudioFormat.CHANNEL_OUT_MONO
                            )
                            .build()
                    )
                    .setBufferSizeInBytes(minBytes * 2)
                    .setPerformanceMode(
                        AudioTrack.PERFORMANCE_MODE_LOW_LATENCY
                    )
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                newTrack = createdTrack

                if (createdTrack.state != AudioTrack.STATE_INITIALIZED) {
                    createdTrack.release()
                    return
                }

                track = createdTrack
                outputBuffer.fill(0f)

                reverb.reset()
                reverb.enabled = reverbEnabled
                reverb.roomSize = reverbRoomSize
                reverb.wetMix = reverbWetMix

                running = true
                createdTrack.play()

                val newThread = Thread(
                    { renderLoop() },
                    "IsaacStudio4-CentralAudio"
                ).apply {
                    priority = Thread.MAX_PRIORITY
                }

                thread = newThread
                newThread.start()

            } catch (_: Exception) {
                running = false

                val threadToStop = thread
                thread = null
                track = null

                try {
                    newTrack?.stop()
                } catch (_: Exception) {
                }

                try {
                    threadToStop?.join()
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }

                try {
                    newTrack?.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun renderLoop() {
        while (running) {
            outputBuffer.fill(0f)

for (renderer in renderers) {
    try {
        renderer.renderInto(outputBuffer)
    } catch (_: Exception) {
        renderer.isRenderingEnabled = false
    }
}

            reverb.process(outputBuffer)

            for (i in outputBuffer.indices) {
                outputBuffer[i] =
                    outputBuffer[i].coerceIn(-1f, 1f)
            }

            val currentTrack = track ?: break

            if (running) {
                try {
                    val written = currentTrack.write(
                        outputBuffer,
                        0,
                        outputBuffer.size,
                        AudioTrack.WRITE_BLOCKING
                    )

                    if (written <= 0) {
                        running = false
                        break
                    }
                } catch (_: Exception) {
                    running = false
                    break
                }
            }

    }
}
    fun stop() {
        synchronized(lifecycleLock) {
            if (!running && track == null && thread == null) return

            running = false

            val trackToStop = track
            val threadToStop = thread

            track = null
            thread = null

            try {
                trackToStop?.stop()
            } catch (_: Exception) {
            }

            try {
                threadToStop?.join()
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }

            try {
                trackToStop?.release()
            } catch (_: Exception) {
            }

            outputBuffer.fill(0f)
            reverb.reset()
        }
    }
}
