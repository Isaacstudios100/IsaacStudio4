package com.isaacstudio.studio4.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.isaacstudio.studio4.audio.effects.ReverbProcessor
import java.util.concurrent.CopyOnWriteArrayList

data class RendererDiagnostic(
    val name: String,
    val averageTimeUs: Long,
    val maximumTimeUs: Long
)

data class AudioDiagnostics(
    val renderers: List<RendererDiagnostic>,
    val totalRenderTimeUs: Long,
    val maximumBlockTimeUs: Long,
    val underrunCount: Int
)
class AudioOutputEngine {

    companion object {
        private const val SAMPLE_RATE = 44100
private const val BUFFER_FRAMES = 512
    }

    private val lifecycleLock = Any()
    private val reverb = ReverbProcessor()

    private val outputBuffer = FloatArray(BUFFER_FRAMES)

private val renderers =
    CopyOnWriteArrayList<Pair<String, AudioRenderer>>()

private val rendererTotalNanos = LongArray(7)
private val rendererMaxNanos = LongArray(7)

@Volatile private var diagnosticTotalRenderNanos = 0L

@Volatile private var diagnosticMaxBlockNanos = 0L

@Volatile private var diagnosticUnderruns = 0
@Volatile
private var publishedDiagnostics = AudioDiagnostics(
    renderers = emptyList(),
    totalRenderTimeUs = 0L,
    maximumBlockTimeUs = 0L,
    underrunCount = 0
)

    private var track: AudioTrack? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    @Volatile
    var reverbEnabled = false

    @Volatile
    var reverbRoomSize = 0.5f

    @Volatile
    var reverbWetMix = 0.25f

@Volatile
var masterVolume = 1.0f

fun addRenderer(name: String, renderer: AudioRenderer) {
    renderers.addIfAbsent(name to renderer)
}

fun removeRenderer(renderer: AudioRenderer) {
    renderers.removeAll { it.second === renderer }
}
fun getDiagnostics(): AudioDiagnostics {
    return publishedDiagnostics
}


    fun configureReverb(
        enabled: Boolean,
        roomSize: Float,
        wetMix: Float
    ) {
        reverbEnabled = enabled
        reverbRoomSize = roomSize.coerceIn(0f, 1f)
        reverbWetMix = wetMix.coerceIn(0f, 1f)

        reverb.enabled = reverbEnabled
        reverb.roomSize = reverbRoomSize
        reverb.wetMix = reverbWetMix
    }

    fun start() {
        synchronized(lifecycleLock) {
            if (running) return

            val minBytes = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_FLOAT
            )

            if (minBytes <= 0) return

            var newTrack: AudioTrack? = null

            try {
                val createdTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(
                                AudioAttributes.CONTENT_TYPE_MUSIC
                            )
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(
                                AudioFormat.ENCODING_PCM_FLOAT
                            )
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(
                                AudioFormat.CHANNEL_OUT_MONO
                            )
                            .build()
                    )
.setBufferSizeInBytes(minBytes * 4)
                    .setPerformanceMode(
                        AudioTrack.PERFORMANCE_MODE_LOW_LATENCY
                    )
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                newTrack = createdTrack

                if (createdTrack.state != AudioTrack.STATE_INITIALIZED) {
                    createdTrack.release()
                    return
                }

                track = createdTrack
                outputBuffer.fill(0f)

                reverb.reset()
                reverb.enabled = reverbEnabled
                reverb.roomSize = reverbRoomSize
                reverb.wetMix = reverbWetMix

                running = true
                createdTrack.play()

                val newThread = Thread(
                    { renderLoop() },
                    "IsaacStudio4-CentralAudio"
                ).apply {
                    priority = Thread.MAX_PRIORITY
                }

                thread = newThread
                newThread.start()

            } catch (_: Exception) {
                running = false

                val threadToStop = thread
                thread = null
                track = null

                try {
                    newTrack?.stop()
                } catch (_: Exception) {
                }

                try {
                    threadToStop?.join()
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }

                try {
                    newTrack?.release()
                } catch (_: Exception) {
                }
            }
        }
    }

private fun renderLoop() {
    val rendererTotals = LongArray(7)
    val rendererMax = LongArray(7)
var measurementCount = 0
var maximumBlockTime = 0L
var lastDiagnosticUpdate = System.nanoTime()

    while (running) {
        val blockStart = System.nanoTime()
        outputBuffer.fill(0f)

        for ((index, entry) in renderers.withIndex()) {
            val rendererStart = System.nanoTime()

            try {
                entry.second.renderInto(outputBuffer)
            } catch (_: Exception) {
                entry.second.isRenderingEnabled = false
            }

            val renderTime = System.nanoTime() - rendererStart

            if (index < rendererTotals.size) {
                rendererTotals[index] += renderTime
                if (renderTime > rendererMax[index]) {
                    rendererMax[index] = renderTime
                }
            }
        }

        reverb.process(outputBuffer)

        for (i in outputBuffer.indices) {
            outputBuffer[i] *= masterVolume.coerceIn(0f, 1f)
        }

        for (i in outputBuffer.indices) {
            outputBuffer[i] = outputBuffer[i].coerceIn(-1f, 1f)
        }

val processingTime = System.nanoTime() - blockStart

if (processingTime > maximumBlockTime) {
    maximumBlockTime = processingTime
}

        val currentTrack = track ?: break

        if (running) {
            try {
                val written = currentTrack.write(
                    outputBuffer,
                    0,
                    outputBuffer.size,
                    AudioTrack.WRITE_BLOCKING
                )

                if (written <= 0) {
                    running = false
                    break
                }
            } catch (_: Exception) {
                running = false
                break
            }
        }

        measurementCount++
        val now = System.nanoTime()

        if (now - lastDiagnosticUpdate >= 1_000_000_000L) {
            for (i in rendererTotals.indices) {
                rendererTotalNanos[i] = rendererTotals[i] / measurementCount
                rendererMaxNanos[i] = rendererMax[i]
            }

            diagnosticTotalRenderNanos =
                rendererTotals.sum() / measurementCount

diagnosticMaxBlockNanos = maximumBlockTime

            diagnosticUnderruns = currentTrack.underrunCount
publishedDiagnostics = AudioDiagnostics(
    renderers = renderers.mapIndexed { index, entry ->
        RendererDiagnostic(
            name = entry.first,
            averageTimeUs = rendererTotalNanos[index] / 1000L,
            maximumTimeUs = rendererMaxNanos[index] / 1000L
        )
    },
    totalRenderTimeUs = diagnosticTotalRenderNanos / 1000L,
    maximumBlockTimeUs = diagnosticMaxBlockNanos / 1000L,
    underrunCount = diagnosticUnderruns
)

            rendererTotals.fill(0L)
            rendererMax.fill(0L)
maximumBlockTime = 0L
            measurementCount = 0
            lastDiagnosticUpdate = now
        }
    }
}

    fun stop() {
        synchronized(lifecycleLock) {
            if (!running && track == null && thread == null) return

            running = false

            val trackToStop = track
            val threadToStop = thread

            track = null
            thread = null

            try {
                trackToStop?.stop()
            } catch (_: Exception) {
            }

            try {
                threadToStop?.join()
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }

            try {
                trackToStop?.release()
            } catch (_: Exception) {
            }

            outputBuffer.fill(0f)
            reverb.reset()
        }
    }
}
