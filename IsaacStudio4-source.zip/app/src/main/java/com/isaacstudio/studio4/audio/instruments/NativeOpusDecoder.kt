package com.isaacstudio.studio4.audio.instruments

/**
 * Native OGG/Opus decoder bridge.
 *
 * Decoding must be requested from a background worker, never from renderInto().
 * Successful output is interleaved signed PCM16 at 48,000 Hz.
 */
internal object NativeOpusDecoder {
    init {
        System.loadLibrary("pianosampledecoder")
    }

    external fun decodeOggToPcm16(oggData: ByteArray): ShortArray?
}
