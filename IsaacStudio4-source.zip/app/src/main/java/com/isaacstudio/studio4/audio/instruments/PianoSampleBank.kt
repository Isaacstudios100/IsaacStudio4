package com.isaacstudio.studio4.audio.instruments

import java.io.Closeable
import java.util.LinkedHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Identifies one piano sample by MIDI key and SFZ velocity layer.
 *
 * Velocity layers are numbered 1 through 4, matching the packaged SFZ.
 */
internal data class PianoSampleId(
    val key: Int,
    val velocityLayer: Int
) {
    init {
        require(key in MIN_KEY..MAX_KEY) { "Piano key out of range: $key" }
        require(velocityLayer in MIN_VELOCITY_LAYER..MAX_VELOCITY_LAYER) {
            "Piano velocity layer out of range: $velocityLayer"
        }
    }

    companion object {
        const val MIN_KEY = 21
        const val MAX_KEY = 108
        const val MIN_VELOCITY_LAYER = 1
        const val MAX_VELOCITY_LAYER = 4
    }
}

/**
 * Decoded mono PCM16 sample.
 *
 * The PCM array is shared between piano engines and must be treated as
 * immutable after construction. Audio rendering will only read this data.
 */
internal class PianoPcmSample internal constructor(
    internal val pcm16: ShortArray,
    val sampleRate: Int = SAMPLE_RATE
) {
    init {
        require(pcm16.isNotEmpty()) { "Decoded piano sample is empty" }
        require(sampleRate == SAMPLE_RATE) {
            "Unsupported piano sample rate: $sampleRate"
        }
    }

    val frameCount: Int
        get() = pcm16.size

    val byteSize: Long
        get() = pcm16.size.toLong() * PCM_BYTES_PER_FRAME

    companion object {
        const val SAMPLE_RATE = 48_000
        const val PCM_BYTES_PER_FRAME = 2
    }
}

/**
 * A reference-counted handle to decoded PCM.
 *
 * Every successful acquisition must be released exactly once.
 */
internal class PianoSampleLease internal constructor(
    val sample: PianoPcmSample,
    private val releaseAction: () -> Unit
) : Closeable {

    private val released = AtomicBoolean(false)

    override fun close() {
        if (released.compareAndSet(false, true)) {
            releaseAction()
        }
    }

    val isReleased: Boolean
        get() = released.get()
}

/**
 * Shared decoded-sample cache for Piano 1 and Piano 2.
 *
 * This first implementation establishes cache ownership and eviction.
 * Asset loading, asynchronous requests and decoding are added separately.
 */
internal class PianoSampleBank(
    private val cacheLimitBytes: Long = DEFAULT_CACHE_LIMIT_BYTES
) : Closeable {

    private class CacheEntry(
        val sample: PianoPcmSample,
        var referenceCount: Int = 0
    )

    private val cacheLock = Any()

    // Access-order LinkedHashMap provides least-recently-used eviction.
    private val cache = LinkedHashMap<PianoSampleId, CacheEntry>(16, 0.75f, true)

    private var cachedPcmBytes = 0L
    private var closed = false

    init {
        require(cacheLimitBytes > 0L) {
            "Piano sample cache limit must be positive"
        }
    }

    val cachedBytes: Long
        get() = synchronized(cacheLock) { cachedPcmBytes }

    val cachedSampleCount: Int
        get() = synchronized(cacheLock) { cache.size }

    /**
     * Acquires an already cached sample.
     * Returns null when the sample is not currently cached.
     */
    internal fun acquireCached(id: PianoSampleId): PianoSampleLease? {
        synchronized(cacheLock) {
            if (closed) return null

            val entry = cache[id] ?: return null
            entry.referenceCount++

            return createLeaseLocked(entry)
        }
    }

    /**
     * Adds a decoded sample to the cache and returns a pinned lease.
     *
     * If the cache cannot safely accommodate the sample because its entries
     * are pinned, the sample is still returned through a transient lease but
     * is not counted as cached memory.
     */
    internal fun cacheDecodedSample(
        id: PianoSampleId,
        sample: PianoPcmSample
    ): PianoSampleLease? {
        synchronized(cacheLock) {
            if (closed) return null

            // Another request may have completed while this sample decoded.
            val existing = cache[id]
            if (existing != null) {
                existing.referenceCount++
                return createLeaseLocked(existing)
            }

            val entry = CacheEntry(sample, referenceCount = 1)
            val requiredBytes = sample.byteSize

            if (requiredBytes <= cacheLimitBytes &&
                evictUnpinnedUntilFitsLocked(requiredBytes)
            ) {
                cache[id] = entry
                cachedPcmBytes += requiredBytes
            }

            // If not cached, the lease still owns the entry until released.
            return createLeaseLocked(entry)
        }
    }

    internal fun assetPath(key: Int, layer: Int): String {
        require(key in 21..108 && layer in 1..4)
        val notes = arrayOf("C","Cs","D","Ds","E","F","Fs","G","Gs","A","As","B")
        val note = notes[key % 12] + (key / 12 - 1)
        return "meta-piano/ogg/INSPiano_Vel%02d_%s_01.ogg".format(layer,note)
    }

    private fun evictUnpinnedUntilFitsLocked(requiredBytes: Long): Boolean {
        if (requiredBytes > cacheLimitBytes) return false

        val iterator = cache.entries.iterator()

        while (cachedPcmBytes + requiredBytes > cacheLimitBytes &&
            iterator.hasNext()
        ) {
            val candidate = iterator.next()
            val entry = candidate.value

            if (entry.referenceCount == 0) {
                cachedPcmBytes -= entry.sample.byteSize
                iterator.remove()
            }
        }

        return cachedPcmBytes + requiredBytes <= cacheLimitBytes
    }

    private fun createLeaseLocked(entry: CacheEntry): PianoSampleLease {
        return PianoSampleLease(entry.sample) {
            releaseEntry(entry)
        }
    }

    private fun releaseEntry(entry: CacheEntry) {
        synchronized(cacheLock) {
            check(entry.referenceCount > 0) {
                "Piano sample reference count underflow"
            }
            entry.referenceCount--
        }
    }

    /**
     * Removes currently unpinned cache entries.
     * Pinned entries remain available until their leases are released.
     */
    internal fun clearUnpinned() {
        synchronized(cacheLock) {
            val iterator = cache.entries.iterator()

            while (iterator.hasNext()) {
                val entry = iterator.next().value
                if (entry.referenceCount == 0) {
                    cachedPcmBytes -= entry.sample.byteSize
                    iterator.remove()
                }
            }
        }
    }

    /**
     * Closes the bank and clears its cache.
     * The application must stop audio rendering and release active leases first.
     */
    override fun close() {
        synchronized(cacheLock) {
            if (closed) return

            closed = true
            cache.clear()
            cachedPcmBytes = 0L
        }
    }

    companion object {
        const val DEFAULT_CACHE_LIMIT_BYTES = 32L * 1024L * 1024L
    }
}
