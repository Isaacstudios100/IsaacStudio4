package com.isaacstudio.studio4.audio.instruments

import android.content.res.AssetManager
import java.io.Closeable
import java.util.LinkedHashMap
import java.util.concurrent.Executor
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Identifies one piano sample by MIDI key and SFZ velocity layer.
 */
internal data class PianoSampleId(
    val key: Int,
    val velocityLayer: Int
) {
    init {
        require(key in MIN_KEY..MAX_KEY) { "Piano key out of range: $key" }
        require(velocityLayer in MIN_VELOCITY_LAYER..MAX_VELOCITY_LAYER) {
            "Piano velocity layer out of range: $velocityLayer"
        }
    }

    companion object {
        const val MIN_KEY = 21
        const val MAX_KEY = 108
        const val MIN_VELOCITY_LAYER = 1
        const val MAX_VELOCITY_LAYER = 4
    }
}

internal fun PianoSampleId.assetPath(): String {
    val notes = arrayOf("C","Cs","D","Ds","E","F","Fs","G","Gs","A","As","B")
    val note = notes[key % 12] + (key / 12 - 1)
    return "meta-piano/ogg/INSPiano_Vel%02d_%s_01.ogg".format(velocityLayer, note)
}

/**
 * Decoded mono PCM16 sample. Treat pcm16 as immutable after construction.
 */
internal class PianoPcmSample internal constructor(
    internal val pcm16: ShortArray,
    val sampleRate: Int = SAMPLE_RATE
) {
    init {
        require(pcm16.isNotEmpty()) { "Decoded piano sample is empty" }
        require(sampleRate == SAMPLE_RATE) {
            "Unsupported piano sample rate: $sampleRate"
        }
    }

    val frameCount: Int
        get() = pcm16.size

    val byteSize: Long
        get() = pcm16.size.toLong() * PCM_BYTES_PER_FRAME

    companion object {
        const val SAMPLE_RATE = 48_000
        const val PCM_BYTES_PER_FRAME = 2
    }
}

/**
 * A reference-counted handle to decoded PCM.
 * Every successful acquisition must be released exactly once.
 */
internal class PianoSampleLease internal constructor(
    val sample: PianoPcmSample,
    private val releaseAction: () -> Unit
) : Closeable {

    private val released = AtomicBoolean(false)

    override fun close() {
        if (released.compareAndSet(false, true)) {
            releaseAction()
        }
    }

    val isReleased: Boolean
        get() = released.get()
}

/**
 * Cancellable handle for one asynchronous sample request.
 *
 * Cancellation prevents delivery if it happens before the callback begins.
 * Once delivered, the callback owns the lease and must close it.
 */
internal class PianoSampleRequest internal constructor() {
    private val cancelled = AtomicBoolean(false)

    fun cancel() {
        cancelled.set(true)
    }

    val isCancelled: Boolean
        get() = cancelled.get()
}

/**
 * Shared decoded-sample cache and asynchronous loader for Piano 1 and Piano 2.
 *
 * Do not call requestSample() from the audio render thread. It performs
 * short synchronized bookkeeping; decoding itself always runs on workers.
 */
internal class PianoSampleBank(
    assets: AssetManager,
    private val cacheLimitBytes: Long = DEFAULT_CACHE_LIMIT_BYTES
) : Closeable {

    private class CacheEntry(
        val sample: PianoPcmSample,
        val referenceCount: AtomicInteger = AtomicInteger(0)
    )

    private class PendingRequest(
        val request: PianoSampleRequest,
        val callbackExecutor: Executor,
        val callback: (PianoSampleLease?) -> Unit
    )

    private val decoder = PianoSampleDecoder(assets)
    private val cacheLock = Any()
    private val requestLock = Any()

    // Access-order LinkedHashMap provides least-recently-used eviction.
    private val cache = LinkedHashMap<PianoSampleId, CacheEntry>(16, 0.75f, true)
    private val inFlight = HashMap<PianoSampleId, MutableList<PendingRequest>>()

    // Two workers limit simultaneous decode scratch memory.
    private val decodeExecutor: ExecutorService =
        Executors.newFixedThreadPool(2) { task ->
            Thread(task, "Isaac-Piano-Sample-Decode").apply {
                isDaemon = true
            }
        }

    private var cachedPcmBytes = 0L
    private var closed = false
    private var requestsClosed = false

    init {
        require(cacheLimitBytes > 0L) {
            "Piano sample cache limit must be positive"
        }
    }

    val cachedBytes: Long
        get() = synchronized(cacheLock) { cachedPcmBytes }

    val cachedSampleCount: Int
        get() = synchronized(cacheLock) { cache.size }

    /**
     * Acquires an already cached sample, or returns null on a cache miss.
     */
    internal fun acquireCached(id: PianoSampleId): PianoSampleLease? {
        synchronized(cacheLock) {
            if (closed) return null

            val entry = cache[id] ?: return null
            entry.referenceCount.incrementAndGet()
            return createLeaseLocked(entry)
        }
    }

    /**
     * Requests a sample asynchronously.
     *
     * Concurrent requests for the same ID share one decode operation.
     * Each successful callback receives its own independently releasable lease.
     * The callback receives null if decoding fails or the bank is closed.
     */
    internal fun requestSample(
        id: PianoSampleId,
        callbackExecutor: Executor,
        callback: (PianoSampleLease?) -> Unit
    ): PianoSampleRequest {
        val request = PianoSampleRequest()
        val pending = PendingRequest(request, callbackExecutor, callback)

        var dispatchImmediate = false
        var immediateLease: PianoSampleLease? = null
        var failedRequests: List<PendingRequest> = emptyList()

        synchronized(requestLock) {
            if (requestsClosed) {
                dispatchImmediate = true
            } else {
                val cachedLease = acquireCached(id)
                if (cachedLease != null) {
                    immediateLease = cachedLease
                    dispatchImmediate = true
                } else {
                    val existing = inFlight[id]
                    if (existing != null) {
                        existing.add(pending)
                    } else {
                        inFlight[id] = mutableListOf(pending)
                        try {
                            decodeExecutor.execute {
                                decodeAndDeliver(id)
                            }
                        } catch (_: RejectedExecutionException) {
                            failedRequests = inFlight.remove(id).orEmpty()
                        }
                    }
                }
            }
        }

        // Never execute caller-provided callbacks while holding requestLock.
        if (dispatchImmediate) dispatch(pending, immediateLease)
        failedRequests.forEach { dispatch(it, null) }

        return request
    }

    private fun decodeAndDeliver(id: PianoSampleId) {
        val decoded = try {
            decoder.decode(id)
        } catch (_: Exception) {
            null
        } catch (_: LinkageError) {
            null
        }

        // Publish decoded PCM before removing the in-flight marker.
        // A concurrent request therefore sees the cache instead of starting
        // a second decode for the same sample.
        val deliveries = synchronized(requestLock) {
            val waiting = inFlight[id].orEmpty()
            val results = waiting.map { pending ->
                val lease = if (pending.request.isCancelled) {
                    null
                } else {
                    decoded?.let { cacheDecodedSample(id, it) }
                }
                pending to lease
            }
            inFlight.remove(id)
            results
        }

        deliveries.forEach { (pending, lease) ->
            dispatch(pending, lease)
        }
    }

    private fun dispatch(
        pending: PendingRequest,
        lease: PianoSampleLease?
    ) {
        try {
            pending.callbackExecutor.execute {
                val bankClosed = synchronized(requestLock) { requestsClosed }
                if (pending.request.isCancelled || bankClosed) {
                    lease?.close()
                } else {
                    try {
                        pending.callback(lease)
                    } catch (_: Exception) {
                        lease?.close()
                    }
                }
            }
        } catch (_: RejectedExecutionException) {
            lease?.close()
        }
    }

    /**
     * Adds decoded PCM to the cache and returns a pinned lease.
     * If all cache entries are pinned, a transient lease is returned instead.
     */
    internal fun cacheDecodedSample(
        id: PianoSampleId,
        sample: PianoPcmSample
    ): PianoSampleLease? {
        synchronized(cacheLock) {
            if (closed) return null

            val existing = cache[id]
            if (existing != null) {
                existing.referenceCount.incrementAndGet()
                return createLeaseLocked(existing)
            }

            val entry = CacheEntry(sample, referenceCount = AtomicInteger(1))
            val requiredBytes = sample.byteSize

            if (requiredBytes <= cacheLimitBytes &&
                evictUnpinnedUntilFitsLocked(requiredBytes)
            ) {
                cache[id] = entry
                cachedPcmBytes += requiredBytes
            }

            return createLeaseLocked(entry)
        }
    }

    internal fun assetPath(key: Int, layer: Int): String {
        return PianoSampleId(key, layer).assetPath()
    }

    private fun evictUnpinnedUntilFitsLocked(requiredBytes: Long): Boolean {
        if (requiredBytes > cacheLimitBytes) return false

        val iterator = cache.entries.iterator()
        while (cachedPcmBytes + requiredBytes > cacheLimitBytes &&
            iterator.hasNext()
        ) {
            val entry = iterator.next().value
            if (entry.referenceCount.get() == 0) {
                cachedPcmBytes -= entry.sample.byteSize
                iterator.remove()
            }
        }

        return cachedPcmBytes + requiredBytes <= cacheLimitBytes
    }

    private fun createLeaseLocked(entry: CacheEntry): PianoSampleLease {
        return PianoSampleLease(entry.sample) {
            releaseEntry(entry)
        }
    }

    private fun releaseEntry(entry: CacheEntry) {
        val remaining = entry.referenceCount.decrementAndGet()
        check(remaining >= 0) {
            "Piano sample reference count underflow"
        }
    }

    /**
     * Removes unpinned entries. Active leases remain valid.
     */
    internal fun clearUnpinned() {
        synchronized(cacheLock) {
            val iterator = cache.entries.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next().value
                if (entry.referenceCount.get() == 0) {
                    cachedPcmBytes -= entry.sample.byteSize
                    iterator.remove()
                }
            }
        }
    }

    /**
     * Stop requests and workers before clearing the cache.
     * Active audio leases must be released before closing the bank.
     */
    override fun close() {
        synchronized(requestLock) {
            if (requestsClosed) return
            requestsClosed = true

            inFlight.values.flatten().forEach { it.request.cancel() }
            inFlight.clear()
            decodeExecutor.shutdownNow()
        }

        synchronized(cacheLock) {
            closed = true
            cache.clear()
            cachedPcmBytes = 0L
        }
    }

    companion object {
        const val DEFAULT_CACHE_LIMIT_BYTES = 32L * 1024L * 1024L
    }
}
