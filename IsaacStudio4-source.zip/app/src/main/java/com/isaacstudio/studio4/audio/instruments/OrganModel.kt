package com.isaacstudio.studio4.audio.instruments

enum class OrganModel(val displayName: String) {
    B3("B3"),
    B3_BASS("B3 Bass"),
    VOX("Vox"),
    FARFISA("Farfisa"),
    PIPE_1("Pipe 1"),
    PIPE_2("Pipe 2")
}
