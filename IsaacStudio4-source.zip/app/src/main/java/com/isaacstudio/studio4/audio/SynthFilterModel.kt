package com.isaacstudio.studio4.audio

enum class SynthFilterMode {
    BYPASS,
    LOW_PASS_12,
    LOW_PASS_24,
    LADDER,
    HIGH_PASS,
    BAND_PASS,
    LOW_PASS_BAND_PASS
}

data class SynthFilterSettings(
    val mode: SynthFilterMode = SynthFilterMode.BYPASS,
    val cutoffHz: Float = 12000f,
    val resonance: Float = 0.1f,
    val drive: Float = 0f
)
