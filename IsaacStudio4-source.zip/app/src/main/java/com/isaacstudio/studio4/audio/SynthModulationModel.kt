package com.isaacstudio.studio4.audio

data class SynthModulationSettings(
    val filterAttack: Float = 0.01f,
    val filterDecay: Float = 0.3f,
    val filterSustain: Float = 0f,
    val filterRelease: Float = 0.3f,
    val filterEnvelopeAmountOctaves: Float = 0f,
    val velocityToVolume: Float = 1f,
    val velocityToFilterOctaves: Float = 0f
)
