package com.isaacstudio.studio4.audio.instruments

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

class PianoEngine {

    companion object {
        private const val SAMPLE_RATE = 44100
        private const val VOICE_COUNT = 16
    }

    private data class Voice(
        var note: Int = -1,
        var phase: Double = 0.0,
        var velocity: Double = 0.0,
        var age: Long = 0,
        var active: Boolean = false,
        var releasing: Boolean = false,
        var releaseLevel: Double = 1.0,
        var releaseAge: Long = 0
    )

    private val voices = Array(VOICE_COUNT) { Voice() }

    @Volatile
    private var running = true

    private val audioTrack: AudioTrack

    init {
        val minBuffer = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuffer, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack.play()

        Thread {
            renderAudio()
        }.start()
    }

    fun noteOn(note: Int, velocity: Float = 0.8f) {
        synchronized(voices) {
            val voice = voices.firstOrNull { !it.active }
                ?: voices.minByOrNull { it.age }

            voice?.apply {
                this.note = note.coerceIn(0, 127)
                phase = 0.0
                this.velocity = velocity.coerceIn(0f, 1f).toDouble()
                age = 0
                active = true
                releasing = false
                releaseLevel = 1.0
                releaseAge = 0
            }
        }
    }

    fun noteOff(note: Int) {
        synchronized(voices) {
            voices.filter {
                it.active && it.note == note && !it.releasing
            }.forEach {
                it.releasing = true
                it.releaseLevel = envelope(it.age)
                it.releaseAge = 0
            }
        }
    }

    private fun envelope(age: Long): Double {
        val seconds = age.toDouble() / SAMPLE_RATE

        return when {
            seconds < 0.015 -> seconds / 0.015
            else -> exp(-(seconds - 0.015) * 1.8)
        }
    }

    private fun renderAudio() {
        val buffer = FloatArray(512)

        while (running) {
            synchronized(voices) {
                for (i in buffer.indices) {
                    var sample = 0.0

                    for (voice in voices) {
                        if (!voice.active) continue

                        val frequency = 440.0 *
                            2.0.pow((voice.note - 69) / 12.0)

                        val angle = 2.0 * PI * voice.phase

                        val tone =
                            sin(angle) * 1.0 +
                            sin(angle * 2.0) * 0.35 +
                            sin(angle * 3.0) * 0.15 +
                            sin(angle * 4.0) * 0.07

                        var amplitude = envelope(voice.age)

                        if (voice.releasing) {
                            val releaseTime =
                                voice.releaseAge.toDouble() / SAMPLE_RATE

                            amplitude = voice.releaseLevel *
                                exp(-releaseTime * 8.0)
                        }

                        sample += tone *
                            amplitude *
                            voice.velocity

                        voice.phase += frequency / SAMPLE_RATE
                        if (voice.phase >= 1.0) {
                            voice.phase -= 1.0
                        }

                        voice.age++

                        if (voice.releasing) {
                            voice.releaseAge++

                            if (amplitude < 0.001) {
                                voice.active = false
                                voice.note = -1
                            }
                        }
                    }

                    buffer[i] = (sample * 0.12)
                        .coerceIn(-1.0, 1.0)
                        .toFloat()
                }
            }

            audioTrack.write(
                buffer,
                0,
                buffer.size,
                AudioTrack.WRITE_BLOCKING
            )
        }
    }

    fun stop() {
        running = false

        try {
            audioTrack.pause()
            audioTrack.flush()
            audioTrack.stop()
            audioTrack.release()
        } catch (_: Exception) {
        }
    }
}
