package com.isaacstudio.studio4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.isaacstudio.studio4.audio.SynthEngine
import com.isaacstudio.studio4.audio.Waveform
import com.isaacstudio.studio4.midi.MidiInput

private val WHITE_KEYS = listOf(
    60, 62, 64, 65, 67, 69, 71,
    72, 74, 76, 77, 79, 81, 83, 84
)

private data class BlackKey(
    val note: Int,
    val afterWhiteIndex: Int
)

private val BLACK_KEYS = listOf(
    BlackKey(61, 0),
    BlackKey(63, 1),
    BlackKey(66, 3),
    BlackKey(68, 4),
    BlackKey(70, 5),
    BlackKey(73, 7),
    BlackKey(75, 8),
    BlackKey(78, 10),
    BlackKey(80, 11),
    BlackKey(82, 12)
)

private val WHITE_KEY_WIDTH = 42.dp
private val BLACK_KEY_WIDTH = 26.dp

class MainActivity : ComponentActivity() {

    private val synth = SynthEngine()
    private var midi: MidiInput? = null
    private var status by mutableStateOf("Starting...")

    private var waveform by mutableStateOf(Waveform.SAWTOOTH)
    private var volume by mutableStateOf(0.7f)
    private var octave by mutableStateOf(0)

    private var attack by mutableStateOf(0.005f)
    private var decay by mutableStateOf(0.12f)
    private var sustain by mutableStateOf(0.7f)
    private var release by mutableStateOf(0.3f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        synth.start()

        midi = MidiInput(
            context = this,
            onNoteOn = { note, velocity ->
                synth.noteOn(note, velocity)
            },
            onNoteOff = { note ->
                synth.noteOff(note)
            },
            onStatus = { text ->
                status = text
            }
        ).also { it.start() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF101116)
                ) {
                    StudioScreen(
                        status = status,
                        waveform = waveform,
                        volume = volume,
                        octave = octave,
                        attack = attack,
                        decay = decay,
                        sustain = sustain,
                        release = release,

                        onWaveformChange = {
                            waveform = it
                            synth.waveform = it
                        },

                        onVolumeChange = {
                            volume = it
                            synth.volume = it
                        },

                        onOctaveChange = {
                            octave = it
                            synth.transposeSemitones = it * 12
                        },

                        onAttackChange = {
                            attack = it
                            synth.attack = it
                        },

                        onDecayChange = {
                            decay = it
                            synth.decay = it
                        },

                        onSustainChange = {
                            sustain = it
                            synth.sustain = it
                        },

                        onReleaseChange = {
                            release = it
                            synth.release = it
                        },

                        onNoteOn = { note, velocity ->
                            synth.noteOn(note, velocity)
                        },

                        onNoteOff = { note ->
                            synth.noteOff(note)
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        midi?.stop()
        synth.stop()
        super.onDestroy()
    }
}

@Composable
fun StudioScreen(
    status: String,
    waveform: Waveform,
    volume: Float,
    octave: Int,
    attack: Float,
    decay: Float,
    sustain: Float,
    release: Float,
    onWaveformChange: (Waveform) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onOctaveChange: (Int) -> Unit,
    onAttackChange: (Float) -> Unit,
    onDecayChange: (Float) -> Unit,
    onSustainChange: (Float) -> Unit,
    onReleaseChange: (Float) -> Unit,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {

        Text(
            "ISAAC STUDIO 4",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White
        )

        Text(
            "STAGE 3B | SYNTHESIZER",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF91A9FF)
        )

        Text(
            status,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFB8C4D9)
        )

        Spacer(Modifier.height(8.dp))

        Text("WAVEFORM", color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Waveform.values().forEach { type ->
                Button(
                    onClick = { onWaveformChange(type) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (waveform == type) {
                            "✓ " + type.name.take(3)
                        } else {
                            type.name.take(3)
                        },
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        Text(
            "MASTER VOLUME: ${(volume * 100).toInt()}%",
            color = Color.White
        )

        Slider(
            value = volume,
            onValueChange = onVolumeChange,
            valueRange = 0f..1f
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("OCTAVE", color = Color.White)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { onOctaveChange((octave - 1).coerceAtLeast(-2)) }
                ) {
                    Text("−")
                }

                Text(
                    text = if (octave > 0) "+$octave" else octave.toString(),
                    color = Color(0xFF91A9FF),
                    modifier = Modifier.padding(horizontal = 14.dp)
                )

                Button(
                    onClick = { onOctaveChange((octave + 1).coerceAtMost(2)) }
                ) {
                    Text("+")
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Text(
            "ENVELOPE (ADSR)",
            color = Color(0xFF91A9FF),
            style = MaterialTheme.typography.titleMedium
        )

        EnvelopeControl(
            "ATTACK",
            "${(attack * 1000).toInt()} ms",
            attack,
            0.001f..2f,
            onAttackChange
        )

        EnvelopeControl(
            "DECAY",
            "${(decay * 1000).toInt()} ms",
            decay,
            0.001f..2f,
            onDecayChange
        )

        EnvelopeControl(
            "SUSTAIN",
            "${(sustain * 100).toInt()}%",
            sustain,
            0f..1f,
            onSustainChange
        )

        EnvelopeControl(
            "RELEASE",
            "${(release * 1000).toInt()} ms",
            release,
            0.01f..3f,
            onReleaseChange
        )

        Spacer(Modifier.height(8.dp))

        Text(
            "TWO-OCTAVE KEYBOARD",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall
        )

        Text(
            "Swipe left or right to explore the keys",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .width(WHITE_KEY_WIDTH * WHITE_KEYS.size)
                    .height(220.dp)
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    WHITE_KEYS.forEach { note ->
                        PianoKey(
                            note = note,
                            label = when (note) {
                                60 -> "C${4 + octave}"
                                72 -> "C${5 + octave}"
                                84 -> "C${6 + octave}"
                                else -> ""
                            },
                            black = false,
                            onNoteOn = onNoteOn,
                            onNoteOff = onNoteOff,
                            modifier = Modifier
                                .width(WHITE_KEY_WIDTH)
                                .fillMaxHeight()
                        )
                    }
                }

                BLACK_KEYS.forEach { key ->
                    PianoKey(
                        note = key.note,
                        label = "",
                        black = true,
                        onNoteOn = onNoteOn,
                        onNoteOff = onNoteOff,
                        modifier = Modifier
                            .offset(
                                x = WHITE_KEY_WIDTH *
                                    (key.afterWhiteIndex + 1) -
                                    BLACK_KEY_WIDTH / 2
                            )
                            .width(BLACK_KEY_WIDTH)
                            .height(130.dp)
                    )
                }
            }
        }

        Text(
            "ISAAC STUDIO 4 • DIGITAL INSTRUMENT",
            color = Color(0xFF77829A),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun EnvelopeControl(
    name: String,
    displayValue: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(name, color = Color.White)
            Text(displayValue, color = Color(0xFF91A9FF))
        }

        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range
        )
    }
}

@Composable
private fun PianoKey(
    note: Int,
    label: String,
    black: Boolean,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    val keyColor = when {
        black && pressed -> Color(0xFF526DAA)
        black -> Color(0xFF171923)
        pressed -> Color(0xFFB0C4FF)
        else -> Color.White
    }

    val shape = RoundedCornerShape(
        bottomStart = 5.dp,
        bottomEnd = 5.dp
    )

    Box(
        modifier = modifier
            .background(keyColor, shape)
            .border(
                width = 0.7.dp,
                color = if (black) Color.Black else Color(0xFFB8B8B8),
                shape = shape
            )
            .pointerInput(note) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onNoteOn(note, 0.8f)
                        tryAwaitRelease()
                        pressed = false
                        onNoteOff(note)
                    }
                )
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        if (label.isNotEmpty()) {
            Text(
                text = label,
                color = Color.DarkGray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}
