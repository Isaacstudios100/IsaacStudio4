package com.isaacstudio.studio4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.isaacstudio.studio4.audio.SynthEngine
import com.isaacstudio.studio4.midi.MidiInput

// C4 to C6, white keys only for stage 1
private val WHITE_KEYS = listOf(60, 62, 64, 65, 67, 69, 71, 72, 74, 76, 77, 79, 81, 83, 84)

class MainActivity : ComponentActivity() {

    private val synth = SynthEngine()
    private var midi: MidiInput? = null
    private var status by mutableStateOf("Starting...")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        synth.start()

        midi = MidiInput(
            context = this,
            onNoteOn = { note, velocity -> synth.noteOn(note, velocity) },
            onNoteOff = { note -> synth.noteOff(note) },
            onStatus = { text -> status = text }
        ).also { it.start() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    StudioScreen(
                        status = status,
                        onNoteOn = { note, velocity -> synth.noteOn(note, velocity) },
                        onNoteOff = { note -> synth.noteOff(note) }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        midi?.stop()
        synth.stop()
        super.onDestroy()
    }
}

@Composable
fun StudioScreen(
    status: String,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Isaac Studio 4", style = MaterialTheme.typography.headlineMedium)
        Text(status, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth().weight(1f)) {
            WHITE_KEYS.forEach { note ->
                PianoKey(
                    note = note,
                    onNoteOn = onNoteOn,
                    onNoteOff = onNoteOff,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
    }
}

@Composable
private fun PianoKey(
    note: Int,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    Row(
        modifier
            .padding(horizontal = 1.dp)
            .background(
                if (pressed) Color(0xFFB0C4FF) else Color.White,
                RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)
            )
            .pointerInput(note) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onNoteOn(note, 0.8f)
                        tryAwaitRelease()
                        pressed = false
                        onNoteOff(note)
                    }
                )
            }
    ) {}
}
