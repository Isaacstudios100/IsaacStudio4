package com.isaacstudio.studio4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.isaacstudio.studio4.audio.SynthEngine
import com.isaacstudio.studio4.midi.MidiInput

private val WHITE_KEYS = listOf(
    60, 62, 64, 65, 67, 69, 71,
    72, 74, 76, 77, 79, 81, 83, 84
)

private data class BlackKey(
    val note: Int,
    val afterWhiteIndex: Int
)

private val BLACK_KEYS = listOf(
    BlackKey(61, 0),
    BlackKey(63, 1),
    BlackKey(66, 3),
    BlackKey(68, 4),
    BlackKey(70, 5),
    BlackKey(73, 7),
    BlackKey(75, 8),
    BlackKey(78, 10),
    BlackKey(80, 11),
    BlackKey(82, 12)
)

private val WHITE_KEY_WIDTH = 42.dp
private val BLACK_KEY_WIDTH = 26.dp

class MainActivity : ComponentActivity() {

    private val synth = SynthEngine()
    private var midi: MidiInput? = null
    private var status by mutableStateOf("Starting...")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        synth.start()

        midi = MidiInput(
            context = this,
            onNoteOn = { note, velocity ->
                synth.noteOn(note, velocity)
            },
            onNoteOff = { note ->
                synth.noteOff(note)
            },
            onStatus = { text ->
                status = text
            }
        ).also { it.start() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF101116)
                ) {
                    StudioScreen(
                        status = status,
                        onNoteOn = { note, velocity ->
                            synth.noteOn(note, velocity)
                        },
                        onNoteOff = { note ->
                            synth.noteOff(note)
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        midi?.stop()
        synth.stop()
        super.onDestroy()
    }
}

@Composable
fun StudioScreen(
    status: String,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "ISAAC STUDIO 4",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White
        )

        Text(
            "STAGE 2  |  PIANO",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF91A9FF)
        )

        Text(
            status,
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFFB8C4D9)
        )

        Spacer(Modifier.height(20.dp))

        Text(
            "TWO-OCTAVE KEYBOARD",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall
        )

        Text(
            "Swipe left or right to explore the keys",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .width(WHITE_KEY_WIDTH * WHITE_KEYS.size)
                    .height(250.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize()
                ) {
                    WHITE_KEYS.forEach { note ->
                        PianoKey(
                            note = note,
                            label = when (note) {
                                60 -> "C4"
                                72 -> "C5"
                                84 -> "C6"
                                else -> ""
                            },
                            black = false,
                            onNoteOn = onNoteOn,
                            onNoteOff = onNoteOff,
                            modifier = Modifier
                                .width(WHITE_KEY_WIDTH)
                                .fillMaxHeight()
                        )
                    }
                }

                BLACK_KEYS.forEach { key ->
                    PianoKey(
                        note = key.note,
                        label = "",
                        black = true,
                        onNoteOn = onNoteOn,
                        onNoteOff = onNoteOff,
                        modifier = Modifier
                            .offset(
                                x = WHITE_KEY_WIDTH *
                                    (key.afterWhiteIndex + 1) -
                                    BLACK_KEY_WIDTH / 2
                            )
                            .width(BLACK_KEY_WIDTH)
                            .height(145.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Text(
            "ISAAC STUDIO 4  •  DIGITAL INSTRUMENT",
            color = Color(0xFF77829A),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun PianoKey(
    note: Int,
    label: String,
    black: Boolean,
    onNoteOn: (Int, Float) -> Unit,
    onNoteOff: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }

    val keyColor = when {
        black && pressed -> Color(0xFF526DAA)
        black -> Color(0xFF171923)
        pressed -> Color(0xFFB0C4FF)
        else -> Color.White
    }

    val shape = RoundedCornerShape(
        bottomStart = 5.dp,
        bottomEnd = 5.dp
    )

    Box(
        modifier = modifier
            .background(keyColor, shape)
            .border(
                width = 0.7.dp,
                color = if (black) Color.Black else Color(0xFFB8B8B8),
                shape = shape
            )
            .pointerInput(note) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        onNoteOn(note, 0.8f)
                        tryAwaitRelease()
                        pressed = false
                        onNoteOff(note)
                    }
                )
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        if (label.isNotEmpty()) {
            Text(
                text = label,
                color = Color.DarkGray,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}
