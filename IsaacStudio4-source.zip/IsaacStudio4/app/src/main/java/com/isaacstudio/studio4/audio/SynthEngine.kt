package com.isaacstudio.studio4.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

/**
 * Simple polyphonic synth. Renders audio on its own thread and writes it
 * to an AudioTrack. Output goes to whatever device Android routes to,
 * including a USB audio device connected to the keyboard.
 */
class SynthEngine {

    private val sampleRate = 44100
    private val bufferFrames = 256
    private val voices = Array(8) { Voice() }
    private val lock = Any()

    private var track: AudioTrack? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    var volume = 0.7f

    private class Voice {
        var note = -1
        var freq = 0.0
        var velocity = 0f
        var phase = 0.0
        var env = 0.0
        var releasing = false
    }

    fun start() {
        if (running) return

        val minBytes = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )

        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBytes * 2)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        running = true
        track?.play()
        thread = Thread({ renderLoop() }, "IsaacStudio4-Audio").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun stop() {
        running = false
        thread?.join()
        thread = null
        track?.stop()
        track?.release()
        track = null
    }

    fun noteOn(note: Int, velocity: Float) {
        synchronized(lock) {
            val voice = voices.firstOrNull { it.note < 0 }
                ?: voices.firstOrNull { it.releasing }
                ?: voices[0]
            voice.note = note
            voice.freq = 440.0 * 2.0.pow((note - 69) / 12.0)
            voice.velocity = velocity.coerceIn(0f, 1f)
            voice.env = 0.0
            voice.releasing = false
        }
    }

    fun noteOff(note: Int) {
        synchronized(lock) {
            voices.filter { it.note == note && !it.releasing }
                .forEach { it.releasing = true }
        }
    }

    private fun renderLoop() {
        val buffer = FloatArray(bufferFrames)
        val attackStep = 1.0 / (0.005 * sampleRate)
        val releaseStep = 1.0 / (0.3 * sampleRate)
        val twoPi = 2.0 * PI

        while (running) {
            synchronized(lock) {
                for (i in 0 until bufferFrames) {
                    var mix = 0.0
                    for (v in voices) {
                        if (v.note < 0) continue

                        if (v.releasing) {
                            v.env -= releaseStep
                            if (v.env <= 0.0) {
                                v.note = -1
                                v.env = 0.0
                                continue
                            }
                        } else if (v.env < 1.0) {
                            v.env = minOf(1.0, v.env + attackStep)
                        }

                        val saw = 2.0 * v.phase - 1.0
                        val tone = 0.6 * saw + 0.4 * sin(twoPi * v.phase)
                        mix += tone * v.env * v.velocity

                        v.phase += v.freq / sampleRate
                        if (v.phase >= 1.0) v.phase -= 1.0
                    }
                    buffer[i] = (mix * volume * 0.3).toFloat().coerceIn(-1f, 1f)
                }
            }
            track?.write(buffer, 0, bufferFrames, AudioTrack.WRITE_BLOCKING)
        }
    }
}
