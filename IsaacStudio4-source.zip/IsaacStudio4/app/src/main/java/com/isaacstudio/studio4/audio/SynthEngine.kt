package com.isaacstudio.studio4.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.abs

enum class Waveform {
    SINE, TRIANGLE, SAWTOOTH, SQUARE
}

class SynthEngine {

    private val sampleRate = 44100
    private val bufferFrames = 256
    private val voices = Array(16) { Voice() }
    private val lock = Any()

    private var track: AudioTrack? = null
    private var thread: Thread? = null

    @Volatile private var running = false

    @Volatile var volume = 0.7f
    @Volatile var waveform = Waveform.SAWTOOTH
    @Volatile var transposeSemitones = 0

    @Volatile var attack = 0.005f
    @Volatile var decay = 0.12f
    @Volatile var sustain = 0.7f
    @Volatile var release = 0.3f

    private enum class Stage {
        OFF, ATTACK, DECAY, SUSTAIN, RELEASE
    }

    private class Voice {
        var note = -1
        var sourceNote = -1
        var freq = 0.0
        var velocity = 0f
        var phase = 0.0
        var env = 0.0
        var releaseLevel = 0.0
        var stage = Stage.OFF
    }

    fun start() {
        if (running) return

        val minBytes = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )

        if (minBytes <= 0) return

        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBytes * 2)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        running = true
        track?.play()

        thread = Thread({ renderLoop() }, "IsaacStudio4-Audio").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun stop() {
        running = false
        thread?.join()
        thread = null
        track?.stop()
        track?.release()
        track = null
    }

    fun noteOn(note: Int, velocity: Float) {
        synchronized(lock) {
            val voice = voices.firstOrNull { it.stage == Stage.OFF }
                ?: voices.firstOrNull { it.stage == Stage.RELEASE }
                ?: voices[0]

            val playedNote = note + transposeSemitones

            voice.note = playedNote
            voice.sourceNote = note
            voice.freq = 440.0 * 2.0.pow((playedNote - 69) / 12.0)
            voice.velocity = velocity.coerceIn(0f, 1f)
            voice.phase = 0.0
            voice.env = 0.0
            voice.releaseLevel = 0.0
            voice.stage = Stage.ATTACK
        }
    }

    fun noteOff(note: Int) {
        synchronized(lock) {
            val playedNote = note + transposeSemitones

            voices.filter {
                it.sourceNote == note && it.stage != Stage.OFF &&
                    it.stage != Stage.RELEASE
            }.forEach {
                it.releaseLevel = it.env
                it.stage = Stage.RELEASE
            }
        }
    }

    private fun waveformSample(phase: Double): Double {
        return when (waveform) {
            Waveform.SINE -> sin(2.0 * PI * phase)
            Waveform.TRIANGLE -> 1.0 - 4.0 * abs(phase - 0.5)
            Waveform.SAWTOOTH -> 2.0 * phase - 1.0
            Waveform.SQUARE -> if (phase < 0.5) 1.0 else -1.0
        }
    }

    private fun renderLoop() {
        val buffer = FloatArray(bufferFrames)
        val twoPi = 2.0 * PI

        while (running) {
            synchronized(lock) {
                for (i in 0 until bufferFrames) {
                    var mix = 0.0

                    for (v in voices) {
                        if (v.stage == Stage.OFF) continue

                        when (v.stage) {
                            Stage.ATTACK -> {
                                val step = 1.0 / (attack.coerceAtLeast(0.001f) * sampleRate)
                                v.env = minOf(1.0, v.env + step)
                                if (v.env >= 1.0) {
                                    v.stage = Stage.DECAY
                                }
                            }

                            Stage.DECAY -> {
                                val target = sustain.coerceIn(0f, 1f).toDouble()
                                val step = (1.0 - target) /
                                    (decay.coerceAtLeast(0.001f) * sampleRate)
                                v.env = maxOf(target, v.env - step)
                                if (v.env <= target) {
                                    v.stage = Stage.SUSTAIN
                                }
                            }

                            Stage.SUSTAIN -> {
                                v.env = sustain.coerceIn(0f, 1f).toDouble()
                            }

                            Stage.RELEASE -> {
                                val step = v.releaseLevel /
                                    (release.coerceAtLeast(0.01f) * sampleRate)
                                v.env = maxOf(0.0, v.env - step)
                                if (v.env <= 0.0) {
                                    v.note = -1
                                    v.sourceNote = -1
                                    v.stage = Stage.OFF
                                    continue
                                }
                            }

                            Stage.OFF -> continue
                        }

                        val tone = waveformSample(v.phase)
                        mix += tone * v.env * v.velocity

                        v.phase += v.freq / sampleRate
                        if (v.phase >= 1.0) v.phase -= 1.0
                    }

                    buffer[i] = (mix * volume.coerceIn(0f, 1f) * 0.2)
                        .toFloat()
                        .coerceIn(-1f, 1f)
                }
            }

            track?.write(
                buffer,
                0,
                bufferFrames,
                AudioTrack.WRITE_BLOCKING
            )
        }
    }
}
