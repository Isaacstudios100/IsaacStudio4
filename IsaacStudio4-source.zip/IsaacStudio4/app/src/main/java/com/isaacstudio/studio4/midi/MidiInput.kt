package com.isaacstudio.studio4.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import java.io.IOException

/**
 * Listens for USB MIDI devices (such as the keyboard) and forwards
 * note on/off messages with velocity to the callbacks.
 */
class MidiInput(
    context: Context,
    private val onNoteOn: (note: Int, velocity: Float) -> Unit,
    private val onNoteOff: (note: Int) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
    private val handler = Handler(Looper.getMainLooper())
    private val openDevices = mutableMapOf<Int, MidiDevice>()
    private val openPorts = mutableListOf<MidiOutputPort>()

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            openDevice(info)
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            onStatus("MIDI keyboard disconnected")
        }
    }

    private val receiver = object : MidiReceiver() {
        override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
            var i = offset
            val end = offset + count
            while (i < end) {
                val status = data[i].toInt() and 0xFF
                if ((status and 0x80) == 0) {       // running status not handled
                    i++
                    continue
                }
                if (status >= 0xF0) {                // system messages, skip one byte
                    i++
                    continue
                }
                val type = status and 0xF0
                val needed = if (type == 0xC0 || type == 0xD0) 2 else 3
                if (i + needed > end) break

                if (type == 0x90 || type == 0x80) {
                    val note = data[i + 1].toInt() and 0x7F
                    val velocity = data[i + 2].toInt() and 0x7F
                    if (type == 0x90 && velocity > 0) {
                        onNoteOn(note, velocity / 127f)
                    } else {
                        onNoteOff(note)
                    }
                }
                i += needed
            }
        }
    }

    fun start() {
        manager.registerDeviceCallback(deviceCallback, handler)
        manager.devices.forEach { openDevice(it) }
        if (manager.devices.none { it.outputPortCount > 0 }) {
            onStatus("No MIDI keyboard connected")
        }
    }

    fun stop() {
        manager.unregisterDeviceCallback(deviceCallback)
        openPorts.forEach {
            try { it.close() } catch (_: IOException) { }
        }
        openPorts.clear()
        openDevices.values.forEach {
            try { it.close() } catch (_: IOException) { }
        }
        openDevices.clear()
    }

    private fun openDevice(info: MidiDeviceInfo) {
        if (info.outputPortCount == 0) return
        val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI device"

        manager.openDevice(info, MidiManager.OnDeviceOpenedListener { device ->
            if (device == null) {
                onStatus("Could not open $name")
                return@OnDeviceOpenedListener
            }
            val port = device.openOutputPort(0)
            if (port == null) {
                onStatus("No output port on $name")
                return@OnDeviceOpenedListener
            }
            openDevices[info.id] = device
            openPorts.add(port)
            port.connect(receiver)
            onStatus("MIDI keyboard: $name")
        }, handler)
    }
}
